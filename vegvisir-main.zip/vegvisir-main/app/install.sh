#!/usr/bin/env bash
# Build + install the debug APK, avoiding adb's incremental delivery.
#
# Some devices (e.g. custom Android 13 automotive images) log
#   "Failed to measure fs-verity, errno 1"
# when adb uses incremental/streamed install and the /data filesystem can't do
# fs-verity. The warning is non-fatal, but --no-incremental avoids it entirely.
#
# Usage: ./install.sh [--release]
set -euo pipefail
cd "$(dirname "$0")"

VARIANT="debug"
GRADLE_TASK=":app:assembleDebug"
if [[ "${1:-}" == "--release" ]]; then
    VARIANT="release"
    GRADLE_TASK=":app:assembleRelease"
fi

ADB="${ANDROID_HOME:-$HOME/Library/Android/sdk}/platform-tools/adb"
[ -x "$ADB" ] || ADB="adb"

./gradlew "$GRADLE_TASK"

APK="app/build/outputs/apk/$VARIANT/app-$VARIANT.apk"
echo "Installing $APK (no-incremental)…"
"$ADB" install -r --no-incremental "$APK"
