# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

Vegvisir is an Android app (Kotlin + Jetpack Compose). The TCP server socket is
**pure Kotlin** (`server/ServerEngine.kt`); the only native C++ is the LSPosed SSL
hook that runs **inside vn.vietmap.live** (`libvietmaphook`). The project root is
this `vegvisir/` directory (where `gradlew` lives), not its `mazda/` parent.

## Commands

Run all Gradle commands from this directory (`vegvisir/`):

- Build debug APK: `./gradlew :app:assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`
- Install to a connected device/emulator: `./gradlew :app:installDebug`, or
  `./install.sh` which uses `adb install --no-incremental`. On some devices
  (custom Android 13 automotive images) the incremental install path logs a
  non-fatal `Failed to measure fs-verity, errno 1`; `--no-incremental` avoids it.
  The APK is v2-signed only (no v4 `.idsig`), so nothing in the build forces
  fs-verity.
- Rebuild only the native `.so` (the vietmap hook): `./gradlew :app:externalNativeBuildDebug`
  (add `--rerun-tasks` to force a recompile after editing C++ that Gradle thinks is up-to-date)

There is no automated test suite yet. If unit tests are added they run via
`./gradlew :app:testDebugUnitTest`.

## Architecture

Two independent pieces run in **two different processes**:

1. **The app** (this process) — Compose UI + the pure-Kotlin socket server
   ([server/ServerEngine.kt](app/src/main/kotlin/com/rongcondihoc/vegvisir/server/ServerEngine.kt)).
   No JNI, no native lib is loaded here.
2. **The SSL hook** — `libvietmaphook.so`, loaded by **LSPosed into vn.vietmap.live**
   (`service/vietmap/` — `Hook.kt`, `RouteParser.kt`, `FileLog.kt` — plus
   `cpp/vietmap-hook/`). It taps `SSL_read/SSL_write`
   (ShadowHook — must be native), reassembles HTTP, and forwards captured navigation
   over **loopback** as a VEG1 client. This is the *only* C++ that ships.

The two meet only on the wire: the hook dials the app's server over loopback and
registers as a `vietmap` client. There is no shared memory, no JNI between them.

**Boot path:** `VegvisirApp.onCreate` → `ServerEngine.start()` → a coroutine binds
IPv6 dual-stack `[::]:15985` and runs the accept loop; each client gets its own
reader coroutine (`Dispatchers.IO`). Dual-stack so the mazda unit dials in over IPv6
and the hook over IPv4 loopback.

**State path:** a client connect/disconnect/register calls `ServerEngine.publishState()`
→ updates `state: StateFlow<EngineState>` → Compose collects it (via
[EngineViewModel](app/src/main/kotlin/com/rongcondihoc/vegvisir/ui/EngineViewModel.kt)).
The UI never polls; it only observes. `EngineState`/`Connector`
([domain/EngineState.kt](app/src/main/kotlin/com/rongcondihoc/vegvisir/domain/EngineState.kt))
is the single source of UI truth. `Connector.fd` is now a **synthetic connection id**
(there is no socket fd on the JVM); the UI passes it back to `sendMessageTo(fd, …)`.

**Message protocol:** every message is a VEG1 *envelope* — a fixed 19-byte header
`magic "VEG1" | version | type | flags | id(4) | replyTo(4) | bodyLen(4)`
(big-endian) + `bodyLen` bytes; `flags` bit0 = binary body (else JSON/UTF-8). The
Kotlin codec is [server/Envelope.kt](app/src/main/kotlin/com/rongcondihoc/vegvisir/server/Envelope.kt);
the hook keeps its own C++ copy (`cpp/vietmap-hook/protocol/envelope.*`) since it
frames messages from inside VietMap's process. `MessageType` is therefore duplicated
in Kotlin (`domain/MessageType.kt`), C++ (`protocol/envelope.h`, hook-only), and
Python (`vegvisir-sim/.../protocol.py`) — wire values must stay in sync.

- **Outbound (server → client):** `ServerEngine.sendMessage`/`sendFile` (all clients),
  `sendMessageTo`/`sendFileTo(fd)` (one client), `sendToType`/`sendFileToType`/
  `sendNavigationToMazda`/`sendUpgradeToMazda` (by role). Files stream as `FileBegin`
  (JSON `{name,size,mime}`) + N × `FileChunk` (64 KB binary) + `FileEnd`, read from
  disk in chunks (never fully buffered).
- **Inbound (client → server):** `ServerEngine.serveClient` frames envelopes and
  calls `onFrame`, which (1) routes by role (below) and (2) emits every message to
  `requests: SharedFlow<RequestEvent>`, which `VegvisirApp` collects (e.g.
  `{"action":"request-file"}` → `sendFileTo(fd, …)`).
- `vegvisir-sim` is the reference **mazda** client: on connect it sends
  `Register {"clientType":"mazda"}`, then receives navigation + upgrades (its
  `client_type` config can be set to `vietmap` to drive navigation instead).

**Client roles + routing (all in `ServerEngine`).** A client declares a role once,
on connect, with a `Register` message (`MessageType.REGISTER = 12`, body
`{"clientType":"mazda"|"vietmap"|"googlemap"}`), handled in `onFrame`/`parseClientType`:

- **vietmap/googlemap → mazda:** a source's `Navigation` body is validated + clamped
  and re-serialized to the canonical HUD-sink schema by
  [server/Navigation.kt](app/src/main/kotlin/com/rongcondihoc/vegvisir/server/Navigation.kt),
  then relayed with `sendToType(MAZDA, NAVIGATION, …)`.
  **Gated by the selected `NavSource`** (`domain/NavSource.kt`): the Navigation source
  page picks None/VietMap/Google Maps and `ServerEngine.setNavSource` relays only the
  chosen source, dropping the rest; switching (and None) sends `active:false` to blank
  the HUD. Both hooks keep running in their own processes — the switch is purely
  server-side, so no cross-process signalling is involved. The choice is persisted by
  `VegvisirApp` (SharedPreferences `vegvisir/nav_source`); default None.
- **mazda** is a receiver: its inbound traffic is logged, not routed.
- Extending = add a `ClientType` value and a branch in `onFrame`. The HUD-sink
  Navigation JSON schema is normative — it must match vegvisir-client's hud-navigate
  provider (keys/enum values). `MessageType`/`ClientType` wire values are duplicated
  in Kotlin (`domain/`), C++ (hook), and Python (`vegvisir-sim`) — keep in sync.

## Build constraints (don't silently break these)

- **16 KB page-size support** (Android 15+): the native lib (`libvietmaphook`) links
  with `-Wl,-z,max-page-size=16384` ([CMakeLists.txt](app/src/main/cpp/CMakeLists.txt))
  and uses `-DANDROID_STL=c++_static`. Do **not** switch back to `c++_shared` on NDK 26 —
  its prebuilt `libc++_shared.so` is only 4 KB-aligned and breaks 16 KB devices.
  `useLegacyPackaging = false` keeps the `.so` uncompressed and 16 KB zip-aligned.
- **ProGuard/JNI:** the vietmap hook's `native` methods and its LSPosed entry
  (`service.vietmap.Hook`, named in `assets/xposed_init` and in libvietmaphook's JNI
  symbol) are kept in `proguard-rules.pro`. The app process no longer loads
  any native lib, so there is no server-side JNI to keep.
- **Signing:** all build types sign with a committed keystore
  `keystore/vegvisir.debug.jks` (a copy of the standard Android debug key,
  creds `android` / `androiddebugkey`) via the `shared` `signingConfig`. This
  keeps one stable signature across machines so reinstalls never hit a
  "signature mismatch / package frozen" error. Do not revert to the per-machine
  `~/.android/debug.keystore`. It is a debug-grade key — replace it before any
  production release.
- Kotlin sources live under `src/main/kotlin/` (not `java/`); ABIs are `arm64-v8a` + `x86_64`.
- Toolchain is pinned: AGP 8.5.2 / Kotlin 1.9.24 / Compose compiler 1.5.14 / compileSdk 34 /
  NDK 26.3 / CMake 3.22.1. These versions are matched — bump them together.

## Conventions

### Language
- All code is written in **English**: comments, log/UI strings, identifiers, commit messages.

### C++ style
- **No trailing `_` suffix on member variables.** Use bare names (`port`, `running`,
  `clients`). Organize in OOP style: private members, behavior via methods.
- When a setter/ctor parameter shadows a member, disambiguate with `this->`
  (e.g. `this->port = port;`).
- A member and a method cannot share a name, so getters are: bool → `isX()`
  (`isRunning()`), value → `getX()` (`getPort()`).
- Anonymous-namespace file globals keep the `g_` prefix (`g_vm`) — the rule bans the
  trailing `_` suffix only.
