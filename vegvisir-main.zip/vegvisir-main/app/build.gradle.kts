// Vegvisir — Android capture server (IPv6 socket server @ port 15985, native C++ core).
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
