plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rongcondihoc.vegvisir"
    compileSdk = 34
    ndkVersion = "26.3.11579264"

    defaultConfig {
        applicationId = "com.rongcondihoc.vegvisir"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        ndk {
            // arm64-v8a only: ShadowHook (used by the LSPosed hook lib) is ARM-only,
            // and the target device + vn.vietmap.live are both arm64.
            abiFilters += "arm64-v8a"
        }
        externalNativeBuild {
            cmake {
                // c++_static: libvietmaphook.so carries its own STL, so no libc++_shared.so is
                // bundled — NDK 26's prebuilt libc++_shared.so is only 4 KB-aligned and would
                // break 16 KB page-size devices. Safe here: the hook is the only native lib.
                arguments += "-DANDROID_STL=c++_static"
                cppFlags += "-std=c++17 -fvisibility=hidden"
            }
        }
    }

    signingConfigs {
        // A stable, committed key (a copy of the standard Android debug key) shared by
        // every build type and every machine. This guarantees a consistent signature so
        // reinstalling never hits a "signature mismatch / package frozen" error.
        // Debug-grade key — fine for this internal test app, NOT for a production release.
        create("shared") {
            storeFile = rootProject.file("keystore/vegvisir.debug.jks")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("shared")
        }
        getByName("release") {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("shared")
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    packaging {
        jniLibs {
            useLegacyPackaging = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // Use kotlin/ as the source root instead of java/.
    sourceSets["main"].java.srcDir("src/main/kotlin")

    buildFeatures {
        buildConfig = true
        compose = true
        prefab = true  // exposes the "shadowhook" prefab package to CMake
    }

    composeOptions {
        // Compose Compiler 1.5.14 matches Kotlin 1.9.24.
        kotlinCompilerExtensionVersion = "1.5.14"
    }
}

dependencies {
    // --- LSPosed hook (runs inside vn.vietmap.live's process) ---
    // Xposed API — compile only, provided by LSPosed at runtime (NOT packaged).
    compileOnly("de.robv.android.xposed:api:82")
    // ShadowHook — native inline hooking; packages libshadowhook.so into the APK.
    implementation("com.bytedance.android:shadowhook:1.0.10")

    // BOM 2024.06 = Compose 1.6.8 / Material3 1.2.1 — matches compileSdk 34 + Kotlin 1.9.24.
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
