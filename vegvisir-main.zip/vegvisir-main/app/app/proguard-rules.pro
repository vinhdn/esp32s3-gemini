# Keep JNI entry points: native methods (the vietmap hook's bridge to libvietmaphook).
-keepclasseswithmembernames class * {
    native <methods>;
}

# LSPosed entry point (loaded by name from assets/xposed_init) + its native bridge.
-keep class com.rongcondihoc.vegvisir.service.vietmap.Hook { *; }
# JNI upcall target: native (libvietmaphook) calls this by exact class + method name.
-keep class com.rongcondihoc.vegvisir.service.vietmap.Hook$NativeHook {
    static void onApiResponse(java.lang.String, java.lang.String, byte[]);
}
# RouteGuide's Java->native binding resolves libvietmaphook's statically-named symbol
# (Java_..._RouteGuide_nativeSendNavigation), so the class name must not change.
-keep class com.rongcondihoc.vegvisir.service.RouteGuide {
    native <methods>;
}
# Xposed API is provided by LSPosed at runtime (compileOnly), not packaged.
-dontwarn de.robv.android.xposed.**
# Self-hook activation probe: the sentinel method must not be inlined/renamed away, or the
# self-hook test in LposedStatus cannot flip its result.
-keep class com.rongcondihoc.vegvisir.service.LposedStatus { *; }
-keep class de.robv.android.xposed.** { *; }
