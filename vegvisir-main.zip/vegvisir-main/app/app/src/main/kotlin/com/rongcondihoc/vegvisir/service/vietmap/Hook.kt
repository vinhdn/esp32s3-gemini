package com.rongcondihoc.vegvisir.service.vietmap

import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import com.rongcondihoc.vegvisir.service.GpsMock
import com.rongcondihoc.vegvisir.service.GpsService
import com.rongcondihoc.vegvisir.service.RouteGuide
import com.rongcondihoc.vegvisir.service.googlemaps.GoogleMapsHook
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * LSPosed entry point (declared in assets/xposed_init), loaded into vn.vietmap.live.
 *
 * It arms two independent, self-contained taps on the target. Each tap keeps its
 * own state and functions in its own nested object:
 *
 *  1. [NativeHook] — loads libvietmaphook.so and hooks libflutter's BoringSSL
 *     SSL_read/SSL_write (cpp/vietmap-hook/ssl-tap.*). The native side reassembles
 *     plaintext into whole HTTP responses (cpp/vietmap-hook/http-reasm.*) for the
 *     configured API_PATHS and pushes them back up here via [onApiResponse], plus
 *     opens a vietmap socket client to the Vegvisir server (cpp/vietmap-hook/vietmap-client.*).
 *
 *  2. [FlutterHook] — a Java-side hook on FlutterJNI.handlePlatformMessage that
 *     decodes the platform channels carrying navigation overlay data
 *     ("updateMapOverlayData", "sendVMLCommonData") and hands them to a capture
 *     point. It intercepts only those methods and does not log.
 */
class Hook : IXposedHookZygoteInit, IXposedHookLoadPackage {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam) {
        NativeHook.modulePath = startupParam.modulePath
    }

    override fun handleLoadPackage(lpparam: LoadPackageParam) {
        // Google Maps runs its own provider (navcore lifecycle + directions capture + RouteGuide);
        // it shares none of the VietMap SSL/Flutter path.
        if (lpparam.packageName == GOOGLE_MAPS_PACKAGE) {
            GoogleMapsHook.install(lpparam)
            return
        }
        if (lpparam.packageName != TARGET_PACKAGE) return
        try {
            NativeHook.install()
            FlutterHook.install(lpparam.classLoader)
            GpsMock.installIfEnabled()
            // Live position source for route guidance: each fix drives RouteGuide, which turns
            // the captured Route API into one HUD Navigation frame per position update.
            GpsService.start { location -> RouteGuide.onLocation(location) }
            Log.d(TAG, "armed on ${lpparam.packageName}")
        } catch (t: Throwable) {
            Log.e(TAG, "install error on ${lpparam.packageName}: $t")
        }
    }

    // =========================================================================
    // 1. NATIVE tap — HTTP response capture via the BoringSSL hook.
    //    All native-only state + functions live here.
    // =========================================================================
    private object NativeHook {
        private const val LIB = "vietmaphook"
        private const val DEP_LIB = "shadowhook"  // libvietmaphook.so's DT_NEEDED — load first

        // STATIC SSL_read/SSL_write offsets inside vn.vietmap.live's libflutter.so, plus the
        // libflutter build-id they belong to. Native compares the build-id before hooking and
        // SKIPS on mismatch (hooking the wrong address would crash Vietmap). These are for one
        // specific Flutter build — update them for the installed version (see tools/README).
        private const val SSL_READ_OFF = 0x5fad50L
        private const val SSL_WRITE_OFF = 0x5fb45cL
        private const val EXPECT_BUILD_ID = "a346b27d0ec2c209b948fa05ad2f255e5bedc592"

        // API response paths whose bodies native should push up to [onApiResponse].
        // Matching is prefix-based on the request path with the query string stripped
        // (so "/place/Route" matches "/place/Route?apikey=…"). Edit this list to pick
        // which endpoints to capture; empty = capture nothing. Each match is saved as JSON
        // by [onApiResponse].
        // Do NOT add "/production/tracklogv2/v20/trackinglog/events" hoping to find an
        // end-of-trip signal there: its POST body was captured once and is ENCRYPTED (high-entropy
        // binary, neither JSON nor gzip), and it posts on a fixed 30-60 s heartbeat that merely
        // batches whatever happened — too late to blank the HUD even if it could be read.
        private val API_PATHS = arrayOf(
            "/production/tracking/v20/place/Route",
        )

        // Set once by initZygote; read many times by install().
        @Volatile
        var modulePath: String? = null

        @Volatile
        private var loaded = false

        /** Load the native lib and arm the SSL tap. Idempotent. */
        fun install() {
            if (!loadNative(modulePath ?: modulePathFromClassLoader())) return
            nativeStart(SSL_READ_OFF, SSL_WRITE_OFF, EXPECT_BUILD_ID, API_PATHS)
        }

        /**
         * Load libvietmaphook.so. Inside vn.vietmap.live\'s process the .so is NOT on that app's
         * library path — it lives in the module's APK, so we dlopen straight from `apk!/lib/<abi>/…`
         * (works because `packaging.jniLibs.useLegacyPackaging = false` stores it uncompressed and
         * 16 KB-aligned). libshadowhook.so (a DT_NEEDED) must be loaded first so the linker resolves
         * it by soname among already-loaded libraries.
         */
        @SuppressLint("UnsafeDynamicallyLoadedCode")
        private fun loadNative(modulePath: String?): Boolean {
            if (loaded) return true
            if (modulePath == null) {
                Log.w(TAG, "modulePath unknown -> cannot load lib$LIB.so")
                return false
            }
            for (abi in Build.SUPPORTED_ABIS) {
                val dir = "$modulePath!/lib/$abi"
                try {
                    System.load("$dir/lib$DEP_LIB.so")
                    System.load("$dir/lib$LIB.so")
                    loaded = true
                    return true
                } catch (t: Throwable) {
                    Log.e(TAG, "loading $dir/lib$LIB.so failed: $t")
                }
            }
            return false
        }

        /** JNI: arms ssl-tap in libvietmaphook.so. Symbol: ..._Hook_00024NativeHook_nativeStart. */
        private external fun nativeStart(
            readOff: Long, writeOff: Long, buildId: String, apiPaths: Array<String>,
        )

        /**
         * Called FROM native (ssl-tap's drain thread, attached to the JVM) once per captured
         * HTTP response whose path matched [API_PATHS]. This is the app-side processing point
         * for VietMap's original API JSON — far richer than what the platform channel carries.
         *
         * @param path    the request path (with query string), e.g. "/place/Route?apikey=…"
         * @param status  the response status line, e.g. "HTTP/1.1 200 OK"
         * @param body    the raw response body, already de-chunked + gunzipped (usually JSON)
         */
        @JvmStatic
        private fun onApiResponse(path: String, status: String, body: ByteArray) {
            // Trace the capture to file, and dump the raw API body verbatim as its own JSON file.
            FileLog.line("api ◀ $path  [$status]  ${body.size}B")
            FileLog.saveBytes(path.substringBefore('?').trim('/'), "json", body)
            // VietMap is a navigation provider: parse its Route API into the standard NavRoute and
            // hand it to the provider-neutral RouteGuide engine, which drives the HUD from GPS.
            RouteParser.parse(body)?.let { RouteGuide.setRoute(it) }
        }

        // Fallback when initZygote does not run: PathClassLoader prints the APK path.
        private fun modulePathFromClassLoader(): String? {
            val s = Hook::class.java.classLoader?.toString() ?: return null
            return Regex("""zip file "([^"]+\.apk)"""").find(s)?.groupValues?.get(1)
        }
    }

    // =========================================================================
    // 2. FLUTTER tap — navigation overlay capture via FlutterJNI.
    //    All flutter-only state + functions live here.
    // =========================================================================
    /**
     * Hook on FlutterJNI.handlePlatformMessage — the obfuscation-proof tap into VietMap's
     * platform channels. It intercepts one method family and nothing else: [DATA_METHODS], whose
     * arguments are decoded with a handwritten StandardMessageCodec reader and handed to
     * [handleData]. Everything else is only seen by the opt-in trace ([TRACE_FLAG]).
     *
     * WHY FlutterJNI (not StandardMethodCodec): vn.vietmap.live ships R8-obfuscated Flutter
     * classes, so the codec/channel classes are renamed. FlutterJNI keeps its real name
     * (native looks it up by name), so hooking it by name survives obfuscation. It hands us
     * the plain channel name + the raw encoded ByteBuffer, which we decode ourselves.
     */
    private object FlutterHook {
        // Methods carrying live guidance state (speedLimit). For a pigeon channel the method is
        // the channel's trailing segment; for a classic channel it is the MethodCall method
        // inside the payload.
        private val DATA_METHODS = setOf(
            "updateMapOverlayData",
            "sendVMLCommonData",
        )

        // THERE IS NO END-OF-GUIDANCE METHOD HERE. This used to dispatch on "endTripSession" and
        // "clearRoute"; a bench run with [TRACE_FLAG] on proved both are fiction and, worse, that
        // no platform-channel call marks the end of a trip at all:
        //   - "endTripSession" is absent from libapp.so (so Dart never sends it) and is only a
        //     string literal in the dex — not a method name;
        //   - "clearRoute" does not exist either; the app has MapboxMapApi.clearRoutes and
        //     GeneratedCarApi.clearRouteTooltips, and neither fires;
        //   - cancelling a trip from the UI produced ~1500 platform messages of which NOT ONE was
        //     new or carried a trip/route/nav word, while the trace kept heartbeating.
        // So ending guidance is handled entirely inside Dart. Arrival is therefore detected
        // geometrically in RouteGuide; a trip cancelled mid-route still has no signal here.

        // StandardMessageCodec type tag for String — a classic MethodChannel payload starts with
        // its method name, so anything else means this is not a MethodCall and we skip it
        // without decoding the (possibly huge) value tree.
        private const val CODEC_TYPE_STRING = 7

        // Opt-in channel tracing, so a bench run can see VietMap's whole platform-channel surface
        // and prove which call actually means "guidance is over" (mirrors GpsMock's flag-file
        // opt-in — create it as root, the app can read it):
        //   adb shell su -c 'touch /data/data/vn.vietmap.live/files/trace_channels.enable'
        // Off by default, so a normal run costs one volatile read per platform message.
        private const val TRACE_FLAG = "/data/data/vn.vietmap.live/files/trace_channels.enable"

        // Words that mark a route/trip lifecycle step. A method carrying one of them as a whole
        // camelCase word is traced on EVERY call; everything else is traced once, the first time
        // it is seen. Whole words, not substrings — "sendVMLCommonData" contains "end".
        private val TRACE_WORDS = setOf(
            "trip", "route", "routes", "nav", "navigation", "arrive", "arrival", "maneuver",
            "clear", "cleared", "start", "started", "stop", "end", "ended", "finish", "cancel",
        )

        /** Split a method name into lowercase words: "setCarManeuver" -> [set, car, maneuver]. */
        private fun words(s: String): List<String> =
            s.split(Regex("(?<=[a-z0-9])(?=[A-Z])|[^A-Za-z0-9]+")).map { it.lowercase() }

        // Every this many platform messages the trace writes a heartbeat, so a quiet stretch can be
        // read as "nothing route-related crossed the boundary" rather than "the hook died".
        private const val TRACE_HEARTBEAT = 500L

        private val traceSeen = java.util.Collections.synchronizedSet(HashSet<String>())
        private val traceCount = java.util.concurrent.atomic.AtomicLong()

        @Volatile
        private var tracing = false

        @Volatile
        private var installed = false

        fun install(classLoader: ClassLoader?) {
            if (installed) return
            val cl = classLoader ?: return
            tracing = try {
                java.io.File(TRACE_FLAG).exists()
            } catch (t: Throwable) {
                false
            }
            if (tracing) FileLog.line("channel trace: ON")
            hookFlutterJni(cl)
            installed = true
        }

        /** Trace one platform-channel call when [TRACE_FLAG] is present; a no-op otherwise. */
        private fun trace(channel: String, method: String) {
            if (!tracing) return
            val n = traceCount.incrementAndGet()
            if (n % TRACE_HEARTBEAT == 0L) FileLog.line("ch ... $n platform messages so far")
            val first = traceSeen.add("$channel|$method")
            if (first || words(method).any { it in TRACE_WORDS }) {
                FileLog.line("ch ${if (first) "NEW" else "   "} $method   [$channel]")
            }
        }

        /**
         * Hook FlutterJNI.handlePlatformMessage(String channel, ByteBuffer message,
         * int replyId, long messageData) — every overload, by name.
         */
        private fun hookFlutterJni(cl: ClassLoader) {
            val jni = try {
                XposedHelpers.findClass("io.flutter.embedding.engine.FlutterJNI", cl)
            } catch (t: Throwable) {
                Log.e(TAG, "FlutterJNI not found: $t")
                return
            }
            XposedBridge.hookAllMethods(jni, "handlePlatformMessage", object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val channel = param.args.getOrNull(0) as? String ?: return
                    val buffer = param.args.getOrNull(1) as? ByteBuffer ?: return
                    onPlatformMessage(channel, buffer)
                }
            })
        }

        private fun onPlatformMessage(channel: String, buffer: ByteBuffer) {
            val pigeon = channel.startsWith("dev.flutter.pigeon.")
            // Decode on a DUPLICATE so we never disturb the buffer the real handler reads.
            val dup = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)

            // Resolve the method name first — it is free for a pigeon channel (the trailing
            // channel segment) and one string read for a classic one. Gating on the method
            // rather than on a hardcoded channel name means a target method is caught on
            // whatever channel VietMap happens to carry it on.
            val method = try {
                if (pigeon) channel.substringAfterLast('.') else readMethodName(dup)
            } catch (t: Throwable) {
                null
            }
            if (method == null) {
                // Not a MethodCall (a BasicMessageChannel payload, say). Nothing to dispatch on,
                // but trace the channel anyway so the trace has no blind spot.
                trace(channel, "(not a method call)")
                return
            }

            trace(channel, method)

            // Only a data method pays for the payload tree decode.
            if (method in DATA_METHODS) {
                val args = try {
                    if (dup.hasRemaining()) readValue(dup) else null
                } catch (t: Throwable) {
                    return
                }
                handleData(args)
            }
        }

        /**
         * Read a classic MethodChannel payload's leading method name, or null if the payload does
         * not start with a string (i.e. it is not a MethodCall). Peeks the type tag first so a
         * non-MethodCall channel never costs us a full value-tree decode.
         */
        private fun readMethodName(b: ByteBuffer): String? {
            if (!b.hasRemaining()) return null
            if ((b.get(b.position()).toInt() and 0xff) != CODEC_TYPE_STRING) return null
            return readValue(b) as? String
        }

        /**
         * Capture point for a [DATA_METHODS] call's decoded arguments (no logging).
         *   - updateMapOverlayData: speedLimit at the top level of the args map.
         *   - sendVMLCommonData:    speedLimit under `mapMatchingData`.
         * [findValue] walks the whole map/list/pigeon tree, so it finds it either way.
         */
        private fun handleData(args: Any?) {
            traceKeys(args)
            // speedLimit may arrive as a number or a numeric string depending on the channel.
            val speedLimit = when (val raw = findValue(args, "speedLimit")) {
                is Number -> raw.toInt()
                is String -> raw.trim().toIntOrNull() ?: return
                else -> return
            }
            // Feed the posted speed limit into guidance; RouteGuide includes it in each frame.
            RouteGuide.updateSpeedLimit(speedLimit)
        }

        /**
         * Trace every route/trip-ish scalar carried by a [DATA_METHODS] payload, deduped by
         * key=value, so a bench run can see which field flips when guidance starts and ends.
         * Tracing only; a no-op unless [TRACE_FLAG] is present.
         */
        private fun traceKeys(node: Any?) {
            if (!tracing) return
            when (node) {
                is Map<*, *> -> for ((k, v) in node) {
                    val name = k as? String
                    if (name != null && (words(name).any { it in TRACE_WORDS } || name.startsWith("is"))) {
                        // Describe containers too: the tell for "guidance started" is a field
                        // going from null to an object, which a scalars-only dump would miss.
                        val desc = when (v) {
                            null -> "null"
                            is Map<*, *> -> "Map{${v.keys.joinToString(",").take(160)}}"
                            is List<*> -> "List(${v.size})"
                            is PigeonObject -> "Pigeon"
                            is ByteArray -> "bytes(${v.size})"
                            else -> v.toString().take(80)
                        }
                        if (traceSeen.add("kv|$name=$desc")) FileLog.line("kv $name = $desc")
                    }
                    traceKeys(v)
                }
                is List<*> -> for (v in node) traceKeys(v)
                is PigeonObject -> traceKeys(node.fields)
            }
        }

        /** Depth-first search for the first value stored under [key] in a Map/List/pigeon tree. */
        private fun findValue(node: Any?, key: String): Any? {
            when (node) {
                is Map<*, *> -> {
                    node[key]?.let { return it }
                    for (v in node.values) findValue(v, key)?.let { return it }
                }
                is List<*> -> for (v in node) findValue(v, key)?.let { return it }
                is PigeonObject -> return findValue(node.fields, key)
            }
            return null
        }

        // ---- StandardMessageCodec decoder (mirrors Flutter's wire format) -----

        private fun readValue(b: ByteBuffer): Any? = when (b.get().toInt() and 0xff) {
            0 -> null
            1 -> true
            2 -> false
            3 -> b.int
            4 -> b.long
            5 -> {                                    // BigInteger (hex string)
                val bytes = ByteArray(readSize(b)); b.get(bytes)
                BigInteger(String(bytes, Charsets.UTF_8), 16)
            }
            6 -> { align(b, 8); b.double }
            7 -> { val bytes = ByteArray(readSize(b)); b.get(bytes); String(bytes, Charsets.UTF_8) }
            8 -> { val bytes = ByteArray(readSize(b)); b.get(bytes); bytes }
            9 -> { val n = readSize(b); align(b, 4); IntArray(n) { b.int } }
            10 -> { val n = readSize(b); align(b, 8); LongArray(n) { b.long } }
            11 -> { val n = readSize(b); align(b, 8); DoubleArray(n) { b.double } }
            12 -> { val n = readSize(b); ArrayList<Any?>(n).apply { repeat(n) { add(readValue(b)) } } }
            13 -> {                                   // Map
                val n = readSize(b)
                LinkedHashMap<Any?, Any?>(n).apply { repeat(n) { put(readValue(b), readValue(b)) } }
            }
            14 -> { val n = readSize(b); align(b, 4); FloatArray(n) { b.float } }
            else -> {
                // Pigeon custom type (id >= 128): the object is encoded as its field LIST via
                // the standard writer, so decode the following value as that field list. The
                // type id itself is not kept — we search the tree by key, never by type.
                PigeonObject(readValue(b))
            }
        }

        /** A pigeon custom-typed object, reduced to the part we search: its field list. */
        private class PigeonObject(val fields: Any?)

        private fun readSize(b: ByteBuffer): Int = when (val v = b.get().toInt() and 0xff) {
            254 -> b.short.toInt() and 0xffff
            255 -> b.int
            else -> v
        }

        private fun align(b: ByteBuffer, alignment: Int) {
            val mod = b.position() % alignment
            if (mod != 0) b.position(b.position() + alignment - mod)
        }
    }

    private companion object {
        const val TAG = "VietMapHook"
        const val TARGET_PACKAGE = "vn.vietmap.live"
        const val GOOGLE_MAPS_PACKAGE = "com.google.android.apps.maps"
    }
}
