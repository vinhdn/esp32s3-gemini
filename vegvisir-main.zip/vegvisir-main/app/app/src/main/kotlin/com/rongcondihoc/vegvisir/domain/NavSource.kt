package com.rongcondihoc.vegvisir.domain

/**
 * Which navigation source is allowed to drive the HUD, chosen by the user on the main screen.
 *
 * This is a SERVER-SIDE switch: the hooks (VietMap / Google Maps) keep running in their own
 * processes and may keep sending, but [com.rongcondihoc.vegvisir.server.ServerEngine] relays only
 * the selected source's Navigation to the mazda head unit and drops the rest. [NONE] relays nothing
 * and blanks the cluster.
 */
enum class NavSource(val label: String) {
    NONE("None"),
    VIETMAP("VietMap"),
    GOOGLEMAP("Google Maps");

    /** The client role this source relays from, or null for [NONE] (relay nothing). */
    val clientType: ClientType?
        get() = when (this) {
            NONE -> null
            VIETMAP -> ClientType.VIETMAP
            GOOGLEMAP -> ClientType.GOOGLEMAP
        }
}
