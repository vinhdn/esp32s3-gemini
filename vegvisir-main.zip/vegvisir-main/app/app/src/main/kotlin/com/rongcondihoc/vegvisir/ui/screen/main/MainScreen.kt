package com.rongcondihoc.vegvisir.ui.screen.main

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rongcondihoc.vegvisir.domain.ClientType
import com.rongcondihoc.vegvisir.domain.EngineState
import com.rongcondihoc.vegvisir.domain.NavSource
import com.rongcondihoc.vegvisir.ui.component.MazdaStatusCard
import com.rongcondihoc.vegvisir.ui.component.NavSourceCard

/**
 * The app home: one card per thing the user cares about.
 *
 *  - Mazda head unit — is the car's vegvisir-client connected; tap (when connected) for its
 *    detail page.
 *  - Navigation source — which source drives the HUD and whether it is connected; tap to pick
 *    another source.
 *
 * The server's own listening state rides in the top bar, since it is background plumbing rather
 * than something to act on.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    state: EngineState,
    navSource: NavSource,
    onOpenMazda: () -> Unit,
    onOpenNavSource: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Vegvisir") },
            )
        },
    ) { inner ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            MazdaStatusCard(
                client = state.clientOf(ClientType.MAZDA),
                onOpen = onOpenMazda,
            )
            NavSourceCard(
                selected = navSource,
                connected = navSource.clientType?.let(state::isConnected) ?: false,
                onOpen = onOpenNavSource,
            )
        }
    }
}
