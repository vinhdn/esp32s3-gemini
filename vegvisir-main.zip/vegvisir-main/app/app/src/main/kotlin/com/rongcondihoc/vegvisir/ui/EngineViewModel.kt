package com.rongcondihoc.vegvisir.ui

import androidx.lifecycle.ViewModel
import com.rongcondihoc.vegvisir.domain.EngineState
import com.rongcondihoc.vegvisir.domain.NavSource
import com.rongcondihoc.vegvisir.server.ServerEngine
import com.rongcondihoc.vegvisir.service.HookInstaller
import com.rongcondihoc.vegvisir.service.LposedStatus
import kotlinx.coroutines.flow.StateFlow

/** Exposes the engine snapshot to the UI. Both screens share this state. */
class EngineViewModel : ViewModel() {
    val state: StateFlow<EngineState> = ServerEngine.state

    /** The navigation source currently allowed to drive the HUD (main-screen Maps card). */
    val navSource: StateFlow<NavSource> = ServerEngine.navSource

    /** Pick the navigation source; the server relays only this one and clears the HUD on change. */
    fun selectNavSource(source: NavSource) = ServerEngine.setNavSource(source)

    /** True when the LSPosed hook is active for this device (no root needed to check). */
    fun isHookActive(): Boolean = LposedStatus.isModuleActive()

    /**
     * Enable the hook (Zygisk + LSPosed) via root and reboot. Returns only on failure (false);
     * success reboots the device. See [HookInstaller.enableAndReboot].
     */
    suspend fun enableHookAndReboot(): Boolean = HookInstaller.enableAndReboot()
}
