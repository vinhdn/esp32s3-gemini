package com.rongcondihoc.vegvisir.server

import android.util.Log
import com.rongcondihoc.vegvisir.domain.ClientType
import com.rongcondihoc.vegvisir.domain.Connector
import com.rongcondihoc.vegvisir.domain.EngineState
import com.rongcondihoc.vegvisir.domain.MessageType
import com.rongcondihoc.vegvisir.domain.NavSource
import com.rongcondihoc.vegvisir.domain.RequestEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.File
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * The VEG1 socket server — the pure-Kotlin replacement for the former native
 * core (libvegvisir.so: server / client-manager / handlers / main-engine + JNI).
 *
 * It listens on [::]:15985 (dual-stack, so the mazda unit dials in over IPv6 and
 * the vietmap hook over IPv4 loopback), frames VEG1 envelopes, tracks each
 * client's role from its Register message, and relays navigation from a source
 * (vietmap / googlemap) to every mazda head unit.
 *
 * This is the single seam the UI talks to: [state] mirrors the live client list,
 * [requests] surfaces every inbound message, and the `send*` methods push out.
 * Only the SSL hook remains in C++ (it must — inline hooking cannot run on the JVM).
 */
object ServerEngine {

    const val PORT = 15985
    private const val TAG = "Vegvisir"
    private const val CHUNK_SIZE = 64 * 1024
    private const val REBIND_DELAY_MS = 2000L   // wait before re-binding after a bind/accept failure

    // --- observable state ------------------------------------------------
    private val _state = MutableStateFlow(EngineState())
    val state: StateFlow<EngineState> = _state.asStateFlow()

    private val _requests = MutableSharedFlow<RequestEvent>(extraBufferCapacity = 64)
    val requests: SharedFlow<RequestEvent> = _requests.asSharedFlow()

    /**
     * Which navigation source may drive the HUD (chosen on the main screen). Only this source's
     * Navigation is relayed to mazda; everything else is dropped. Default [NavSource.NONE] — the
     * user picks a map explicitly. Persisted by [com.rongcondihoc.vegvisir.VegvisirApp].
     */
    private val _navSource = MutableStateFlow(NavSource.NONE)
    val navSource: StateFlow<NavSource> = _navSource.asStateFlow()

    // --- internals -------------------------------------------------------
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val clients = ConcurrentHashMap<Int, Conn>()
    private val nextConnId = AtomicInteger(1)   // synthetic "fd" for the UI
    private val nextMsgId = AtomicInteger(1)     // ids for messages / files

    @Volatile private var serverSocket: ServerSocket? = null
    @Volatile private var started = false

    /** One accepted client connection. */
    private class Conn(val id: Int, val socket: Socket, val ip: String, val port: Int) {
        @Volatile var type: ClientType = ClientType.UNKNOWN
        val input = DataInputStream(BufferedInputStream(socket.getInputStream()))
        private val output = socket.getOutputStream()
        private val writeLock = Any()

        /**
         * Write a whole frame atomically; false if the socket is gone.
         *
         * Catches [Throwable], not just [IOException]: a failed send to one client must never
         * propagate into the caller (a UI click, another client's reader coroutine) and kill the
         * process — the send API reports delivery by count, not by exception.
         */
        fun write(bytes: ByteArray): Boolean = synchronized(writeLock) {
            return try {
                output.write(bytes)
                output.flush()
                true
            } catch (t: Throwable) {
                Log.w(TAG, "write to id=$id failed: $t")
                false
            }
        }
    }

    // ====================================================================
    //  Lifecycle
    // ====================================================================

    /** Boot the server socket. Safe to call once at app start. */
    @Synchronized
    fun start() {
        if (started) return
        started = true
        scope.launch { runServer() }
    }

    /**
     * Choose which navigation source drives the HUD — the server-side map switch behind the main
     * screen's Maps card. Only the selected source's Navigation is relayed to mazda from now on;
     * the others are dropped in [relayNavigation]. Switching always blanks the cluster first
     * (`active:false`) so a stale maneuver from the previous source never lingers:
     *   - [NavSource.NONE] — the blank IS the effect (guidance off),
     *   - VietMap / Google Maps — the newly selected source repaints on its next frame (~1 Hz).
     * No-op if the selection is unchanged.
     *
     * Callable from any thread — including the UI thread, which is where the Maps card calls it
     * from. The blank frame is therefore dispatched onto [scope] (IO): writing it inline would do a
     * blocking socket write on the main thread, which Android answers with a
     * NetworkOnMainThreadException — a crash whenever a mazda client happened to be connected.
     */
    fun setNavSource(source: NavSource) {
        if (_navSource.value == source) return
        _navSource.value = source
        Log.i(TAG, "nav source -> ${source.name.lowercase()}")
        // Clear whatever the outgoing source last put on the HUD (off the caller's thread).
        scope.launch { sendNavigationToMazda("""{"active":false}""") }
        publishState()
    }

    fun stop() {
        started = false
        runCatching { serverSocket?.close() }
        serverSocket = null
        clients.values.forEach { runCatching { it.socket.close() } }
        clients.clear()
        publishState()
    }

    /**
     * Self-healing server loop: keeps a bound listening socket for as long as the engine should be
     * running ([started]). A bind failure (e.g. the port briefly stuck in TIME_WAIT after a fast
     * restart) or an unexpected accept() error no longer kills the server for good — it waits
     * [REBIND_DELAY_MS] and rebinds. Only [stop] ends the loop (it flips [started] and closes the
     * socket, which makes accept() throw and unwinds cleanly). While unbound, [publishState]
     * reports `running=false` so the UI shows the outage.
     */
    private suspend fun runServer() {
        while (started) {
            val ss = try {
                ServerSocket().apply {
                    reuseAddress = true
                    bind(InetSocketAddress(InetAddress.getByName("::"), PORT))
                }
            } catch (e: Exception) {
                Log.e(TAG, "bind [::]:$PORT failed: ${e.message}; retrying in ${REBIND_DELAY_MS}ms")
                publishState()
                delay(REBIND_DELAY_MS)
                continue
            }
            serverSocket = ss
            Log.i(TAG, "Server listening on [::]:$PORT")
            publishState()

            try {
                while (started) {
                    val sock = ss.accept()   // throws when stop() closes the socket
                    onAccept(sock)
                }
            } catch (e: IOException) {
                if (started) Log.w(TAG, "accept() failed: ${e.message}; rebinding")
            } finally {
                runCatching { ss.close() }
                serverSocket = null
                publishState()
            }

            if (started) delay(REBIND_DELAY_MS)   // brief backoff before rebinding
        }
        publishState()
    }

    private fun onAccept(sock: Socket) {
        val id = nextConnId.getAndIncrement()
        val ip = (sock.inetAddress?.hostAddress ?: "?").removePrefix("::ffff:")
        val conn = Conn(id, sock, ip, sock.port)
        clients[id] = conn
        Log.i(TAG, "Client connected: $ip:${sock.port} (id=$id)")
        publishState()
        scope.launch { serveClient(conn) }
    }

    private fun serveClient(conn: Conn) {
        val header = ByteArray(Veg.HEADER_SIZE)
        try {
            while (started) {
                conn.input.readFully(header)   // throws EOFException at end of stream
                val h = parseEnvelopeHeader(header)
                if (h == null) {
                    Log.w(TAG, "bad frame from ${conn.ip} (dropping)")
                    break
                }
                if (h.bodyLen < 0 || h.bodyLen > Veg.MAX_BODY) {
                    Log.w(TAG, "body too large (${h.bodyLen}) from ${conn.ip}")
                    break
                }
                val body = ByteArray(h.bodyLen)
                if (h.bodyLen > 0) conn.input.readFully(body)
                onFrame(conn, h, body)
            }
        } catch (e: Exception) {
            // EOF / reset — normal disconnect path.
        } finally {
            clients.remove(conn.id)
            runCatching { conn.socket.close() }
            Log.i(TAG, "Client disconnected: ${conn.ip}:${conn.port} (id=${conn.id})")
            publishState()
        }
    }

    // ====================================================================
    //  Inbound routing (parity with the C++ ClientManager + handlers)
    // ====================================================================

    private fun onFrame(conn: Conn, h: FrameHeader, body: ByteArray) {
        if (h.type == MessageType.PING.wireValue) {
            // Liveness probe. The mazda client pings an idle link and treats a
            // long silence *after a Pong has been seen* as proof the link died,
            // so this reply is what lets it redial in seconds instead of waiting
            // on a TCP timeout. Answered here and dropped — it is transport
            // traffic, not something the app layer should see or a log should
            // fill up with every few seconds.
            conn.write(encodeEnvelope(MessageType.PONG.wireValue, ByteArray(0), replyTo = h.id))
            return
        }

        Log.i(TAG, "recv from ${conn.ip}: type=${h.type} id=${h.id} body=${h.bodyLen}B")

        if (h.type == MessageType.REGISTER.wireValue) {
            conn.type = parseClientType(body)
            Log.i(TAG, "register: id=${conn.id} -> ${conn.type.name.lowercase()}")
            publishState()
        } else {
            when (conn.type) {
                ClientType.VIETMAP, ClientType.GOOGLEMAP ->
                    if (h.type == MessageType.NAVIGATION.wireValue) relayNavigation(conn, body)
                ClientType.MAZDA ->
                    Log.i(TAG, "mazda: inbound type=${h.type} id=${h.id} (${body.size}B)")
                ClientType.UNKNOWN ->
                    Log.w(TAG, "message from unregistered id=${conn.id} (type=${h.type})")
            }
        }

        // Surface every inbound message to the app layer (observability +
        // request/response handling such as request-file).
        _requests.tryEmit(
            RequestEvent(fd = conn.id, type = h.type, id = h.id, body = String(body, Charsets.UTF_8)),
        )
    }

    private fun parseClientType(body: ByteArray): ClientType {
        val text = String(body, Charsets.UTF_8)
        val role = try {
            JSONObject(text).optString("clientType")
        } catch (e: Exception) {
            ""
        }
        return when (role.lowercase()) {
            "mazda" -> ClientType.MAZDA
            "vietmap" -> ClientType.VIETMAP
            "googlemap", "google" -> ClientType.GOOGLEMAP
            else -> ClientType.UNKNOWN
        }
    }

    private fun relayNavigation(conn: Conn, body: ByteArray) {
        // Server-side map switch: relay only the source the user selected on the main screen.
        val selected = _navSource.value.clientType
        if (conn.type != selected) {
            Log.i(TAG, "drop navigation from ${conn.type.name.lowercase()} " +
                "(selected=${_navSource.value.name.lowercase()})")
            return
        }
        val hudJson = Navigation.clampToHudJson(String(body, Charsets.UTF_8))
        if (hudJson == null) {
            Log.w(TAG, "${conn.type.name.lowercase()}: bad navigation JSON from id=${conn.id}")
            return
        }
        val reached = sendToType(ClientType.MAZDA, MessageType.NAVIGATION, hudJson)
        Log.i(TAG, "${conn.type.name.lowercase()}: navigation -> $reached mazda client(s)")
    }

    // ====================================================================
    //  Outbound — the API the UI calls
    // ====================================================================

    /** Broadcast a JSON message to every client. Returns how many it reached. */
    fun sendMessage(type: MessageType, json: String): Int =
        writeToMany(clients.values, encodeJsonMessage(type, json, nextMsgId.getAndIncrement()))

    /** Send a JSON message to one client by its id (the UI's "fd"). */
    fun sendMessageTo(fd: Int, type: MessageType, json: String): Int {
        val conn = clients[fd] ?: return 0
        return if (conn.write(encodeJsonMessage(type, json, nextMsgId.getAndIncrement()))) 1 else 0
    }

    /** Route a Navigation JSON message to every registered mazda client. */
    fun sendNavigationToMazda(json: String): Int =
        sendToType(ClientType.MAZDA, MessageType.NAVIGATION, json)

    /** Send a JSON message to every client of a role. */
    fun sendToType(type: ClientType, msgType: MessageType, json: String): Int =
        writeToMany(
            clients.values.filter { it.type == type },
            encodeJsonMessage(msgType, json, nextMsgId.getAndIncrement()),
        )

    /** Stream a file (FileBegin/Chunk/End) to every client. */
    fun sendFile(filePath: String, mime: String = "application/octet-stream"): Int =
        streamFile(filePath, mime) { bytes -> writeToMany(clients.values, bytes) }

    /** Stream a file to one client by id. */
    fun sendFileTo(fd: Int, filePath: String, mime: String = "application/octet-stream"): Int =
        streamFile(filePath, mime) { bytes ->
            val conn = clients[fd] ?: return@streamFile 0
            if (conn.write(bytes)) 1 else 0
        }

    /** Stream a file to every client of a role. */
    fun sendFileToType(type: ClientType, filePath: String, mime: String): Int =
        streamFile(filePath, mime) { bytes ->
            writeToMany(clients.values.filter { it.type == type }, bytes)
        }

    /**
     * Push a system upgrade to every mazda client: an Upgrade metadata message
     * ({command, fileName, size}) followed by the file stream.
     */
    fun sendUpgradeToMazda(
        filePath: String,
        command: String,
        mime: String = "application/octet-stream",
    ): Int {
        val file = File(filePath)
        val size = if (file.exists()) file.length() else 0L
        val json = JSONObject()
            .put("command", command)
            .put("fileName", file.name)
            .put("size", size)
            .toString()
        val delivered = sendToType(ClientType.MAZDA, MessageType.UPGRADE, json)
        sendFileToType(ClientType.MAZDA, filePath, mime)
        Log.i(TAG, "upgrade '${file.name}' ($size B) cmd='$command' -> $delivered mazda client(s)")
        return delivered
    }

    // ====================================================================
    //  Low-level send + file streaming
    // ====================================================================

    private fun writeToMany(conns: Collection<Conn>, bytes: ByteArray): Int {
        var delivered = 0
        for (conn in conns) if (conn.write(bytes)) delivered++
        return delivered
    }

    /** Emits FileBegin (JSON) / FileChunk (64 KB binary) / FileEnd; returns the FileBegin count. */
    private fun streamFile(filePath: String, mime: String, sink: (ByteArray) -> Int): Int {
        val file = File(filePath)
        if (!file.exists()) {
            Log.w(TAG, "streamFile: cannot open $filePath")
            return 0
        }
        val fileId = nextMsgId.getAndIncrement()
        val size = file.length()

        val beginJson = JSONObject()
            .put("name", file.name)
            .put("size", size)
            .put("mime", mime)
            .toString()
        val delivered =
            sink(encodeEnvelope(MessageType.FILE_BEGIN.wireValue, beginJson.toByteArray(Charsets.UTF_8), id = fileId))

        var chunks = 0
        file.inputStream().use { input ->
            val buffer = ByteArray(CHUNK_SIZE)
            while (true) {
                val got = input.read(buffer)
                if (got <= 0) break
                sink(
                    encodeEnvelope(
                        MessageType.FILE_CHUNK.wireValue,
                        buffer.copyOf(got),
                        id = fileId,
                        binary = true,
                    ),
                )
                chunks++
            }
        }

        sink(encodeEnvelope(MessageType.FILE_END.wireValue, ByteArray(0), id = fileId))
        Log.i(TAG, "streamFile: ${file.name} ($size B, $chunks chunks) fileId=$fileId -> $delivered")
        return delivered
    }

    // ====================================================================
    //  State publishing
    // ====================================================================

    private fun publishState() {
        val connectors = clients.values
            .sortedBy { it.id }
            .map { Connector(ip = it.ip, port = it.port, fd = it.id, type = it.type) }
        _state.value = EngineState(
            running = serverSocket != null && started,
            port = PORT,
            connectors = connectors,
        )
    }
}
