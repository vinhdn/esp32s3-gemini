package com.rongcondihoc.vegvisir.domain

/**
 * The role a connected client plays, declared once via a Register message.
 * [wireValue] is a VEG1 wire constant shared with the mazda client and the
 * vietmap hook (both C++) — keep it in sync.
 */
enum class ClientType(val wireValue: Int) {
    UNKNOWN(0),
    MAZDA(1),      // receives navigation guidance + system upgrades
    VIETMAP(2),    // sends navigation info to the server
    GOOGLEMAP(3);  // sends navigation info to the server (defined later)

    /** True for roles that produce navigation (map apps), i.e. non-mazda sources. */
    val isProvider: Boolean get() = this == VIETMAP || this == GOOGLEMAP

    /** Human-readable name shown in the UI. */
    val displayName: String
        get() = when (this) {
            MAZDA -> "Mazda head unit"
            VIETMAP -> "VietMap"
            GOOGLEMAP -> "Google Maps"
            UNKNOWN -> "Unknown"
        }

    companion object {
        fun fromWire(value: Int): ClientType =
            entries.firstOrNull { it.wireValue == value } ?: UNKNOWN
    }
}
