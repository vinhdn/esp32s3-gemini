package com.rongcondihoc.vegvisir.service

import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge

/**
 * Is the LSPosed injection stack actually active for THIS app — i.e. is our Xposed module being
 * injected into our own process? That is the "hook granted" signal the UI needs before it can tell
 * whether VietMap will ever connect.
 *
 * Detected with the canonical self-hook test, no root required: hook a private [sentinel] method
 * that returns false so it instead returns true, then call it. If the value flipped, LSPosed is
 * injecting this process, which only happens when Zygisk is on AND the `zygisk_lsposed` module is
 * enabled AND our module is enabled and scoped (our own package is in `xposed_scope`).
 *
 * When the framework is off/disabled, `de.robv.android.xposed.*` was never injected here, so merely
 * touching [XposedBridge] throws `NoClassDefFoundError` — caught and reported as "not active".
 *
 * The result is cached: activation cannot change without a process restart (LSPosed injects at fork).
 */
object LposedStatus {

    @Volatile
    private var cached: Boolean? = null

    /** True when this process is LSPosed-injected (the hook is "granted"). Never throws. */
    fun isModuleActive(): Boolean {
        cached?.let { return it }
        val active = try {
            probe()
        } catch (t: Throwable) {
            // NoClassDefFoundError (framework absent) or any hook failure -> treat as inactive.
            false
        }
        cached = active
        return active
    }

    private fun probe(): Boolean {
        val method = LposedStatus::class.java.getDeclaredMethod("sentinel")
        XposedBridge.hookMethod(method, object : XC_MethodHook() {
            override fun beforeHookedMethod(param: XC_MethodHook.MethodHookParam) {
                param.result = true
            }
        })
        return sentinel()
    }

    // Effectively always false, but written so the compiler cannot const-fold/inline it at the
    // call site — the self-hook must be the only thing that can flip its result to true.
    private fun sentinel(): Boolean = System.nanoTime() == 0L
}
