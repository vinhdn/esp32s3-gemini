package com.rongcondihoc.vegvisir.domain

/** A message received from a client, surfaced from the native layer. */
data class RequestEvent(
    val fd: Int,        // the client connection it arrived on (reply target)
    val type: Int,      // MessageType wire value
    val id: Int,        // sender's message id
    val body: String,   // decoded body (JSON/text)
)
