package com.rongcondihoc.vegvisir.service.vietmap

import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Best-effort file logger for the hook, running INSIDE vn.vietmap.live. It writes into THAT app's
 * external files dir, so pull the output with:
 *   adb pull /sdcard/Android/data/vn.vietmap.live/files/vegvisir-log
 *
 * One session folder per process run (named by the run's start time) so runs don't intermix. It
 * offers two sinks into that folder:
 *   - [line]      append one timestamped text line to `vegvisir.log` (the running trace)
 *   - [saveBytes] write one raw payload (e.g. an API body) to its own file
 *
 * Everything is silent on I/O failure — logging must never disturb the target app.
 */
object FileLog {

    private const val TAG = "VietMapHook"

    private val sessionStart = System.currentTimeMillis()
    private val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)

    @Volatile
    private var dirCache: File? = null
    private var seq = 0

    /** The per-run session dir (lazily created), or null if no writable location is found. */
    @Synchronized
    private fun dir(): File? {
        dirCache?.let { return it }
        val base = try {
            val app = android.app.AndroidAppHelper.currentApplication()
            app?.getExternalFilesDir(null) ?: app?.filesDir
        } catch (t: Throwable) {
            null
        } ?: return null
        val d = File(base, "vegvisir-log/session-$sessionStart")
        if (!d.exists()) d.mkdirs()
        dirCache = d
        return d
    }

    /** Append one timestamped line to `vegvisir.log`. Silently no-ops on any I/O failure. */
    @Synchronized
    fun line(msg: String) {
        val d = dir() ?: return
        try {
            File(d, "vegvisir.log").appendText("${stamp.format(Date())}  $msg\n")
        } catch (t: Throwable) {
            Log.e(TAG, "file log failed: $t")
        }
    }

    /**
     * Write [bytes] to `{ts}_{seq}_{slug}.{ext}` in the session dir. [slug] is sanitised to a safe
     * filename; returns nothing and silently no-ops on any I/O failure.
     */
    @Synchronized
    fun saveBytes(slug: String, ext: String, bytes: ByteArray) {
        val d = dir() ?: return
        val safe = slug.replace(Regex("[^A-Za-z0-9._-]"), "_").take(60).ifEmpty { "data" }
        try {
            File(d, "${System.currentTimeMillis()}_${seq++}_$safe.$ext").writeBytes(bytes)
        } catch (t: Throwable) {
            Log.e(TAG, "file save failed for $slug: $t")
        }
    }
}
