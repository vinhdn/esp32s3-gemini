package com.rongcondihoc.vegvisir.service

import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executor

/**
 * Injects synthetic GPS inside vn.vietmap.live so navigation can be exercised on a
 * bench with no real fix. It hooks [LocationManager] to (1) capture every
 * [LocationListener] the app registers and (2) answer getLastKnownLocation, then a
 * background engine drives a position from START to END (chợ Bến Thành), feeding
 * each registered listener once per second — exactly how the app's real 1 Hz gps
 * request is served.
 *
 * Opt-in and controllable via flag files in the app's own files dir (create them as
 * root over adb; the app can read them):
 *   mock_gps.enable  — must exist at process start, else this stays completely dormant
 *   mock_gps.conf    — optional "start=lat,lng / end=lat,lng / steps=N / intervalMs=M"
 *   mock_go          — while absent the position holds at START; touch it to start moving
 *
 * All work is wrapped so a failure can never crash the host app.
 */
object GpsMock {

    private const val TAG = "VietmapGps"
    private const val DIR = "/data/data/vn.vietmap.live/files"

    // Chợ Bến Thành (destination) and a start point ~2 km out on the road grid.
    private val defaultStart = doubleArrayOf(10.7592, 106.6820)
    private val defaultEnd = doubleArrayOf(10.77216, 106.69804)

    private class Reg(val listener: LocationListener, val handler: Handler?, val executor: Executor?)

    private val regs = CopyOnWriteArrayList<Reg>()

    @Volatile
    private var current: Location? = null

    @Volatile
    private var installed = false

    /** Install only when the enable flag exists, so normal GPS is untouched otherwise. */
    fun installIfEnabled() {
        try {
            if (installed) return
            if (!File("$DIR/mock_gps.enable").exists()) {
                Log.d(TAG, "mock disabled (no enable flag) — real GPS untouched")
                return
            }
            installed = true
            hookLocationManager()
            startEngine()
            Log.d(TAG, "GPS mock installed")
        } catch (t: Throwable) {
            Log.e(TAG, "install failed: $t")
        }
    }

    private fun hookLocationManager() {
        val lm = LocationManager::class.java

        // Capture the app's listeners from every requestLocationUpdates overload.
        for (m in lm.methods.filter { it.name == "requestLocationUpdates" }) {
            XposedBridge.hookMethod(m, object : XC_MethodHook() {
                override fun afterHookedMethod(param: XC_MethodHook.MethodHookParam) {
                    try {
                        capture(param.args)
                    } catch (t: Throwable) {
                        Log.e(TAG, "capture failed: $t")
                    }
                }
            })
        }
        // Drop listeners the app removes.
        for (m in lm.methods.filter { it.name == "removeUpdates" }) {
            XposedBridge.hookMethod(m, object : XC_MethodHook() {
                override fun afterHookedMethod(param: XC_MethodHook.MethodHookParam) {
                    val l = param.args.firstOrNull { it is LocationListener } as? LocationListener ?: return
                    regs.removeAll { it.listener === l }
                }
            })
        }
        // Answer last-known-location with our synthetic point.
        for (m in lm.methods.filter { it.name == "getLastKnownLocation" }) {
            XposedBridge.hookMethod(m, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: XC_MethodHook.MethodHookParam) {
                    current?.let { param.result = clone(it) }
                }
            })
        }
    }

    private fun capture(args: Array<Any?>) {
        var listener: LocationListener? = null
        var looper: Looper? = null
        var executor: Executor? = null
        for (a in args) {
            when (a) {
                is LocationListener -> listener = a
                is Looper -> looper = a
                is Executor -> executor = a
            }
        }
        val l = listener ?: return
        if (regs.any { it.listener === l }) return
        val handler = when {
            looper != null -> Handler(looper)
            executor != null -> null
            else -> Handler(Looper.getMainLooper())
        }
        regs.add(Reg(l, handler, executor))
        Log.d(TAG, "captured listener (${regs.size} total)")
    }

    private fun startEngine() {
        Thread({
            try {
                val cfg = readConf()
                val start = cfg.start
                val end = cfg.end
                val steps = cfg.steps
                val goFile = File("$DIR/mock_go")

                var moving = false
                var i = 0
                while (true) {
                    if (!moving) {
                        current = makeLocation(start[0], start[1], 0f, bearing(start, end))
                        dispatch()
                        if (goFile.exists()) {
                            moving = true
                            Log.d(TAG, "go flag seen — moving toward Bến Thành")
                        }
                    } else if (i >= steps) {
                        current = makeLocation(end[0], end[1], 0f, bearing(start, end))
                        dispatch()  // arrived — hold at destination
                    } else {
                        val t = i.toDouble() / steps
                        val lat = start[0] + (end[0] - start[0]) * t
                        val lng = start[1] + (end[1] - start[1]) * t
                        current = makeLocation(lat, lng, speedMps(start, end, steps, cfg.intervalMs),
                                               bearing(start, end))
                        dispatch()
                        i++
                    }
                    Thread.sleep(cfg.intervalMs)
                }
            } catch (t: Throwable) {
                Log.e(TAG, "engine stopped: $t")
            }
        }, "vietmap-gps").apply { isDaemon = true }.start()
    }

    private fun dispatch() {
        val c = current ?: return
        for (r in regs) {
            val loc = clone(c)
            val run = Runnable {
                try {
                    r.listener.onLocationChanged(loc)
                } catch (_: Throwable) {
                }
            }
            try {
                when {
                    r.executor != null -> r.executor.execute(run)
                    r.handler != null -> r.handler.post(run)
                    else -> run.run()
                }
            } catch (_: Throwable) {
            }
        }
    }

    private fun makeLocation(lat: Double, lng: Double, speed: Float, bearingDeg: Float): Location {
        val l = Location(LocationManager.GPS_PROVIDER)
        l.latitude = lat
        l.longitude = lng
        l.altitude = 10.0
        l.accuracy = 5f
        l.speed = speed
        l.bearing = bearingDeg
        l.time = System.currentTimeMillis()
        l.elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            l.speedAccuracyMetersPerSecond = 1f
            l.bearingAccuracyDegrees = 5f
            l.verticalAccuracyMeters = 5f
        }
        return l
    }

    private fun clone(src: Location): Location =
        Location(src).apply {
            time = System.currentTimeMillis()
            elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
        }

    // --- geometry --------------------------------------------------------
    private fun bearing(a: DoubleArray, b: DoubleArray): Float {
        val lat1 = Math.toRadians(a[0]); val lat2 = Math.toRadians(b[0])
        val dLon = Math.toRadians(b[1] - a[1])
        val y = Math.sin(dLon) * Math.cos(lat2)
        val x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon)
        return ((Math.toDegrees(Math.atan2(y, x)) + 360.0) % 360.0).toFloat()
    }

    private fun distanceMeters(a: DoubleArray, b: DoubleArray): Double {
        val r = 6371000.0
        val dLat = Math.toRadians(b[0] - a[0]); val dLon = Math.toRadians(b[1] - a[1])
        val s = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(Math.toRadians(a[0])) * Math.cos(Math.toRadians(b[0])) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2)
        return r * 2 * Math.atan2(Math.sqrt(s), Math.sqrt(1 - s))
    }

    private fun speedMps(start: DoubleArray, end: DoubleArray, steps: Int, intervalMs: Long): Float {
        val total = distanceMeters(start, end)
        val seconds = steps * (intervalMs / 1000.0)
        return if (seconds > 0) (total / seconds).toFloat() else 10f
    }

    // --- config ----------------------------------------------------------
    private class Conf(
        val start: DoubleArray,
        val end: DoubleArray,
        val steps: Int,
        val intervalMs: Long,
    )

    private fun readConf(): Conf {
        var start = defaultStart
        var end = defaultEnd
        var steps = 120
        var intervalMs = 1000L
        try {
            val f = File("$DIR/mock_gps.conf")
            if (f.exists()) {
                for (line in f.readLines()) {
                    val kv = line.split("=", limit = 2)
                    if (kv.size != 2) continue
                    val k = kv[0].trim(); val v = kv[1].trim()
                    when (k) {
                        "start" -> parsePoint(v)?.let { start = it }
                        "end" -> parsePoint(v)?.let { end = it }
                        "steps" -> v.toIntOrNull()?.let { steps = it }
                        "intervalMs" -> v.toLongOrNull()?.let { intervalMs = it }
                    }
                }
            }
        } catch (t: Throwable) {
            Log.e(TAG, "conf read failed: $t")
        }
        Log.d(TAG, "route start=${start[0]},${start[1]} end=${end[0]},${end[1]} steps=$steps")
        return Conf(start, end, steps, intervalMs)
    }

    private fun parsePoint(s: String): DoubleArray? {
        val p = s.split(",")
        val lat = p.getOrNull(0)?.trim()?.toDoubleOrNull() ?: return null
        val lng = p.getOrNull(1)?.trim()?.toDoubleOrNull() ?: return null
        return doubleArrayOf(lat, lng)
    }
}
