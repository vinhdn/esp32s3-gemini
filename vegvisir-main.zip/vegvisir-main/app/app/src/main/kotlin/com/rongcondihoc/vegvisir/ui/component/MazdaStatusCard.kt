package com.rongcondihoc.vegvisir.ui.component

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rongcondihoc.vegvisir.domain.Connector

/**
 * Mazda head unit card: the connection state of the vegvisir-client running on the car.
 * It is only tappable while the unit is connected — tapping pushes its detail page
 * (the HUD navigation test panel).
 */
@Composable
fun MazdaStatusCard(
    client: Connector?,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val connected = client != null

    Card(
        modifier = modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(enabled = connected, onClick = onOpen)
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            StatusDot(connected = connected)
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Mazda head unit", style = MaterialTheme.typography.titleMedium)
                Text(
                    text = if (client != null) {
                        "Connected · ${client.ip} · port ${client.port}"
                    } else {
                        "Not connected"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (connected) {
                Icon(
                    Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
