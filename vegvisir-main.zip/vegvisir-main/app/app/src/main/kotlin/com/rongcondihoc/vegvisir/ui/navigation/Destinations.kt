package com.rongcondihoc.vegvisir.ui.navigation

import com.rongcondihoc.vegvisir.domain.ClientType

/** Navigation routes for the app (push/pop stack). */
object Routes {
    const val MAIN = "main"
    const val NAV_SOURCE = "nav-source"

    // Detail page for one connected client, keyed by its ROLE rather than its connection id: a
    // client that drops and redials gets a new id, and the open page should follow the role.
    const val CLIENT = "client/{type}"
    fun client(type: ClientType) = "client/${type.name}"

    fun clientType(arg: String?): ClientType =
        ClientType.entries.firstOrNull { it.name == arg } ?: ClientType.UNKNOWN
}
