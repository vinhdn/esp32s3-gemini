package com.rongcondihoc.vegvisir.service

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.HandlerThread
import android.util.Log

/**
 * The live position source for route guidance, running INSIDE vn.vietmap.live.
 *
 * It registers a real [LocationManager] GPS listener (the host app already holds the
 * fine-location permission) and republishes each fix to [RouteGuide]. Because it listens
 * on the standard [LocationManager], it also picks up [GpsMock]'s synthetic fixes for free
 * on the bench — GpsMock captures every registered listener, so no special wiring is needed.
 *
 * All work is wrapped so a failure here can never crash the host app.
 */
object GpsService {

    private const val TAG = "VietMapHook"

    // 1 Hz — matches VietMap's own gps cadence and the HUD's countdown granularity.
    private const val MIN_TIME_MS = 1000L
    private const val MIN_DISTANCE_M = 0f

    // The application context is not ready at handleLoadPackage; poll for it briefly.
    private const val CTX_RETRIES = 40
    private const val CTX_RETRY_DELAY_MS = 500L

    fun interface FixListener {
        fun onFix(location: Location)
    }

    @Volatile
    private var last: Location? = null

    @Volatile
    private var started = false

    /** Latest known fix, or null before the first one arrives. */
    fun last(): Location? = last

    /**
     * Begin listening for GPS fixes and forward each to [listener]. Idempotent. Registration
     * is deferred to a background thread that waits for the host Application to come up.
     */
    fun start(listener: FixListener) {
        if (started) return
        started = true
        val worker = HandlerThread("vegvisir-gps-service").apply { start() }
        Thread({
            try {
                val ctx = awaitContext() ?: run {
                    Log.w(TAG, "gps: no application context — guidance disabled")
                    return@Thread
                }
                register(ctx, worker, listener)
            } catch (t: Throwable) {
                Log.e(TAG, "gps: start failed: $t")
            }
        }, "vegvisir-gps-init").apply { isDaemon = true }.start()
    }

    @SuppressLint("MissingPermission")
    private fun register(ctx: Context, worker: HandlerThread, listener: FixListener) {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: run {
            Log.w(TAG, "gps: no LocationManager")
            return
        }

        val cb = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                last = location
                try {
                    listener.onFix(location)
                } catch (t: Throwable) {
                    Log.e(TAG, "gps: fix handler failed: $t")
                }
            }

            // Older API signatures — no-ops, but required by some platform versions.
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
            @Deprecated("deprecated in API 29")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }

        // Seed with the last known fix so guidance can start before the first live update.
        try {
            lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { last = it }
        } catch (_: Throwable) {
        }

        // GPS is the primary source; network is a best-effort fallback (each is optional).
        for (provider in arrayOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            try {
                lm.requestLocationUpdates(provider, MIN_TIME_MS, MIN_DISTANCE_M, cb, worker.looper)
                Log.d(TAG, "gps: listening on $provider")
            } catch (t: Throwable) {
                Log.w(TAG, "gps: cannot listen on $provider: $t")
            }
        }
    }

    /** Poll for the host Application context, which is not yet built at hook-install time. */
    private fun awaitContext(): Context? {
        repeat(CTX_RETRIES) {
            val app = try {
                android.app.AndroidAppHelper.currentApplication()
            } catch (_: Throwable) {
                null
            }
            if (app != null) return app
            try {
                Thread.sleep(CTX_RETRY_DELAY_MS)
            } catch (_: InterruptedException) {
                return null
            }
        }
        return null
    }
}
