package com.rongcondihoc.vegvisir.ui.screen.client

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rongcondihoc.vegvisir.domain.ClientType
import com.rongcondihoc.vegvisir.domain.Connector
import com.rongcondihoc.vegvisir.domain.MessageType
import com.rongcondihoc.vegvisir.server.ServerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Detail page for a mazda head unit.
 *
 * Besides identifying the connection, it carries a NAVIGATION TEST PANEL: each
 * button sends one Navigation (HUD-sink JSON) message to THIS unit's fd, so every
 * HUD glyph can be exercised on the cluster. The unit's hudnav provider decodes
 * the message and drives com.jci.vbs.navi exactly as if it came from a real route.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MazdaClientScreen(
    client: Connector?,
    onBack: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var lastResult by remember { mutableStateOf<String?>(null) }
    // The unit can drop while this page is open; the test panel then has nowhere to send.
    val connected = client != null

    fun send(case: NavCase) {
        val fd = client?.fd ?: return
        sendNav(scope, fd, case) { lastResult = it }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(ClientType.MAZDA.displayName) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { inner ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = if (client != null) {
                    "Connected · ${client.ip} · port ${client.port} · fd ${client.fd}"
                } else {
                    "Not connected — the head unit dropped its socket"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("Navigation test", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Send a single maneuver to this unit's HUD. Each button maps to one " +
                            "glyph; roundabout buttons step the exit bearing through all 12 " +
                            "sectors per side.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    // Stop / clear guidance — full width, emphasized.
                    Button(
                        onClick = { send(NavCase("Clear (active:false)", CLEAR_JSON)) },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = connected,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer,
                            contentColor = MaterialTheme.colorScheme.onErrorContainer,
                        ),
                    ) {
                        Text("Clear HUD (guidance off)")
                    }
                    lastResult?.let {
                        Text(
                            it,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            navTestSections().forEach { (title, cases) ->
                Section(title, cases, connected, ::send)
            }
        }
    }
}

// ============================================================================
//  Test model
// ============================================================================

/** One test maneuver: a button [label] and the exact Navigation JSON it sends. */
private data class NavCase(val label: String, val json: String)

// NavSide wire values (see the client's nav model).
private const val L = 1     // left
private const val R = 2     // right
private const val S = 3     // none / straight

// NavEvent wire values.
private const val EV_DEPART = 1
private const val EV_NAME_CHANGE = 2
private const val EV_SLIGHT = 3
private const val EV_TURN = 4
private const val EV_SHARP = 5
private const val EV_UTURN = 6
private const val EV_ON_RAMP = 7
private const val EV_OFF_RAMP = 8
private const val EV_FORK = 9
private const val EV_MERGE = 10
private const val EV_ROUNDABOUT = 13
private const val EV_STRAIGHT = 14
private const val EV_FERRY = 16
private const val EV_DEST = 19

private const val CLEAR_JSON = """{"active":false}"""

/** Build one Navigation (HUD-sink schema) body. Distance defaults to 300 m. */
private fun navJson(
    event: Int,
    side: Int = S,
    angle: Int = 0,
    number: Int = 0,
    road: String = "Nguyễn Huệ",
    distance: Int = 300,
    unit: Int = 1,   // 1 = metres
    eta: Int = 30,
    speedLimit: Int = 0,   // km/h; 0 = no posted limit
): String =
    """{"active":true,"event":$event,"side":$side,"angle":$angle,"number":$number,""" +
        """"road":"$road","distance":$distance,"unit":$unit,"eta":$eta,""" +
        """"speedLimit":$speedLimit}"""

/** Roundabout: 12 exit-bearing sectors (0..330° step 30°) for one side. */
private fun roundaboutCases(side: Int, tag: String): List<NavCase> =
    (0 until 360 step 30).mapIndexed { i, deg ->
        NavCase(
            "RA $tag ${deg}°",
            navJson(EV_ROUNDABOUT, side = side, angle = deg, number = i + 1, road = "Vòng xuyến"),
        )
    }

/** All test groups, in display order. Covers every non-blank HUD glyph. */
private fun navTestSections(): List<Pair<String, List<NavCase>>> = listOf(
    "Basic" to listOf(
        NavCase("Straight", navJson(EV_STRAIGHT)),
        NavCase("Name change", navJson(EV_NAME_CHANGE)),
        NavCase("Depart ahead", navJson(EV_DEPART, S)),
        NavCase("Depart left", navJson(EV_DEPART, L)),
        NavCase("Depart right", navJson(EV_DEPART, R)),
        NavCase("Destination ahead", navJson(EV_DEST, S)),
        NavCase("Destination left", navJson(EV_DEST, L)),
        NavCase("Destination right", navJson(EV_DEST, R)),
        NavCase("Ferry", navJson(EV_FERRY)),
    ),
    "Turns" to listOf(
        NavCase("Turn left", navJson(EV_TURN, L)),
        NavCase("Turn right", navJson(EV_TURN, R)),
        NavCase("Slight left", navJson(EV_SLIGHT, L)),
        NavCase("Slight right", navJson(EV_SLIGHT, R)),
        NavCase("Sharp left", navJson(EV_SHARP, L)),
        NavCase("Sharp right", navJson(EV_SHARP, R)),
        NavCase("U-turn left", navJson(EV_UTURN, L)),
        NavCase("U-turn right", navJson(EV_UTURN, R)),
    ),
    "Ramp / fork / merge" to listOf(
        NavCase("On-ramp left", navJson(EV_ON_RAMP, L)),
        NavCase("On-ramp right", navJson(EV_ON_RAMP, R)),
        NavCase("Off-ramp left", navJson(EV_OFF_RAMP, L)),
        NavCase("Off-ramp right", navJson(EV_OFF_RAMP, R)),
        NavCase("Fork left", navJson(EV_FORK, L)),
        NavCase("Fork right", navJson(EV_FORK, R)),
        NavCase("Merge left", navJson(EV_MERGE, L)),
        NavCase("Merge right", navJson(EV_MERGE, R)),
    ),
    "Roundabout · right-hand" to roundaboutCases(R, "R"),
    "Roundabout · left-hand" to roundaboutCases(L, "L"),
    "Distance / unit" to listOf(
        NavCase("50 m", navJson(EV_TURN, L, distance = 50, unit = 1)),
        NavCase("300 m", navJson(EV_TURN, R, distance = 300, unit = 1)),
        NavCase("1.2 km", navJson(EV_TURN, L, distance = 1200, unit = 3)),
        NavCase("12 km", navJson(EV_STRAIGHT, distance = 12000, unit = 3)),
    ),
    // Posted speed-limit sign. Rides the same Navigation message alongside a
    // benign straight maneuver; 0 blanks the sign.
    "Speed limit (km/h)" to listOf(
        NavCase("30", navJson(EV_STRAIGHT, speedLimit = 30)),
        NavCase("40", navJson(EV_STRAIGHT, speedLimit = 40)),
        NavCase("50", navJson(EV_STRAIGHT, speedLimit = 50)),
        NavCase("60", navJson(EV_STRAIGHT, speedLimit = 60)),
        NavCase("80", navJson(EV_STRAIGHT, speedLimit = 80)),
        NavCase("100", navJson(EV_STRAIGHT, speedLimit = 100)),
        NavCase("120", navJson(EV_STRAIGHT, speedLimit = 120)),
        NavCase("No limit (0)", navJson(EV_STRAIGHT, speedLimit = 0)),
    ),
)

// ============================================================================
//  UI helpers
// ============================================================================

@Composable
private fun Section(
    title: String,
    cases: List<NavCase>,
    enabled: Boolean,
    onSend: (NavCase) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            title,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary,
        )
        // Two buttons per row.
        cases.chunked(2).forEach { rowCases ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowCases.forEach { case ->
                    OutlinedButton(
                        onClick = { onSend(case) },
                        modifier = Modifier.weight(1f),
                        enabled = enabled,
                    ) {
                        Text(case.label, style = MaterialTheme.typography.labelMedium)
                    }
                }
                if (rowCases.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

// The native send is blocking, so run it off the main thread and report the fd
// and delivery count back to the caller.
private fun sendNav(
    scope: CoroutineScope,
    fd: Int,
    case: NavCase,
    onResult: (String) -> Unit,
) {
    scope.launch(Dispatchers.IO) {
        val n = ServerEngine.sendMessageTo(fd, MessageType.NAVIGATION, case.json)
        onResult("Sent \"${case.label}\" -> fd $fd (delivered=$n)")
    }
}
