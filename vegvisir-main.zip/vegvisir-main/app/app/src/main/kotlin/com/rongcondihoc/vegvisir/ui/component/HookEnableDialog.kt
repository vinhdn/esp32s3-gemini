package com.rongcondihoc.vegvisir.ui.component

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Shown when the user picks VietMap but the LSPosed hook is not active for this device. Confirming
 * runs the root recovery ([com.rongcondihoc.vegvisir.service.HookInstaller]) and reboots.
 *
 * @param fixing true while the recovery script is running (the device is about to reboot).
 */
@Composable
fun HookEnableDialog(
    fixing: Boolean,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = { if (!fixing) onCancel() },
        title = { Text("Bật VietMap hook?") },
        text = {
            Text(
                "VietMap hook chưa được bật nên chưa thể nhận dẫn đường. Đồng ý để bật hook " +
                    "(Zygisk + LSPosed) rồi khởi động lại thiết bị. Sau khi khởi động lại, hãy mở " +
                    "VietMap để bắt đầu.",
            )
        },
        confirmButton = {
            TextButton(onClick = onConfirm, enabled = !fixing) {
                if (fixing) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(8.dp))
                        Text("Đang bật…")
                    }
                } else {
                    Text("Đồng ý")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onCancel, enabled = !fixing) { Text("Hủy") }
        },
    )
}
