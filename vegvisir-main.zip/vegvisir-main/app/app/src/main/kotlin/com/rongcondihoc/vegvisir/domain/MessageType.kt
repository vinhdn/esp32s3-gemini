package com.rongcondihoc.vegvisir.domain

/**
 * Message types carried over the connection.
 * [wireValue] must match the VEG1 envelope wire values spoken by the mazda
 * client (vegvisir-client) and the vietmap hook (both C++).
 */
enum class MessageType(val wireValue: Int) {
    NAVIGATION(1),   // maneuver / route guidance (HUD-sink JSON schema)
    UPGRADE(2),      // upgrade package info (metadata; file follows)
    FILE_BEGIN(3),   // { "name", "size", "mime" }; id = fileId
    FILE_CHUNK(4),   // one binary slice of the file; id = fileId
    FILE_END(5),     // end of file; id = fileId
    REQUEST(6),      // client -> server request
    RESPONSE(7),     // server -> client reply
    ERROR(9),        // { "message" }
    PING(10),
    PONG(11),
    REGISTER(12);    // client declares its role: { "clientType" }

    companion object {
        fun fromWire(value: Int): MessageType? = entries.firstOrNull { it.wireValue == value }
    }
}
