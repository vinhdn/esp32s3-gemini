package com.rongcondihoc.vegvisir

import android.app.Application
import com.rongcondihoc.vegvisir.service.VegvisirService

/**
 * The server no longer lives here. It runs in [VegvisirService] (a foreground service) so it
 * outlives the UI and can be brought up at boot by BootReceiver — see that class for the "VietMap
 * started first" rationale. Whenever the app process exists we make sure the service is running;
 * the actual server boot, NavSource restore, and request handling all happen inside the service.
 */
class VegvisirApp : Application() {
    override fun onCreate() {
        super.onCreate()
        VegvisirService.start(this)
    }
}
