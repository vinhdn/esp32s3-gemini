package com.rongcondihoc.vegvisir.ui.component

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Green when the peer is connected, muted otherwise. Shared by every status row. */
@Composable
fun StatusDot(connected: Boolean, modifier: Modifier = Modifier, size: Int = 12) {
    Spacer(
        modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(
                if (connected) CONNECTED_GREEN else MaterialTheme.colorScheme.outlineVariant,
            ),
    )
}

private val CONNECTED_GREEN = Color(0xFF2E7D32)
