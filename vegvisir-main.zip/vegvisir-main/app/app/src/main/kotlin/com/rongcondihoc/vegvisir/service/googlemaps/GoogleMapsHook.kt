package com.rongcondihoc.vegvisir.service.googlemaps

import android.util.Log
import com.rongcondihoc.vegvisir.service.GpsService
import com.rongcondihoc.vegvisir.service.RouteGuide
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam

/**
 * The Google Maps navigation provider, loaded by LSPosed into com.google.android.apps.maps. It is
 * the Google sibling of the VietMap hook and drives the SAME [RouteGuide] engine — only the sources
 * differ. It wires three data-based signals (no screen scraping):
 *
 *  1. **Start / End** — hooks Google's navigation foreground service
 *     `com.google.android.libraries.geo.navcore.service.base.NavigationService` (a stable, non-
 *     obfuscated navcore class). onStartCommand ⇒ a guidance session began; onDestroy ⇒ it ended,
 *     which clears the route so the HUD blanks. The service is foreground, so this fires whether or
 *     not the Maps UI is visible (it keeps running when Maps is backgrounded / screen off).
 *  2. **Steps** — the captured GMM directions protobuf, parsed by [GoogleRouteParser] into the
 *     standard NavRoute. The bytes are delivered by the Cronet capture layer via [onDirectionsBody].
 *  3. **Live data** — [RouteGuide] snaps GPS ([GpsService]) onto the route and emits one HUD frame
 *     per fix, exactly as it does for VietMap.
 *
 * Emitted frames leave this process over [GoogleServerClient] (pure-Kotlin VEG1 to the server),
 * since libvietmaphook's native client is not loaded here.
 *
 * Everything is best-effort and wrapped so a failure can never crash Google Maps.
 */
object GoogleMapsHook {

    private const val TAG = "GoogleMapsHook"

    // Google's navigation foreground service — the start/end lifecycle signal (stable class name).
    private const val NAV_SERVICE = "com.google.android.libraries.geo.navcore.service.base.NavigationService"

    @Volatile
    private var installed = false

    /** Arm the provider: transport, GPS→RouteGuide, and the navigation lifecycle hook. Idempotent. */
    fun install(lpparam: LoadPackageParam) {
        if (installed) return
        installed = true
        try {
            // Route emitted HUD frames out over the Kotlin VEG1 client (not the VietMap JNI path).
            RouteGuide.setSink { json -> GoogleServerClient.sendNavigation(json) }
            // Live position source: each fix drives RouteGuide, turning the captured route into one
            // HUD Navigation frame per update.
            GpsService.start { location -> RouteGuide.onLocation(location) }
            hookNavigationService(lpparam.classLoader)
            // Capture the GetDirections protobuf off Cronet's gRPC bidi stream → onDirectionsBody.
            GoogleCronetHook.install()
            Log.d(TAG, "armed on ${lpparam.packageName}")
        } catch (t: Throwable) {
            Log.e(TAG, "install error: $t")
        }
    }

    /**
     * Hook the navigation foreground service for the start/end lifecycle. onStartCommand marks a
     * session start (the route arrives separately via [onDirectionsBody]); onDestroy ends guidance
     * and clears the route, which makes RouteGuide emit the active:false frame that blanks the HUD.
     */
    private fun hookNavigationService(classLoader: ClassLoader?) {
        val cl = classLoader ?: return
        val svc = try {
            XposedHelpers.findClass(NAV_SERVICE, cl)
        } catch (t: Throwable) {
            Log.e(TAG, "NavigationService not found (nav lifecycle disabled): $t")
            return
        }
        XposedBridge.hookAllMethods(svc, "onStartCommand", object : XC_MethodHook() {
            override fun afterHookedMethod(param: MethodHookParam) {
                Log.i(TAG, "nav session start (NavigationService.onStartCommand)")
            }
        })
        XposedBridge.hookAllMethods(svc, "onDestroy", object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                Log.i(TAG, "nav session end (NavigationService.onDestroy) -> clear route")
                RouteGuide.setRoute(null)
            }
        })
        Log.d(TAG, "NavigationService lifecycle hooked")
    }

    /**
     * Capture entry: a whole, decompressed GMM directions protobuf response body. [GoogleCronetHook]
     * (the Cronet gRPC bidi-stream tap) calls this once per directions response; we parse it into the
     * standard route and arm guidance. A reroute is just a fresh body → a fresh route.
     */
    fun onDirectionsBody(body: ByteArray) {
        try {
            val route = GoogleRouteParser.parse(body)
            if (route == null) {
                Log.w(TAG, "directions body did not parse to a route (${body.size} B)")
                return
            }
            Log.i(TAG, "route captured: ${route.maneuvers.size} maneuvers, ${route.points.size} pts")
            RouteGuide.setRoute(route)
        } catch (t: Throwable) {
            Log.e(TAG, "onDirectionsBody failed: $t")
        }
    }
}
