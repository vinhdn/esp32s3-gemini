package com.rongcondihoc.vegvisir.ui.navigation

import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.rongcondihoc.vegvisir.domain.ClientType
import com.rongcondihoc.vegvisir.domain.NavSource
import com.rongcondihoc.vegvisir.ui.EngineViewModel
import com.rongcondihoc.vegvisir.ui.component.HookEnableDialog
import com.rongcondihoc.vegvisir.ui.screen.client.MazdaClientScreen
import com.rongcondihoc.vegvisir.ui.screen.client.NavProviderClientScreen
import com.rongcondihoc.vegvisir.ui.screen.main.MainScreen
import com.rongcondihoc.vegvisir.ui.screen.navsource.NavSourceScreen
import kotlinx.coroutines.launch

@Composable
fun VegvisirNavHost(viewModel: EngineViewModel = viewModel()) {
    val navController = rememberNavController()
    val state by viewModel.state.collectAsStateWithLifecycle()
    val navSource by viewModel.navSource.collectAsStateWithLifecycle()

    // "Enable VietMap hook?" recovery dialog: shown when VietMap is picked but its LSPosed hook is
    // not active for this device (Zygisk/LSPosed off). Confirming enables it via root and reboots.
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showHookDialog by remember { mutableStateOf(false) }
    var fixingHook by remember { mutableStateOf(false) }

    val onSelectSource: (NavSource) -> Unit = { source ->
        viewModel.selectNavSource(source)
        if (source == NavSource.VIETMAP &&
            !state.isConnected(ClientType.VIETMAP) &&
            !viewModel.isHookActive()
        ) {
            showHookDialog = true
        }
    }

    if (showHookDialog) {
        HookEnableDialog(
            fixing = fixingHook,
            onCancel = { if (!fixingHook) showHookDialog = false },
            onConfirm = {
                fixingHook = true
                scope.launch {
                    // On success the device reboots and this never returns; a return means failure.
                    val ok = viewModel.enableHookAndReboot()
                    fixingHook = false
                    showHookDialog = false
                    if (!ok) {
                        Toast.makeText(
                            context,
                            "Không bật được hook (cần cấp quyền root cho ứng dụng trong Magisk).",
                            Toast.LENGTH_LONG,
                        ).show()
                    }
                }
            },
        )
    }

    NavHost(navController = navController, startDestination = Routes.MAIN) {
        composable(Routes.MAIN) {
            MainScreen(
                state = state,
                navSource = navSource,
                onOpenMazda = { navController.navigate(Routes.client(ClientType.MAZDA)) },
                onOpenNavSource = { navController.navigate(Routes.NAV_SOURCE) },
            )
        }
        composable(Routes.NAV_SOURCE) {
            NavSourceScreen(
                selected = navSource,
                state = state,
                onSelect = onSelectSource,
                onOpenDetail = { navController.navigate(Routes.client(it)) },
                onBack = { navController.popBackStack() },
            )
        }
        composable(
            route = Routes.CLIENT,
            arguments = listOf(navArgument("type") { type = NavType.StringType }),
        ) { entry ->
            val type = Routes.clientType(entry.arguments?.getString("type"))
            // The client may drop while its page is open, so this is nullable by design; each
            // screen renders a disconnected state rather than popping under the user.
            val client = state.clientOf(type)
            // Two kinds of detail page: the mazda head unit vs a map-app provider.
            if (type == ClientType.MAZDA) {
                MazdaClientScreen(client = client, onBack = { navController.popBackStack() })
            } else {
                NavProviderClientScreen(
                    type = type,
                    client = client,
                    onBack = { navController.popBackStack() },
                )
            }
        }
    }
}
