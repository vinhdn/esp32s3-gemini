package com.rongcondihoc.vegvisir.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Starts [VegvisirService] at device boot so the VEG1 server is listening *before* the user ever
 * opens VietMap (or Vegvisir). This is what fixes the "VietMap ran first → no vietmap client"
 * case: the hook's loopback client finds the server already up on its first connect.
 *
 * NOTE: Android keeps a freshly installed app in the "stopped" state, so BOOT_COMPLETED is NOT
 * delivered until the app has been launched manually at least once after each (re)install.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON" -> {
                Log.i("Vegvisir", "boot: starting server service (${intent.action})")
                VegvisirService.start(context)
            }
        }
    }
}
