package com.rongcondihoc.vegvisir.service.googlemaps

import android.util.Log
import com.rongcondihoc.vegvisir.service.NavEvent
import com.rongcondihoc.vegvisir.service.NavManeuver
import com.rongcondihoc.vegvisir.service.NavRoute
import com.rongcondihoc.vegvisir.service.NavSide

/**
 * The Google Maps navigation provider: parses a **GetDirections** protobuf response into the
 * standard [NavRoute] that RouteGuide consumes — the Google sibling of VietMap's RouteParser. This
 * is the ONLY place that knows Google's wire format.
 *
 * The response is fetched by Google Maps over Cronet/gRPC; the capture layer
 * ([GoogleCronetHook]) de-frames the gRPC message and gunzips it, then hands the raw protobuf here.
 *
 * The schema was reverse-engineered + measured on ~2600 real steps (field numbers are inferred, not
 * a Google contract — they can change). Verified paths:
 *
 *   resp .1 .1 .2 (repeated) = route alternatives         · .1 .1 .8 (repeated) = polylines (parallel)
 *   polyline .1 / .2        = packed sint32 lat/lng deltas, ZIGZAG, scale 1e7 (the dense geometry)
 *   route .1 .3 .1          = total metres                · route .2 .2 .2 (repeated) = steps
 *   step .7                 = maneuver type   (1 DEPART · 3 TURN-family · 4 UTURN · 8 MERGE ·
 *                                              10/11 ROUNDABOUT · 12 CONTINUE · 30 ARRIVE)
 *   step .8                 = turn shape when .7==3 (1 SLIGHT · 2 TURN · 3 SHARP · 4 KEEP · 6 STRAIGHT)
 *   step .9                 = side (1 LEFT · 2 RIGHT)      · step .11 = roundabout exit number
 *   step .16                = index of the maneuver point in the route polyline (0.00 m error)
 *   step .1 .3 .1           = step metres                 · step .12 .2 = road name · step .19 .2 = instruction
 *
 * Everything is best-effort: a malformed body yields null rather than throwing, like the VietMap
 * parser. The maneuver point is taken from the polyline vertex at step field 16, so guidance rides
 * the real dense geometry (not just the sparse turn vertices).
 */
object GoogleRouteParser {

    private const val TAG = "GoogleMapsHook"

    /** Parse a gunzipped GetDirections protobuf body into a [NavRoute], or null. Never throws. */
    fun parse(body: ByteArray): NavRoute? = try {
        parseProto(body)
    } catch (t: Throwable) {
        Log.e(TAG, "google route: parse failed: $t")
        null
    }

    private fun parseProto(body: ByteArray): NavRoute? {
        val wrapper = Message(body).message(1)?.message(1) ?: return null
        val routes = wrapper.messages(2)
        val polylines = wrapper.messages(8)
        if (routes.isEmpty()) return null

        // Pick the first "real" route: skip empties and multi-modal routes (walk/bus legs each carry
        // their own DEPART), which would otherwise make the HUD announce the wrong turns.
        var pick = -1
        for (i in routes.indices) {
            val steps = stepsOf(routes[i])
            if (steps.size < 2) continue
            if (steps.count { it.varint(7) == 1L } > 1) continue   // > 1 DEPART ⇒ multi-modal
            pick = i
            break
        }
        if (pick < 0) return null

        val points = polylines.getOrNull(pick)?.let { decodePolyline(it) } ?: emptyList()
        val steps = stepsOf(routes[pick])

        val maneuvers = ArrayList<NavManeuver>()
        for (step in steps) {
            val type = (step.varint(7) ?: 0L).toInt()
            if (type == ROUNDABOUT_EXIT) continue   // fold: the ENTER step (11) is the announcement
            val shape = (step.varint(8) ?: 0L).toInt()
            val sideRaw = (step.varint(9) ?: 0L).toInt()
            val exit = (step.varint(11) ?: 0L).toInt()
            val plIdx = (step.varint(16) ?: -1L).toInt()
            val road = step.message(12)?.string(2) ?: ""

            // Maneuver location: the polyline vertex the step points at (field 16). Fall back to the
            // step's own geometry point if the polyline is missing.
            val at = points.getOrNull(plIdx)
                ?: step.message(1)?.message(8)?.message(2)?.let { pair ->
                    pair.message(1)?.let { p -> p.fixed64Double(3)?.let { la -> p.fixed64Double(4)?.let { lo -> doubleArrayOf(la, lo) } } }
                }
                ?: continue

            maneuvers.add(
                NavManeuver(
                    lat = at[0],
                    lng = at[1],
                    event = mapEvent(type, shape),
                    side = mapSide(sideRaw),
                    angle = 0,               // Google gives no roundabout angle; HUD uses the generic glyph
                    number = exit.coerceIn(0, 19),
                    road = road,
                ),
            )
        }
        if (maneuvers.isEmpty()) return null
        // If the polyline was absent, fall back to the maneuver points so RouteGuide still has geometry.
        val geometry = if (points.size >= 2) points else maneuvers.map { doubleArrayOf(it.lat, it.lng) }
        if (geometry.size < 2) return null
        return NavRoute(geometry, maneuvers)
    }

    /** steps live at route .2 (legs) .2 (leg) .2[] (step). */
    private fun stepsOf(route: Message): List<Message> =
        route.message(2)?.message(2)?.messages(2) ?: emptyList()

    /**
     * Decode a route polyline: two packed sint32 arrays (field 1 = lat deltas, field 2 = lng deltas),
     * zigzag-encoded, cumulative, scaled by 1e7.
     */
    private fun decodePolyline(poly: Message): List<DoubleArray> {
        val lat = poly.packedVarints(1)
        val lng = poly.packedVarints(2)
        val n = minOf(lat.size, lng.size)
        val pts = ArrayList<DoubleArray>(n)
        var cumLat = 0L
        var cumLng = 0L
        for (i in 0 until n) {
            cumLat += zigzag(lat[i])
            cumLng += zigzag(lng[i])
            pts.add(doubleArrayOf(cumLat / 1e7, cumLng / 1e7))
        }
        return pts
    }

    private fun zigzag(v: Long): Long = (v ushr 1) xor -(v and 1)

    // ---- GMM maneuver enums -> standard NavEvent / NavSide -------------------

    private const val ROUNDABOUT_EXIT = 10

    private fun mapEvent(type: Int, shape: Int): Int = when (type) {
        1 -> NavEvent.DEPART
        2 -> NavEvent.STRAIGHT                       // continue through a named junction
        3 -> when (shape) {                          // TURN family — the shape decides
            1 -> NavEvent.SLIGHT
            3 -> NavEvent.SHARP
            4 -> NavEvent.FORK                        // "keep left/right" — a fork/lane keep
            6 -> NavEvent.STRAIGHT
            else -> NavEvent.TURN                     // shape 2 = plain turn
        }
        4 -> NavEvent.UTURN
        8 -> NavEvent.MERGE
        10, 11 -> NavEvent.ROUNDABOUT
        12 -> NavEvent.STRAIGHT
        30 -> NavEvent.DEST
        else -> NavEvent.STRAIGHT
    }

    private fun mapSide(side: Int): Int = when (side) {
        1 -> NavSide.LEFT
        2 -> NavSide.RIGHT
        else -> NavSide.NONE
    }

    // ---- Minimal protobuf reader (parse by field number, no .proto schema) ---
    // Wire types: 0 varint, 1 fixed64, 2 length-delimited, 5 fixed32.

    private class Message(bytes: ByteArray) {
        private val fields = HashMap<Int, MutableList<Pair<Int, Any>>>()

        init {
            var i = 0
            val n = bytes.size
            while (i < n) {
                val (tag, ni) = readVarint(bytes, i); i = ni
                val field = (tag ushr 3).toInt()
                when ((tag and 7).toInt()) {
                    0 -> { val (v, j) = readVarint(bytes, i); i = j; add(field, 0, v) }
                    1 -> { add(field, 1, bytes.copyOfRange(i, i + 8)); i += 8 }
                    2 -> {
                        val (len, j) = readVarint(bytes, i); i = j
                        val end = i + len.toInt()
                        if (end < i || end > n) break
                        add(field, 2, bytes.copyOfRange(i, end)); i = end
                    }
                    5 -> { add(field, 5, bytes.copyOfRange(i, i + 4)); i += 4 }
                    else -> break
                }
            }
        }

        private fun add(field: Int, wire: Int, value: Any) {
            fields.getOrPut(field) { ArrayList() }.add(wire to value)
        }

        fun message(field: Int): Message? {
            val v = fields[field]?.firstOrNull { it.first == 2 }?.second as? ByteArray ?: return null
            return Message(v)
        }

        fun messages(field: Int): List<Message> =
            fields[field].orEmpty().filter { it.first == 2 }.map { Message(it.second as ByteArray) }

        fun string(field: Int): String? =
            (fields[field]?.firstOrNull { it.first == 2 }?.second as? ByteArray)?.toString(Charsets.UTF_8)

        fun varint(field: Int): Long? =
            fields[field]?.firstOrNull { it.first == 0 }?.second as? Long

        fun fixed64Double(field: Int): Double? {
            val v = fields[field]?.firstOrNull { it.first == 1 }?.second as? ByteArray ?: return null
            var bits = 0L
            for (k in 7 downTo 0) bits = (bits shl 8) or (v[k].toLong() and 0xff)   // little-endian
            return Double.fromBits(bits)
        }

        /** All varints packed into a length-delimited field (packed repeated). */
        fun packedVarints(field: Int): LongArray {
            val v = fields[field]?.firstOrNull { it.first == 2 }?.second as? ByteArray ?: return LongArray(0)
            val out = ArrayList<Long>()
            var i = 0
            while (i < v.size) {
                val (x, j) = readVarint(v, i); i = j; out.add(x)
            }
            return out.toLongArray()
        }
    }

    private fun readVarint(b: ByteArray, start: Int): Pair<Long, Int> {
        var result = 0L
        var shift = 0
        var i = start
        while (true) {
            val x = b[i].toInt() and 0xff
            i++
            result = result or ((x.toLong() and 0x7f) shl shift)
            if (x and 0x80 == 0) break
            shift += 7
        }
        return result to i
    }
}
