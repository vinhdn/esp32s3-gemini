package com.rongcondihoc.vegvisir.domain

/** A single client currently connected to the server socket. */
data class Connector(
    val ip: String,
    val port: Int,
    val fd: Int,
    val type: ClientType = ClientType.UNKNOWN,
)

/** Snapshot of the server engine, observed by the UI. */
data class EngineState(
    val running: Boolean = false,
    val port: Int = 0,
    val connectors: List<Connector> = emptyList(),
) {
    val clientCount: Int get() = connectors.size

    /** The connected client playing [type], or null when that role is absent. */
    fun clientOf(type: ClientType): Connector? = connectors.firstOrNull { it.type == type }

    /** True while a client of [type] is connected. */
    fun isConnected(type: ClientType): Boolean = clientOf(type) != null
}
