package com.rongcondihoc.vegvisir.service.googlemaps

import android.util.Log
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.GZIPInputStream

/**
 * Captures Google Maps' GetDirections response at the Cronet Java layer and feeds the raw protobuf
 * to [GoogleMapsHook.onDirectionsBody].
 *
 * WHY this layer (verified on device): Maps drives Cronet from native C++, so there is no
 * `UrlRequest.Callback` to hook, and libcronet is stripped (only `JNI_OnLoad` exported) so a native
 * hook would need fragile byte-patterns. But the directions RPC is a gRPC **bidirectional stream**,
 * and `CronetBidirectionalStream.onReadCompleted(ByteBuffer, bytesRead, …)` is a stable,
 * NON-obfuscated `@CalledByNative` method — hooking it survives Maps/Cronet updates. The response
 * body arrives here as gRPC frames: `[1B flag][4B len BE][gzip(protobuf)]`.
 *
 * Cronet lives in the GMS "dynamite" (or mainline connectivity) classloader, not the app loader, and
 * its class name has two possible prefixes (`org.chromium.net.impl.*` and
 * `android.net.connectivity.org.chromium.net.impl.*`). So we don't hardcode a loader: we tap
 * `ClassLoader.loadClass` and match the class by its simple-name suffix, hooking `onReadCompleted`
 * on whichever concrete class actually loads.
 *
 * All work is wrapped so a failure can never crash Google Maps.
 */
object GoogleCronetHook {

    private const val TAG = "GoogleMapsHook"
    private const val MAX_FRAME = 8 * 1024 * 1024   // sanity cap on a gRPC frame length
    private const val MAX_STREAMS = 64              // bound the per-stream accumulator map

    // Concrete Cronet request/stream classes whose onReadCompleted carries response bytes. Matched by
    // simple-name suffix so both classloader prefixes are caught. BidirectionalStream is the one that
    // actually carries GetDirections (gRPC); UrlRequest is hooked too and simply yields no route.
    private val TARGET_SIMPLE_NAMES = setOf("CronetBidirectionalStream", "CronetUrlRequest")

    @Volatile
    private var installed = false

    // Classes already hooked (avoid double-hooking as loadClass fires repeatedly).
    private val hookedClasses = ConcurrentHashMap.newKeySet<String>()

    // Per-stream accumulation. Key = identity of the stream object.
    private class Acc {
        val buf = ByteArrayOutputStream()
        var isRoute: Boolean? = null
    }
    private val streams = ConcurrentHashMap<Int, Acc>()

    /** Arm the capture: watch class loading and hook onReadCompleted on the Cronet stream class. */
    fun install() {
        if (installed) return
        installed = true
        try {
            XposedBridge.hookAllMethods(
                ClassLoader::class.java, "loadClass",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val cls = param.result as? Class<*> ?: return
                        val simple = cls.simpleName
                        if (simple in TARGET_SIMPLE_NAMES) hookClass(cls)
                    }
                },
            )
            Log.d(TAG, "cronet capture armed (watching for CronetBidirectionalStream)")
        } catch (t: Throwable) {
            Log.e(TAG, "cronet capture install failed: $t")
        }
    }

    private fun hookClass(cls: Class<*>) {
        if (!hookedClasses.add(cls.name)) return
        try {
            XposedBridge.hookAllMethods(cls, "onReadCompleted", object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    try {
                        onReadCompleted(param.thisObject, param.args)
                    } catch (t: Throwable) {
                        // never disturb Cronet
                    }
                }
            })
            Log.i(TAG, "hooked ${cls.name}.onReadCompleted")
        } catch (t: Throwable) {
            Log.e(TAG, "hook ${cls.name} failed: $t")
        }
    }

    /**
     * onReadCompleted(ByteBuffer buffer, int bytesRead, …): the freshly read [bytesRead] bytes sit at
     * the start of the direct buffer. Accumulate per stream, keep only gRPC-gzip (route) streams, and
     * extract each complete `[flag][len][gzip]` frame → gunzip → [GoogleMapsHook.onDirectionsBody].
     */
    private fun onReadCompleted(stream: Any?, args: Array<Any?>) {
        val bb = args.getOrNull(0) as? ByteBuffer ?: return
        val bytesRead = (args.getOrNull(1) as? Int) ?: return
        if (bytesRead <= 0 || stream == null) return

        val chunk = ByteArray(bytesRead)
        val dup = bb.duplicate()
        dup.position(0)
        dup.limit(bytesRead)
        dup.get(chunk)

        val key = System.identityHashCode(stream)
        val acc = streams.getOrPut(key) {
            if (streams.size >= MAX_STREAMS) streams.clear()   // crude but keeps memory bounded
            Acc()
        }
        acc.buf.write(chunk)
        val b = acc.buf.toByteArray()

        // Decide once whether this stream is a gzip-gRPC route. gRPC framing puts the gzip magic at
        // offset 5 ([flag][len]); scan the first 16 bytes to be lenient.
        if (acc.isRoute == null && b.size >= 7) {
            acc.isRoute = looksRoute(b)
            if (acc.isRoute == false) { streams.remove(key); return }
        }
        if (acc.isRoute != true) return

        val leftover = extractFrames(b)
        acc.buf.reset()
        if (leftover.isEmpty()) streams.remove(key) else acc.buf.write(leftover)
    }

    /** Extract every complete gRPC frame from [b], hand each gunzipped body up, return the tail. */
    private fun extractFrames(b: ByteArray): ByteArray {
        var off = 0
        while (b.size - off >= 5) {
            val len = ((b[off + 1].toInt() and 0xff) shl 24) or
                ((b[off + 2].toInt() and 0xff) shl 16) or
                ((b[off + 3].toInt() and 0xff) shl 8) or
                (b[off + 4].toInt() and 0xff)
            if (len <= 0 || len > MAX_FRAME) return ByteArray(0)   // header looks bogus → drop stream
            if (b.size - off < 5 + len) break                      // frame not complete yet
            val proto = gunzip(b, off + 5, len)
            if (proto != null) GoogleMapsHook.onDirectionsBody(proto)
            off += 5 + len
        }
        return if (off == 0) b else b.copyOfRange(off, b.size)
    }

    /** Gzip magic (1f 8b) within the first 16 bytes → this is a gRPC-gzip response. */
    private fun looksRoute(b: ByteArray): Boolean {
        val n = minOf(16, b.size - 1)
        for (i in 0 until n) if (b[i] == 0x1f.toByte() && b[i + 1] == 0x8b.toByte()) return true
        return false
    }

    private fun gunzip(b: ByteArray, off: Int, len: Int): ByteArray? = try {
        GZIPInputStream(b.inputStream(off, len)).use { it.readBytes() }
    } catch (t: Throwable) {
        null
    }
}
