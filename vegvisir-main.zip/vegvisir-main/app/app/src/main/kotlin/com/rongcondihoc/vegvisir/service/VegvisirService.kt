package com.rongcondihoc.vegvisir.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import com.rongcondihoc.vegvisir.R
import com.rongcondihoc.vegvisir.domain.NavSource
import com.rongcondihoc.vegvisir.server.ServerEngine
import com.rongcondihoc.vegvisir.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File

/**
 * A foreground service that hosts the VEG1 socket server ([ServerEngine]) for the whole
 * lifetime of the device session — independent of the UI Activity.
 *
 * WHY a service (not the Activity/Application): the vietmap LSPosed hook dials the server over
 * loopback and only appears as a client once the server is listening. If the server lived in the
 * UI process it would only come up when the user opens the app, and Android could kill it the
 * moment the app is backgrounded — so if VietMap starts navigating first, its hook would find no
 * server and never register. Running the server in a foreground service keeps it alive across UI
 * teardown, and [BootReceiver] starts it at boot so it is ready *before* VietMap runs.
 *
 * The server itself ([ServerEngine]) is a process-wide singleton; this service just owns its
 * lifecycle plus the two app-layer collectors (NavSource persistence, request-file handling)
 * that used to live in VegvisirApp.
 */
class VegvisirService : Service() {

    // Tied to this service instance; cancelled in onDestroy. A restarted service (START_STICKY)
    // is a fresh instance with a fresh scope.
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        goForeground()
        // Boot the Kotlin socket server (idempotent — safe if already running).
        ServerEngine.start()
        restoreNavSource()
        handleRequests()
        Log.i(TAG, "service created; server engine started")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Re-assert foreground on every start (including a START_STICKY restart with a null intent).
        goForeground()
        // Keep the server running: if the system kills us for memory, recreate the service.
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        // Deliberately DO NOT call ServerEngine.stop(): the server must outlive the UI (and this
        // service instance) so the vietmap hook can connect regardless of when VietMap starts.
        // We only tear down this instance's own collectors.
        scope.cancel()
        super.onDestroy()
    }

    // ---- foreground notification -------------------------------------------------

    private fun goForeground() {
        ensureChannel()
        val tap = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val notification: Notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setSmallIcon(R.drawable.ic_stat_vegvisir)
            .setOngoing(true)
            .setContentIntent(tap)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun ensureChannel() {
        val nm = getSystemService(NotificationManager::class.java) ?: return
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notif_channel_name),
            NotificationManager.IMPORTANCE_LOW,   // no sound/heads-up for a persistent status
        ).apply { description = getString(R.string.notif_channel_desc) }
        nm.createNotificationChannel(channel)
    }

    // ---- app-layer collectors (moved out of VegvisirApp) -------------------------

    /** Restore the last-picked navigation source and keep it persisted across restarts. */
    private fun restoreNavSource() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val saved = runCatching { NavSource.valueOf(prefs.getString(KEY_NAV_SOURCE, null) ?: "") }
            .getOrDefault(NavSource.NONE)
        ServerEngine.setNavSource(saved)
        scope.launch {
            ServerEngine.navSource.collect { source ->
                prefs.edit().putString(KEY_NAV_SOURCE, source.name).apply()
            }
        }
    }

    /**
     * Handle inbound client requests. A client can ask the server to send it a file
     * (e.g. vegvisir-sim's "request file" button); we reply by streaming one.
     */
    private fun handleRequests() {
        scope.launch {
            ServerEngine.requests.collect { request ->
                val action = runCatching { JSONObject(request.body).optString("action") }
                    .getOrDefault("")
                Log.i(TAG, "request fd=${request.fd} type=${request.type} action=$action")
                if (action == "request-file") {
                    val file = writeRequestedFile()
                    val count = ServerEngine.sendFileTo(request.fd, file.absolutePath)
                    Log.i(TAG, "request-file: sent ${file.length()} B to fd=${request.fd} ($count)")
                }
            }
        }
    }

    /** A stand-in file the server hands back on a "request file" (real source TBD). */
    private fun writeRequestedFile(): File {
        val file = File(cacheDir, "server_response.bin")
        file.writeBytes(ByteArray(4096) { (it % 256).toByte() })
        return file
    }

    companion object {
        private const val TAG = "Vegvisir"
        private const val CHANNEL_ID = "vegvisir_server"
        private const val NOTIF_ID = 1

        private const val PREFS = "vegvisir"
        private const val KEY_NAV_SOURCE = "nav_source"

        /**
         * Start (or ensure running) the foreground server service. Safe to call from the Activity,
         * the Application, or [BootReceiver]. Wrapped because a background start can be refused on
         * Android 12+ (ForegroundServiceStartNotAllowedException) outside an allowed context;
         * the boot and UI paths are both allowed, so a failure here is only a defensive log.
         */
        fun start(context: Context) {
            val intent = Intent(context, VegvisirService::class.java)
            try {
                context.startForegroundService(intent)
            } catch (t: Throwable) {
                Log.w(TAG, "startForegroundService refused: $t")
            }
        }
    }
}
