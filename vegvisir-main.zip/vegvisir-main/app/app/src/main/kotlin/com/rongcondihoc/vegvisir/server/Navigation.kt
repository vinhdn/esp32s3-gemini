package com.rongcondihoc.vegvisir.server

import org.json.JSONArray
import org.json.JSONObject

/**
 * The navigation relay: validate + clamp a source's Navigation body into the
 * canonical HUD-sink JSON that mazda consumes.
 *
 * A navigation source (vietmap / googlemap) sends a Navigation JSON body; the
 * server validates + clamps it and re-serializes the canonical HUD-sink JSON
 * that the mazda client parses. The key names and enum values are NORMATIVE —
 * they must match vegvisir-client's hud-navigate provider.
 */
object Navigation {

    // NavEvent — Android Auto hu.proto numbering (mirrors vegvisir-client).
    private val VALID_EVENTS = setOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 13, 14, 16, 19)
    private const val EV_STRAIGHT = 14

    // NavSide: 1=left, 2=right, 3=none.
    private const val SIDE_NONE = 3

    // Lane row limits, mirroring the HUD model (`NAV_LANE_MAX` / `NAV_LANE_ANGLES_MAX` in
    // vegvisir-client's `core/nav_types.h`) — the cluster row is 8 slots wide. Extras are dropped.
    private const val MAX_LANES = 8
    private const val MAX_LANE_ANGLES = 8

    /**
     * Parse a raw Navigation body, clamp it, and return the canonical HUD-sink
     * JSON to relay to mazda. Returns null if the body is not a JSON object.
     */
    fun clampToHudJson(rawBody: String): String? {
        val o = try {
            JSONObject(rawBody)
        } catch (e: Exception) {
            return null
        }

        val active = o.optBoolean("active", true)
        val event = clampEvent(o.optLong("event", EV_STRAIGHT.toLong()))
        val side = clampSide(o.optLong("side", SIDE_NONE.toLong()))
        val angle = o.optInt("angle", 0)
        var number = o.optInt("number", 0)
        if (number < 0 || number > 19) number = 0
        val road = o.optString("road", "")
        val distance = o.optInt("distance", 0)
        val unit = o.optInt("unit", 0)
        val eta = o.optInt("eta", 0)
        val speedLimit = o.optInt("speedLimit", 0).coerceAtLeast(0)
        val lanes = clampLanes(o.optJSONArray("lanes"))

        // JSONObject escapes `road` correctly; the client reads by key, so field
        // order does not matter.
        return JSONObject()
            .put("active", active)
            .put("event", event)
            .put("side", side)
            .put("angle", angle)
            .put("number", number)
            .put("road", road)
            .put("distance", distance)
            .put("unit", unit)
            .put("eta", eta)
            .put("speedLimit", speedLimit)
            // Only when the source sent usable lanes: the client reads a missing key as "no lanes"
            // and blanks the row, so an empty array would say the same thing in more bytes.
            .apply { if (lanes.length() > 0) put("lanes", lanes) }
            .toString()
    }

    /**
     * Validate the lane row: at most [MAX_LANES] lanes of at most [MAX_LANE_ANGLES] directions, each
     * direction a bearing in `[-180, 180]`. Anything that does not survive that is dropped rather
     * than corrected — a lane arrow guessed from a malformed field would point somewhere real.
     */
    private fun clampLanes(raw: JSONArray?): JSONArray {
        val out = JSONArray()
        if (raw == null) return out

        for (i in 0 until minOf(raw.length(), MAX_LANES)) {
            val lane = raw.optJSONObject(i) ?: continue
            val rawAngles = lane.optJSONArray("angles") ?: continue

            val angles = JSONArray()
            for (k in 0 until rawAngles.length()) {
                if (angles.length() >= MAX_LANE_ANGLES) break
                val a = rawAngles.optInt(k, Int.MIN_VALUE)
                if (a in -180..180) angles.put(a)
            }
            if (angles.length() == 0) continue   // a lane with no direction draws nothing

            val clamped = JSONObject()
                .put("angles", angles)
                .put("recommended", lane.optBoolean("recommended", false))
            val hl = lane.optInt("highlight", Int.MIN_VALUE)
            if (hl in -180..180) clamped.put("highlight", hl)

            out.put(clamped)
        }
        return out
    }

    private fun clampEvent(v: Long): Int =
        if (v in VALID_EVENTS.map { it.toLong() }) v.toInt() else EV_STRAIGHT

    private fun clampSide(v: Long): Int =
        if (v in 1L..3L) v.toInt() else SIDE_NONE
}
