package com.rongcondihoc.vegvisir.service

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Turns the LSPosed injection stack back on via root, then reboots — the one-tap recovery behind
 * the "enable VietMap hook" dialog. It re-applies exactly the two changes that were found disabled:
 * Magisk's `zygisk` setting and the `zygisk_lsposed` module's `disable` flag. LSPosed injects at
 * process fork, so a reboot is required for it to take effect.
 *
 * Needs root. The app is a normal (non-root) app, so the first call triggers Magisk's superuser
 * prompt unless a policy for this app's uid was pre-granted during provisioning; a denial is
 * reported as failure rather than a silent no-op.
 *
 * Commands are fed to `su` over stdin so the on-device shell parses them. Passing the SQL through
 * `su -c "..."` (or nested `adb shell su -c`) mangles the `(` / quotes; stdin avoids that entirely.
 */
object HookInstaller {

    private const val TAG = "Vegvisir"

    /**
     * Enable Zygisk + the LSPosed module and reboot.
     *
     * Returns **false** on failure (root denied, or the reboot did not happen). On success the
     * device reboots, so this function never returns true — the caller should treat a return as an
     * error and a non-return (reboot) as success.
     */
    suspend fun enableAndReboot(): Boolean = withContext(Dispatchers.IO) {
        try {
            val p = ProcessBuilder("su").redirectErrorStream(true).start()
            val w = p.outputStream.bufferedWriter()
            val r = p.inputStream.bufferedReader()

            // 1) Confirm we actually hold root before touching anything.
            w.write("echo VEG_UID:\$(id -u)\n")
            w.flush()
            val gotRoot = withTimeoutOrNull(8_000L) {
                var line = r.readLine()
                while (line != null) {
                    if (line.contains("VEG_UID:0")) return@withTimeoutOrNull true
                    if (line.contains("VEG_UID:")) return@withTimeoutOrNull false
                    line = r.readLine()
                }
                false
            } == true

            if (!gotRoot) {
                Log.w(TAG, "hook fix: root not granted (Magisk denied or no policy)")
                runCatching { w.write("exit\n"); w.flush() }
                runCatching { p.destroy() }
                return@withContext false
            }

            // 2) Re-enable Zygisk + the LSPosed module, flush, then reboot.
            w.write("magisk --sqlite \"REPLACE INTO settings (key,value) VALUES('zygisk',1)\"\n")
            w.write("rm -f /data/adb/modules/zygisk_lsposed/disable\n")
            w.write("sync\n")
            w.write("setprop sys.powerctl reboot\n")
            w.flush()

            // If we are still alive after this, the reboot did not take — report failure.
            delay(6_000L)
            Log.w(TAG, "hook fix: applied but device did not reboot")
            false
        } catch (t: Throwable) {
            Log.w(TAG, "hook fix failed: $t")
            false
        }
    }
}
