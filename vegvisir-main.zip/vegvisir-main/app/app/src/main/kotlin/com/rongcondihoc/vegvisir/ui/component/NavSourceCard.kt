package com.rongcondihoc.vegvisir.ui.component

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rongcondihoc.vegvisir.domain.NavSource

/**
 * Navigation source card: which source is currently driving the HUD, and whether that source is
 * actually connected. Tapping opens the source picker page.
 */
@Composable
fun NavSourceCard(
    selected: NavSource,
    connected: Boolean,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpen)
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // NONE has no peer to connect to, so it keeps the muted dot.
            StatusDot(connected = selected != NavSource.NONE && connected)
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Navigation source", style = MaterialTheme.typography.titleMedium)
                Text(
                    text = subtitle(selected, connected),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Icon(
                Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

private fun subtitle(selected: NavSource, connected: Boolean): String = when (selected) {
    NavSource.NONE -> "None · HUD guidance off"
    else -> "${selected.label} · " + if (connected) "connected" else "not connected"
}
