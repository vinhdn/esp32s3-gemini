package com.rongcondihoc.vegvisir.service.vietmap

import android.util.Log
import com.rongcondihoc.vegvisir.service.NavEvent
import com.rongcondihoc.vegvisir.service.NavLane
import com.rongcondihoc.vegvisir.service.NavManeuver
import com.rongcondihoc.vegvisir.service.NavRoute
import com.rongcondihoc.vegvisir.service.NavSide
import org.json.JSONArray
import org.json.JSONObject

/**
 * The VietMap navigation provider: parses a captured Route API response into the standard
 * [NavRoute] that [RouteGuide] consumes. This is the ONLY place that knows VietMap's wire format;
 * a Google Maps provider would be a sibling parser producing the same [NavRoute].
 *
 * VietMap's `/production/tracking/v20/place/Route` reply is a Mapbox-Directions route at
 * `data.data.routes[0]`: `geometry` is a **polyline6** (precision 1e6) string and
 * `legs[].steps[].maneuver` carries `type` / `modifier` / `bearing_after` / `exit` /
 * `location([lng,lat])`. Each maneuver location lies exactly on the decoded geometry, so the
 * standard model needs only the decoded points plus the mapped maneuvers.
 */
object RouteParser {

    private const val TAG = "VietMapHook"

    // How far an intersection may sit from a maneuver and still count as the same node. The two
    // coordinates are identical in every captured reply, so this only has to absorb rounding.
    private const val LANE_NODE_TOLERANCE_M = 10.0

    /**
     * Parse a raw Route API body (VietMap's JSON, already de-chunked + gunzipped) into a
     * [NavRoute], or null if it carries no usable route. Never throws.
     */
    fun parse(body: ByteArray): NavRoute? = try {
        parseJson(String(body, Charsets.UTF_8))
    } catch (t: Throwable) {
        Log.e(TAG, "vietmap route: parse failed: $t")
        null
    }

    private fun parseJson(raw: String): NavRoute? {
        // routes live at data.data.routes[0]; both `data` wrappers are present in the API reply.
        val root = JSONObject(raw)
        val inner = root.optJSONObject("data")?.optJSONObject("data") ?: return null
        val routes = inner.optJSONArray("routes") ?: return null
        if (routes.length() == 0) return null
        val route0 = routes.optJSONObject(0) ?: return null

        val points = decodePolyline6(route0.optString("geometry", ""))
        if (points.size < 2) return null

        val maneuvers = ArrayList<NavManeuver>()
        val legs = route0.optJSONArray("legs") ?: return null
        for (li in 0 until legs.length()) {
            val steps = legs.optJSONObject(li)?.optJSONArray("steps") ?: continue
            for (si in 0 until steps.length()) {
                val step = steps.optJSONObject(si) ?: continue
                val mv = step.optJSONObject("maneuver") ?: continue
                val loc = mv.optJSONArray("location") ?: continue  // [lng, lat]
                if (loc.length() < 2) continue
                val lng = loc.optDouble(0)
                val lat = loc.optDouble(1)

                val type = mv.optString("type", "")
                val modifier = mv.optString("modifier", "")

                // A rotary/roundabout is one HUD maneuver, but VietMap splits a big rotary into an
                // enter step (`rotary`) + a leave step (`exit rotary`). Fold them: emit the
                // roundabout at the enter step and skip the leave step (its info is used below).
                if (type == "exit rotary" || type == "exit roundabout") continue

                val event = mapEvent(type, modifier)
                var side = mapSide(modifier)
                var angle = 0
                var number = 0
                var endLat = lat
                var endLng = lng
                if (event == NavEvent.ROUNDABOUT) {
                    number = mv.optInt("exit", 0).coerceIn(0, 19)

                    // `side` on a roundabout picks the HUD's glyph BANK (which way traffic
                    // circulates), not the exit direction — that is `angle`. Mapbox's `modifier`
                    // is useless for it: captured rotaries read "right" even when the exit turns
                    // 90 deg LEFT. The driving side is what the bank actually means.
                    side = if (step.optString("driving_side", "right") == "left") {
                        NavSide.LEFT
                    } else {
                        NavSide.RIGHT
                    }

                    // The paired leave step (skipped by the fold above) is where the maneuver
                    // ENDS: guidance holds the roundabout glyph until the car is out of the
                    // circle, and its bearing_after is the only true exit heading in the payload.
                    val exitStep = steps.optJSONObject(si + 1)?.takeIf {
                        val t = it.optJSONObject("maneuver")?.optString("type", "")
                        t == "exit rotary" || t == "exit roundabout"
                    }
                    exitStep?.optJSONObject("maneuver")?.optJSONArray("location")?.let { xl ->
                        if (xl.length() >= 2) {
                            endLng = xl.optDouble(0)
                            endLat = xl.optDouble(1)
                        }
                    }

                    // Best signal: Mapbox states the roundabout's exit angle as `degrees`, with
                    // 180 meaning "straight through". It lives on the banner that ANNOUNCES the
                    // roundabout, which sits on the PREVIOUS step — a step's banners describe its
                    // upcoming maneuver, not its own (the enter/exit steps carry none of their
                    // own). `degrees` runs the OPPOSITE way round from the HUD glyph (0 = straight
                    // ahead, + = right/CW), so the HUD angle is 180-degrees, not degrees-180:
                    // verified against the route geometry of captured rotaries, where degrees=270
                    // is a 90 deg LEFT exit and degrees=152 a 28 deg right one.
                    val prev = if (si > 0) steps.optJSONObject(si - 1) else null
                    val degrees = bannerDegrees(prev)
                    angle = if (degrees != null) {
                        ((180 - degrees) % 360 + 360) % 360
                    } else {
                        // Rare fallback (no announcing banner): derive it from bearings. NOTE
                        // VietMap's `bearing_before` points BACK down the approach, so the
                        // approach heading is bearing_before+180; and the rotary's own
                        // `bearing_after` is the circulating heading, so the exit heading has to
                        // come from the leave step.
                        val approach = (mv.optInt("bearing_before", 0) + 180) % 360
                        val exitMv = exitStep?.optJSONObject("maneuver") ?: mv
                        val afterExit = exitMv.optInt("bearing_after", approach)
                        ((afterExit - approach) % 360 + 360) % 360
                    }
                }
                // The road the maneuver leads onto is this step's own name.
                val road = step.optString("name", "").ifBlank { mv.optString("instruction", "") }

                maneuvers.add(
                    NavManeuver(
                        lat, lng, event, side, angle, number, road, endLat, endLng,
                        lanesFor(steps, si, lat, lng),
                    ),
                )
            }
        }
        if (maneuvers.isEmpty()) return null

        return NavRoute(points, maneuvers)
    }

    // ---- Lane guidance -------------------------------------------------------

    /**
     * The approach lanes for the maneuver that STARTS `steps[si]`, or empty if the reply carries
     * none for it.
     *
     * Mapbox hangs lane data off `intersections`, never off the maneuver, so the association has to
     * be derived: a step's LAST intersection IS the node the NEXT step's maneuver happens at
     * (verified on captured routes — the two coordinates are byte-identical), which puts the lanes a
     * driver has to choose between for step `si` on step `si-1`. The earlier lane-bearing
     * intersections of that step belong to junctions already driven through, so they are ignored.
     *
     * Nothing is guessed: a leg's first step, a missing lane array, or a last intersection that is
     * NOT the maneuver node all yield no lanes. Blank lane arrows cost the driver nothing; arrows
     * for the wrong junction actively mislead.
     */
    private fun lanesFor(steps: JSONArray, si: Int, lat: Double, lng: Double): List<NavLane> {
        if (si <= 0) return emptyList()
        val prev = steps.optJSONObject(si - 1) ?: return emptyList()
        val ints = prev.optJSONArray("intersections") ?: return emptyList()
        val last = ints.optJSONObject(ints.length() - 1) ?: return emptyList()
        val lanes = last.optJSONArray("lanes") ?: return emptyList()

        val loc = last.optJSONArray("location") ?: return emptyList()  // [lng, lat]
        if (loc.length() < 2) return emptyList()
        if (metres(loc.optDouble(1), loc.optDouble(0), lat, lng) > LANE_NODE_TOLERANCE_M) {
            Log.w(TAG, "vietmap route: step $si lane node is not the maneuver node — no lanes")
            return emptyList()
        }

        // Which way a U-turn indication points depends on which side traffic drives on.
        val drivingSide = prev.optString("driving_side", "right")

        val out = ArrayList<NavLane>(lanes.length())
        for (i in 0 until minOf(lanes.length(), NavLane.MAX_LANES)) {
            val ln = lanes.optJSONObject(i) ?: continue

            // A set: two indications can bucket to the same direction, and a lane that allows one
            // direction twice is still a one-arrow lane.
            val angles = LinkedHashSet<Int>()
            val inds = ln.optJSONArray("indications")
            if (inds != null) {
                for (k in 0 until inds.length()) {
                    laneAngle(inds.optString(k), drivingSide)?.let { angles.add(it) }
                }
            }
            if (angles.isEmpty()) continue   // no direction at all -> nothing to draw

            out.add(
                NavLane(
                    angles = angles.take(NavLane.MAX_ANGLES),
                    highlight = highlightAngle(ln.optString("valid_indication", ""), drivingSide),
                    // `valid` = a driver CAN complete the upcoming maneuver from this lane;
                    // `active` = it is the preferred one among those. Older replies carry only
                    // `valid`, so a missing `active` reads as "yes".
                    recommended = ln.optBoolean("valid", false) && ln.optBoolean("active", true),
                ),
            )
        }
        return out
    }

    /**
     * A Mapbox lane indication as a direction in degrees (0 = straight, negative = left), or null
     * for a word we do not know.
     *
     * `"none"` here means the lane carries no turn marking at all, which on the ground means it
     * goes straight on — NOT the same as the `"none"` in `valid_indication`, see [highlightAngle].
     */
    private fun laneAngle(indication: String, drivingSide: String): Int? = when (indication) {
        "sharp left" -> -135
        "left" -> -90
        "slight left" -> -30
        "straight", "none" -> 0
        "slight right" -> 30
        "right" -> 90
        "sharp right" -> 135
        "uturn" -> if (drivingSide == "left") 180 else -180
        else -> null
    }

    /**
     * The highlighted direction from `valid_indication`. Here `"none"` means "no indication applies
     * to this route", i.e. do not highlight anything — the opposite reading of the same word from
     * the one [laneAngle] uses for the `indications` list.
     */
    private fun highlightAngle(validIndication: String, drivingSide: String): Int? =
        if (validIndication.isEmpty() || validIndication == "none") null
        else laneAngle(validIndication, drivingSide)

    /** Rough metres between two `lat/lng` pairs — a local flat frame is plenty at junction scale. */
    private fun metres(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        val dLat = (lat1 - lat2) * 111320.0
        val dLng = (lng1 - lng2) * 111320.0 * Math.cos(Math.toRadians(lat2))
        return Math.hypot(dLat, dLng)
    }

    /**
     * The roundabout exit angle Mapbox states directly: `degrees` on a banner instruction's
     * `primary`/`sub` component — the clockwise angle from the entrance to the chosen exit. Returns
     * the first one found, or null if the step has no banner degrees (e.g. the enter step, whose
     * degrees live on the paired exit step).
     */
    private fun bannerDegrees(step: JSONObject?): Int? {
        val banners = step?.optJSONArray("bannerInstructions") ?: return null
        for (i in 0 until banners.length()) {
            val bi = banners.optJSONObject(i) ?: continue
            for (slot in arrayOf("primary", "sub")) {
                val comp = bi.optJSONObject(slot) ?: continue
                if (comp.has("degrees") && !comp.isNull("degrees")) return comp.optInt("degrees")
            }
        }
        return null
    }

    // ---- VietMap (Mapbox) maneuver vocabulary -> standard NavEvent/NavSide ----
    // Only the type/modifier combos actually seen in captured Route responses are mapped; extend
    // here if new maneuver types appear.

    private fun mapEvent(type: String, modifier: String): Int = when (type) {
        "depart" -> NavEvent.DEPART
        "new name" -> NavEvent.NAME_CHANGE
        "turn", "end of road" -> when {
            modifier.contains("slight") -> NavEvent.SLIGHT
            modifier.contains("sharp") -> NavEvent.SHARP
            modifier == "uturn" -> NavEvent.UTURN
            else -> NavEvent.TURN
        }
        "fork" -> NavEvent.FORK
        "merge" -> NavEvent.MERGE
        "on ramp" -> NavEvent.ON_RAMP
        "off ramp" -> NavEvent.OFF_RAMP
        "roundabout", "rotary", "roundabout turn" -> NavEvent.ROUNDABOUT
        // Note: "exit rotary"/"exit roundabout" never reach here — parseJson folds them into the
        // preceding roundabout maneuver.
        "continue" -> if (modifier == "uturn") NavEvent.UTURN else NavEvent.STRAIGHT
        "arrive" -> NavEvent.DEST
        "ferry" -> NavEvent.FERRY
        else -> NavEvent.STRAIGHT
    }

    private fun mapSide(modifier: String): Int = when {
        modifier.contains("left") -> NavSide.LEFT
        modifier.contains("right") -> NavSide.RIGHT
        else -> NavSide.NONE
    }

    /** Decode a Google/Mapbox polyline at precision 6 into `[lat, lng]` pairs. */
    private fun decodePolyline6(encoded: String): List<DoubleArray> {
        val path = ArrayList<DoubleArray>()
        var index = 0
        var lat = 0
        var lng = 0
        val len = encoded.length
        while (index < len) {
            var shift = 0
            var result = 0
            var b: Int
            do {
                b = encoded[index++].code - 63
                result = result or ((b and 0x1f) shl shift)
                shift += 5
            } while (b >= 0x20 && index < len)
            lat += if (result and 1 != 0) (result shr 1).inv() else result shr 1

            shift = 0
            result = 0
            do {
                b = encoded[index++].code - 63
                result = result or ((b and 0x1f) shl shift)
                shift += 5
            } while (b >= 0x20 && index < len)
            lng += if (result and 1 != 0) (result shr 1).inv() else result shr 1

            path.add(doubleArrayOf(lat / 1e6, lng / 1e6))
        }
        return path
    }
}
