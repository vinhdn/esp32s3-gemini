package com.rongcondihoc.vegvisir.service.googlemaps

import android.util.Log
import com.rongcondihoc.vegvisir.domain.MessageType
import com.rongcondihoc.vegvisir.server.encodeJsonMessage
import java.net.InetSocketAddress
import java.net.Socket

/**
 * The Google Maps hook's link to the Vegvisir server. It runs INSIDE com.google.android.apps.maps
 * (a process where libvietmaphook — VietMap's native VegvisirClient — is NOT loaded), so it speaks
 * the VEG1 wire protocol from pure Kotlin instead: it dials the server over IPv4 loopback on
 * [com.rongcondihoc.vegvisir.server.ServerEngine.PORT], registers as a `googlemap` client, and
 * relays each HUD Navigation JSON that [com.rongcondihoc.vegvisir.service.RouteGuide] emits. The
 * server then applies its NavSource gate and forwards to mazda.
 *
 * This mirrors what the VietMap hook does natively (dial loopback, Register, stream Navigation).
 * The connection is lazy and self-healing: a dropped socket is simply reopened on the next send.
 * Every path is wrapped so a network hiccup can never crash the host app.
 */
object GoogleServerClient {

    private const val TAG = "GoogleMapsHook"
    private const val HOST = "127.0.0.1"       // the server binds [::]:PORT dual-stack; loopback reaches it
    private const val PORT = 15985             // ServerEngine.PORT
    private const val CONNECT_TIMEOUT_MS = 3000

    private val lock = Any()

    @Volatile
    private var socket: Socket? = null

    /** Send one HUD Navigation JSON to the server, connecting/reconnecting as needed. */
    fun sendNavigation(json: String) {
        write(encodeJsonMessage(MessageType.NAVIGATION, json, id = 0))
    }

    private fun write(frame: ByteArray) {
        synchronized(lock) {
            try {
                val s = ensureConnected() ?: return
                s.getOutputStream().apply { write(frame); flush() }
            } catch (t: Throwable) {
                Log.w(TAG, "send failed, will reconnect: $t")
                closeQuietly()
            }
        }
    }

    /** Open the socket and register as a googlemap client if not already connected. */
    private fun ensureConnected(): Socket? {
        socket?.let { if (it.isConnected && !it.isClosed) return it }
        return try {
            val s = Socket()
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(HOST, PORT), CONNECT_TIMEOUT_MS)
            // Declare our role once, right after connect (same as the mazda/vietmap clients do).
            s.getOutputStream().apply {
                write(encodeJsonMessage(MessageType.REGISTER, """{"clientType":"googlemap"}""", id = 0))
                flush()
            }
            socket = s
            Log.i(TAG, "connected to server $HOST:$PORT as googlemap")
            s
        } catch (t: Throwable) {
            Log.w(TAG, "connect to $HOST:$PORT failed: $t")
            null
        }
    }

    private fun closeQuietly() {
        runCatching { socket?.close() }
        socket = null
    }
}
