package com.rongcondihoc.vegvisir.ui.screen.client

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Map
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.rongcondihoc.vegvisir.domain.ClientType
import com.rongcondihoc.vegvisir.domain.Connector
import com.rongcondihoc.vegvisir.domain.MessageType
import com.rongcondihoc.vegvisir.server.ServerEngine

/**
 * Detail page for a map-app provider (VietMap / Google Maps). Shows the map app
 * name and the latest navigation frame it pushed to the server — which the
 * server relays to mazda in the HUD-sink schema.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NavProviderClientScreen(
    type: ClientType,
    client: Connector?,
    onBack: () -> Unit,
) {
    var lastNav by remember { mutableStateOf<String?>(null) }
    val fd = client?.fd

    // Observe navigation this provider sends (fd-scoped) so the card shows live data. A reconnect
    // hands out a new connection id, which re-keys this effect onto the fresh socket.
    LaunchedEffect(fd) {
        if (fd == null) return@LaunchedEffect
        ServerEngine.requests.collect { req ->
            if (req.fd == fd && req.type == MessageType.NAVIGATION.wireValue) {
                lastNav = req.body
            }
        }
    }

    val appName = type.displayName

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(appName) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { inner ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            if (client == null) {
                Text(
                    "$appName is no longer connected",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text("Map application", style = MaterialTheme.typography.titleMedium)
                    Row2(icon = { Icon(Icons.Default.Map, contentDescription = null) }, text = appName)
                    if (client != null) {
                        Text(
                            "${client.ip} · port ${client.port} · fd ${client.fd}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text("Latest navigation", style = MaterialTheme.typography.titleMedium)
                    Text(
                        lastNav ?: "Waiting for a navigation frame…",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 6,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

@Composable
private fun Row2(icon: @Composable () -> Unit, text: String) {
    androidx.compose.foundation.layout.Row(
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        icon()
        Text(text, style = MaterialTheme.typography.bodyLarge)
    }
}
