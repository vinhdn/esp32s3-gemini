package com.rongcondihoc.vegvisir.service

/**
 * The provider-neutral route model — THE standard [RouteGuide] consumes.
 *
 * A navigation source (VietMap today via [vietmap.RouteParser], Google Maps later) parses its
 * own API response into a [NavRoute]; [RouteGuide] then drives the HUD from it and knows nothing
 * about which provider produced it or what wire format it came from. To add a provider, write a
 * parser that outputs a [NavRoute] and hand it to [RouteGuide.setRoute] — nothing in the engine
 * changes.
 *
 * A route is just two things: the ordered polyline of the whole route, and the ordered maneuvers
 * along it. Each maneuver already speaks the HUD vocabulary ([NavEvent] / [NavSide]) so the engine
 * never has to interpret provider-specific maneuver types.
 */
class NavRoute(
    /** Ordered `[lat, lng]` vertices of the full route geometry (fine enough to snap GPS to). */
    val points: List<DoubleArray>,
    /** Ordered maneuvers along the route, from depart to arrive. */
    val maneuvers: List<NavManeuver>,
)

/** One maneuver in the standard model, in HUD-ready terms. */
class NavManeuver(
    /** Where the maneuver happens (should lie on, or very near, the route polyline). */
    val lat: Double,
    val lng: Double,
    /** [NavEvent] — the kind of maneuver. */
    val event: Int,
    /**
     * [NavSide] — which way it turns. For [NavEvent.ROUNDABOUT] it is NOT the exit direction
     * (that is [angle]) but the driving side, which picks the HUD's roundabout glyph bank.
     */
    val side: Int,
    /**
     * Roundabout exit direction in degrees `[0,360)`, measured from straight-ahead and counted
     * CLOCKWISE: 0 = straight through, 90 = exit right, 270 = exit left. 0 for non-roundabout
     * maneuvers.
     */
    val angle: Int,
    /** Roundabout exit number `1..19`; 0 for non-roundabout maneuvers. */
    val number: Int,
    /** Road the maneuver leads onto (UTF-8). */
    val road: String,
    /**
     * Where the maneuver is COMPLETE — the point on the route past which guidance may move on to
     * the next instruction. Defaults to the maneuver point itself; a roundabout sets it to the
     * exit so the HUD keeps the roundabout glyph while the car is still circulating.
     */
    val endLat: Double = lat,
    val endLng: Double = lng,
    /**
     * The approach lanes at this maneuver, left to right; empty when the source gives none (the
     * common case — most maneuvers carry no lane data).
     */
    val lanes: List<NavLane> = emptyList(),
)

/**
 * One approach lane at a maneuver, in HUD-ready terms.
 *
 * Deliberately geometric rather than symbolic: a lane is "the set of directions you may take from
 * it", which every routing source can express and the HUD can bucket into its own lane glyphs. No
 * provider vocabulary (Mapbox indications, iAP2 lane TLVs) survives past its parser.
 */
class NavLane(
    /**
     * Every direction this lane allows, in degrees: 0 = straight, negative = left, positive =
     * right (so -90 = left, 30 = slight right, -180 = U-turn to the left). At most 8.
     */
    val angles: List<Int>,
    /** The one direction the route takes from this lane, in degrees, or null for none. */
    val highlight: Int? = null,
    /** Is this a lane the driver should be in for the maneuver? */
    val recommended: Boolean = false,
) {
    companion object {
        /**
         * What one lane row can carry. Both mirror the HUD model's `NAV_LANE_MAX` /
         * `NAV_LANE_ANGLES_MAX` (`vegvisir-client/mazda/core/nav_types.h`), which in turn mirror
         * the cluster's own 8-slot lane row — anything past this is dropped, not scaled.
         */
        const val MAX_LANES = 8
        const val MAX_ANGLES = 8
    }
}

/**
 * Maneuver kinds, provider-neutral. Numbering follows Android-Auto hu.proto (sparse) to match
 * `vegvisir-client/mazda/core/nav_types.h` and the server's `Navigation` schema — every provider
 * maps its own maneuver types onto these.
 */
object NavEvent {
    const val UNKNOWN = 0
    const val DEPART = 1
    const val NAME_CHANGE = 2
    const val SLIGHT = 3
    const val TURN = 4
    const val SHARP = 5
    const val UTURN = 6
    const val ON_RAMP = 7
    const val OFF_RAMP = 8
    const val FORK = 9
    const val MERGE = 10
    const val ROUNDABOUT = 13   // directional glyph chosen from `angle`
    const val STRAIGHT = 14
    const val FERRY = 16
    const val DEST = 19
}

/** Turn side, provider-neutral (matches hu.proto TURN_SIDE). */
object NavSide {
    const val LEFT = 1
    const val RIGHT = 2
    const val NONE = 3   // unspecified / straight
}
