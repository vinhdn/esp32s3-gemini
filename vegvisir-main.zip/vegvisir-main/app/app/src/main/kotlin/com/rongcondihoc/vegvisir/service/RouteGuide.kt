package com.rongcondihoc.vegvisir.service

import android.location.Location
import android.os.SystemClock
import android.util.Log
import com.rongcondihoc.vegvisir.service.vietmap.FileLog

/**
 * The provider-neutral guidance engine: it takes ONE standard [NavRoute] and, driven by
 * [GpsService] fixes, turns the current position into live HUD navigation.
 *
 * It is deliberately source-agnostic. A navigation provider (VietMap via [vietmap.RouteParser],
 * Google Maps later) parses its own API into a [NavRoute] and calls [setRoute]; this engine
 * never parses provider JSON, decodes geometry, or knows any maneuver vocabulary beyond the
 * standard model. Its only job is:
 *   1. hold the current route,
 *   2. on each fix ([onLocation]) snap the position onto the route, find the maneuver in play and
 *      the remaining distance to it — holding the current one until the turn is behind us, and
 *      ending guidance ([finish]) once the destination is reached or the car has left the route
 *      for good — and
 *   3. emit one canonical HUD-sink [com.rongcondihoc.vegvisir.server.Navigation] JSON, which the
 *      native [VietmapClient] forwards to the Vegvisir server for relay to mazda.
 *
 * Everything is best-effort: a bad route or fix clears/holds guidance rather than crashing.
 */
object RouteGuide {

    private const val TAG = "VietMapHook"

    // Ignore fixes further than this from the route — the car is off-route (or the fix is
    // stale/garbage), so emitting a maneuver would be misleading.
    private const val OFF_ROUTE_METERS = 150.0

    // How long the car may stay continuously off-route before guidance gives up, blanks the HUD
    // and disarms. A missed turn is not this: VietMap reroutes and re-arms within seconds, which
    // resets the clock. Staying away this long means the trip is over in practice — the driver
    // cancelled it and drove on — and VietMap gives us NO signal for that (verified on device: no
    // platform-channel call and no API request marks the end of a trip), so this watchdog is the
    // only thing that stops the last maneuver sitting on the cluster forever.
    private const val OFF_ROUTE_GIVE_UP_MS = 120_000L

    // Send-rate bounds. The ceiling caps countdown-only chatter (two location providers can each
    // tick at 1 Hz); it never delays a maneuver change, which is a real turn announcement.
    private const val MIN_SEND_INTERVAL_MS = 500L

    // The floor: re-send the current frame even when nothing changed, so a mazda client that
    // connected (or reconnected) while the car sat still — no key change, so nothing to emit —
    // still learns the current state instead of showing a blank HUD until the car moves 10 m.
    // Driven by the GPS tick, so it is silent while off-route or with no fixes, by design.
    private const val MAX_SEND_INTERVAL_MS = 2000L

    // How far PAST a maneuver the car must travel before guidance moves on to the next one.
    // Without it the HUD switches instruction the moment the snapped position crosses the corner
    // vertex — i.e. while the driver is still turning. Clamped per maneuver to half the gap to
    // the next one (see [compile]) so back-to-back maneuvers are never held past their own turn.
    private const val MANEUVER_PASSED_METERS = 25.0

    // Distance to the final maneuver at which the trip counts as finished: guidance blanks the
    // HUD and disarms. VietMap's own end-of-trip channel signal is unproven, so arrival is
    // detected geometrically instead of waiting for it.
    private const val ARRIVED_METERS = 25.0

    // How close the maneuver has to be before the lane arrows go up. Lane guidance answers "which
    // lane do I need NOW": held up 3 km early it is clutter, and it would sit on the cluster
    // through every junction in between — none of which it describes.
    private const val LANE_SHOW_METERS = 500

    /** A route compiled for guidance: the standard route plus the geometry lookups we precompute. */
    private class Compiled(
        val route: NavRoute,
        val cum: DoubleArray,         // cum[i] = metres from points[0] to points[i]
        val maneuverIdx: IntArray,    // points index nearest each maneuver (index-aligned)
        val passDist: DoubleArray,    // along-route metres past which maneuver i is behind us
    )

    @Volatile
    private var compiled: Compiled? = null

    @Volatile
    private var speedLimit: Int = 0

    // De-dupes identical emits so the HUD only sees real changes (distance still updates at 1 Hz).
    @Volatile
    private var lastKey: String = ""

    // The maneuver half of [lastKey], tracked separately: a change here bypasses the send-rate
    // ceiling so a new turn reaches the HUD on the very fix that produced it.
    @Volatile
    private var lastManeuverKey: String = ""

    @Volatile
    private var lastSentAt: Long = 0L

    // When the current off-route stretch began (0 = we are on the route). Drives the give-up
    // watchdog; reset by every on-route fix and by every freshly armed route.
    @Volatile
    private var offRouteSince: Long = 0L

    /**
     * Where an emitted HUD Navigation JSON goes. RouteGuide is a per-process singleton, so each
     * hook sets the transport that fits its host: the VietMap hook leaves this null and the frame
     * goes out over JNI to libvietmaphook's native VietmapClient (default); the Google Maps hook —
     * which runs in a process where that native lib is not loaded — sets a pure-Kotlin sink
     * ([com.rongcondihoc.vegvisir.service.googlemaps.GoogleServerClient]) instead.
     */
    @Volatile
    private var sink: ((String) -> Unit)? = null

    /** Install a transport for emitted frames (Google path). Null (default) uses the JNI VietMap path. */
    fun setSink(sink: (String) -> Unit) {
        this.sink = sink
    }

    /**
     * Install a new route to guide along (or null to stop guidance). Called by a provider once it
     * has parsed its source into the standard model. Emits immediately from the last known fix so
     * the HUD updates without waiting for the next GPS tick.
     */
    fun setRoute(route: NavRoute?) {
        if (route == null || route.points.size < 2 || route.maneuvers.isEmpty()) {
            val wasArmed = compiled != null
            compiled = null
            resetSendState()
            Log.w(TAG, "route: cleared (no usable route)")
            // Tell the HUD guidance ended; without this the sink's keep-alive keeps re-asserting
            // the last maneuver forever, so a cancelled route stays on the cluster.
            if (wasArmed) sendClear()
            return
        }
        compiled = compile(route)
        resetSendState()
        Log.i(TAG, "route: armed (${route.maneuvers.size} maneuvers, ${route.points.size} pts)")
        dumpRoute(route)
        GpsService.last()?.let { onLocation(it) }
    }

    /**
     * Latest posted speed limit (km/h), folded into each emitted frame; 0 = none. Fed by
     * [vietmap.Hook] FlutterHook, event-driven and independent of GPS.
     *
     * It only stores the value — the next GPS tick (≤1 s) carries it out. Deliberately no
     * re-emit here: the feeding Flutter channel is VietMap's map-matching stream, which fires far
     * faster than 1 Hz and can flap (60 → 0 → 60) whenever matching drops a segment. Since the
     * limit is part of the emit de-dupe key, re-emitting on every change let that flap drive the
     * send rate and blink the HUD's speed sign. Binding it to the GPS tick makes the fix the
     * single source of cadence; MAX_SEND_INTERVAL_MS covers the case where the car is stopped.
     */
    fun updateSpeedLimit(kmh: Int) {
        if (kmh < 0 || kmh == speedLimit) return
        speedLimit = kmh
    }

    /**
     * Snap [location] onto the current route, pick the next maneuver, and emit HUD JSON.
     * Called from [GpsService]'s listener thread (and once from [setRoute]).
     */
    fun onLocation(location: Location) {
        val c = compiled ?: return
        try {
            val p = snap(c, location.latitude, location.longitude)
            if (p.distanceM > OFF_ROUTE_METERS) {
                // Off-route: hold the last frame rather than emit a bogus maneuver — a reroute
                // normally lands within seconds. If it never does, give up (see the constant).
                val now = SystemClock.elapsedRealtime()
                if (offRouteSince == 0L) {
                    offRouteSince = now
                    // Once per off-route stretch, so the log shows the give-up clock starting.
                    Log.i(TAG, "route: off-route (${p.distanceM.toInt()}m) — holding last frame")
                } else if (now - offRouteSince >= OFF_ROUTE_GIVE_UP_MS) {
                    finish("off-route for ${(now - offRouteSince) / 1000}s, ${p.distanceM.toInt()}m away")
                }
                return
            }
            offRouteSince = 0L
            val progress = p.progressM

            // The maneuver in play is the first one we have not driven PAST yet. Passing is
            // measured against [Compiled.passDist], which sits a short way beyond the maneuver's
            // end point, so the current instruction stays on the HUD until the turn (or the whole
            // roundabout) is actually behind us instead of flipping at the corner.
            val n = c.passDist.indexOfFirst { progress < it }
                .let { if (it < 0) c.passDist.size - 1 else it }

            val remaining = (c.cum[c.maneuverIdx[n]] - progress).coerceAtLeast(0.0)

            // End of route: blank the HUD and disarm, instead of pinning the arrive glyph there
            // forever (the keep-alive would keep re-asserting it long after the trip ended).
            if (n == c.passDist.size - 1 && remaining <= ARRIVED_METERS) {
                finish("arrived")
                return
            }

            val m = c.route.maneuvers[n]
            val speed = location.speed  // m/s
            val eta = if (speed > 2f) (remaining / speed).toInt() else 0

            emit(m, remaining.toInt(), eta)
        } catch (t: Throwable) {
            Log.e(TAG, "route: guidance failed: $t")
        }
    }

    /**
     * Dump the freshly armed route's maneuver list to `vegvisir.log` (one line per maneuver), so the
     * captured guidance is inspectable offline alongside the raw API body. Best-effort; never throws.
     */
    private fun dumpRoute(route: NavRoute) {
        FileLog.line("route: armed (${route.maneuvers.size} maneuvers, ${route.points.size} pts)")
        route.maneuvers.forEachIndexed { i, m ->
            val lanes = m.lanes.joinToString(" ") { lane ->
                val hl = lane.highlight?.toString() ?: "-"
                "${lane.angles.joinToString(",")}${if (lane.recommended) "*" else ""}(hl=$hl)"
            }
            FileLog.line(
                "  [$i] event=${m.event} side=${m.side} angle=${m.angle} number=${m.number} " +
                    "road=\"${m.road}\" @ ${m.lat},${m.lng}" +
                    if (lanes.isEmpty()) "" else " lanes=[$lanes]"
            )
        }
    }

    // ---- Emit ---------------------------------------------------------------

    /**
     * Decide whether this frame goes on the wire, then send it. Three tiers, loosest first:
     *   - the maneuver itself changed  → always send (a turn announcement is never held back),
     *   - only the countdown changed   → send, but no more often than MIN_SEND_INTERVAL_MS,
     *   - nothing changed              → send only as the MAX_SEND_INTERVAL_MS heartbeat.
     */
    private fun emit(m: NavManeuver, distanceM: Int, etaSec: Int) {
        // Lane arrows are gated on proximity (see the constant). A maneuver's lane list never
        // changes once the route is armed, so crossing the gate is the only way this can differ
        // within one maneuver — hence the size alone identifies it in the de-dupe key below.
        val lanes = if (distanceM <= LANE_SHOW_METERS) m.lanes else emptyList()

        val maneuverKey = "${m.event}|${m.side}|${m.angle}|${m.number}|${m.road}"
        // Round distance to 10 m for the change key so we still refresh the countdown without
        // spamming an identical frame every tick.
        val key = "$maneuverKey|${distanceM / 10}|$speedLimit|${lanes.size}"

        val now = SystemClock.elapsedRealtime()
        val sinceLast = now - lastSentAt
        if (maneuverKey == lastManeuverKey) {
            if (key == lastKey) {
                if (sinceLast < MAX_SEND_INTERVAL_MS) return
            } else if (sinceLast < MIN_SEND_INTERVAL_MS) {
                return
            }
        }
        lastKey = key
        lastManeuverKey = maneuverKey
        lastSentAt = now

        val json = org.json.JSONObject()
            .put("active", true)
            .put("event", m.event)
            .put("side", m.side)
            .put("angle", m.angle)
            .put("number", m.number)
            .put("road", m.road)
            .put("distance", distanceM)
            .put("unit", 0)          // 0 = let the HUD sink auto-pick metres/km
            .put("eta", etaSec)
            .put("speedLimit", speedLimit)
            // Omitted when there are none: the HUD sink reads a missing key as "no lanes now" and
            // blanks the row, which is exactly what an out-of-gate or lane-less maneuver wants.
            .apply { if (lanes.isNotEmpty()) put("lanes", lanesJson(lanes)) }
            .toString()

        Log.i(TAG, "nav ▶ event=${m.event} side=${m.side} road=\"${m.road}\" dist=${distanceM}m " +
            "eta=${etaSec}s speedLimit=$speedLimit lanes=${lanes.size}")
        send(json)
    }

    /**
     * The lane row in the canonical HUD-sink shape — the one nested field in the schema, documented
     * with the rest of it at the top of vegvisir-client's `hudnav_provider.cpp`.
     */
    private fun lanesJson(lanes: List<NavLane>): org.json.JSONArray {
        val arr = org.json.JSONArray()
        for (lane in lanes.take(NavLane.MAX_LANES)) {
            val angles = org.json.JSONArray()
            lane.angles.take(NavLane.MAX_ANGLES).forEach { angles.put(it) }
            val o = org.json.JSONObject()
                .put("angles", angles)
                .put("recommended", lane.recommended)
            lane.highlight?.let { o.put("highlight", it) }
            arr.put(o)
        }
        return arr
    }

    /**
     * Guidance is over for [reason]: disarm the route and blank the HUD. Both ways a trip can end
     * without VietMap telling us — reaching the destination, and giving up after a long off-route
     * stretch — land here, so the wind-down is identical either way.
     */
    private fun finish(reason: String) {
        compiled = null
        resetSendState()
        Log.i(TAG, "route: guidance ended ($reason)")
        FileLog.line("route: guidance ended ($reason)")
        sendClear()
    }

    /** Emit the guidance-ended frame; the HUD sink blanks the maneuver on `active:false`. */
    private fun sendClear() {
        Log.i(TAG, "nav ▶ active=false (guidance ended)")
        send("""{"active":false}""")
    }

    private fun send(json: String) {
        try {
            val s = sink
            if (s != null) s(json) else nativeSendNavigation(json)
        } catch (t: Throwable) {
            Log.e(TAG, "route: send failed: $t")
        }
    }

    /**
     * Forget what was last sent so the next frame is never de-duped against a stale route, and
     * clear the off-route clock so a fresh route never inherits the previous one's give-up timer.
     */
    private fun resetSendState() {
        lastKey = ""
        lastManeuverKey = ""
        lastSentAt = 0L
        offRouteSince = 0L
    }

    // ---- Geometry -----------------------------------------------------------

    private fun compile(route: NavRoute): Compiled {
        val pts = route.points
        val cum = DoubleArray(pts.size)
        for (i in 1 until pts.size) {
            cum[i] = cum[i - 1] + haversine(pts[i - 1], pts[i])
        }
        val count = route.maneuvers.size
        val idx = IntArray(count) { i ->
            val m = route.maneuvers[i]
            nearest(pts, m.lat, m.lng).index
        }
        // Where each maneuver ends — its own point, except for a roundabout, which ends at the
        // exit. Never before the maneuver point itself.
        val endIdx = IntArray(count) { i ->
            val m = route.maneuvers[i]
            if (m.endLat == m.lat && m.endLng == m.lng) idx[i]
            else nearest(pts, m.endLat, m.endLng).index.coerceAtLeast(idx[i])
        }
        val passDist = DoubleArray(count) { i ->
            when {
                // The final maneuver is never "passed" — reaching it is arrival, handled in
                // [onLocation], so nothing may advance beyond it.
                i == count - 1 -> Double.MAX_VALUE
                // "Depart" is a start marker, not an instruction: hand the HUD the first real
                // maneuver right away rather than dwelling on the departure flag.
                route.maneuvers[i].event == NavEvent.DEPART -> 0.0
                else -> {
                    val end = cum[endIdx[i]]
                    val gap = (cum[idx[i + 1]] - end).coerceAtLeast(0.0)
                    end + minOf(MANEUVER_PASSED_METERS, gap / 2)
                }
            }
        }
        return Compiled(route, cum, idx, passDist)
    }

    /** A fix snapped onto the route: how far along it we are, and how far off it we sit. */
    private class Snap(val progressM: Double, val distanceM: Double)

    /**
     * Snap (lat,lng) onto the route: the closest point on any polyline SEGMENT, as metres
     * travelled along the route plus the perpendicular distance to it.
     *
     * Projecting onto segments rather than onto the nearest vertex keeps progress continuous: the
     * countdown ticks smoothly instead of in vertex-sized jumps, and "we are past this maneuver"
     * becomes a real distance rather than a side effect of where the polyline happens to have a
     * point. Distances are computed in a local flat frame around the fix — good to centimetres at
     * these ranges and far cheaper than a haversine per segment.
     */
    private fun snap(c: Compiled, lat: Double, lng: Double): Snap {
        val pts = c.route.points
        val mPerDegLat = 111320.0
        val mPerDegLng = 111320.0 * Math.cos(Math.toRadians(lat))
        var bestDist = Double.MAX_VALUE
        var bestProgress = 0.0
        for (i in 0 until pts.size - 1) {
            // The fix is the origin; a, b are the segment ends in metres relative to it.
            val ax = (pts[i][1] - lng) * mPerDegLng
            val ay = (pts[i][0] - lat) * mPerDegLat
            val bx = (pts[i + 1][1] - lng) * mPerDegLng
            val by = (pts[i + 1][0] - lat) * mPerDegLat
            val dx = bx - ax
            val dy = by - ay
            val len2 = dx * dx + dy * dy
            val t = if (len2 <= 0.0) 0.0 else (((-ax) * dx + (-ay) * dy) / len2).coerceIn(0.0, 1.0)
            val px = ax + t * dx
            val py = ay + t * dy
            val d = Math.sqrt(px * px + py * py)
            if (d < bestDist) {
                bestDist = d
                bestProgress = c.cum[i] + t * (c.cum[i + 1] - c.cum[i])
            }
        }
        return Snap(bestProgress, bestDist)
    }

    private class Nearest(val index: Int, val distanceM: Double)

    /** Nearest polyline vertex to (lat,lng) by great-circle distance (linear scan). */
    private fun nearest(points: List<DoubleArray>, lat: Double, lng: Double): Nearest {
        var bestIdx = 0
        var bestDist = Double.MAX_VALUE
        val here = doubleArrayOf(lat, lng)
        for (i in points.indices) {
            val d = haversine(here, points[i])
            if (d < bestDist) {
                bestDist = d
                bestIdx = i
            }
        }
        return Nearest(bestIdx, bestDist)
    }

    private fun haversine(a: DoubleArray, b: DoubleArray): Double {
        val radius = 6371000.0
        val dLat = Math.toRadians(b[0] - a[0])
        val dLng = Math.toRadians(b[1] - a[1])
        val s = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(Math.toRadians(a[0])) * Math.cos(Math.toRadians(b[0])) *
            Math.sin(dLng / 2) * Math.sin(dLng / 2)
        return radius * 2 * Math.atan2(Math.sqrt(s), Math.sqrt(1 - s))
    }

    /** JNI: hands one HUD Navigation JSON to libvietmaphook's VietmapClient for forwarding. */
    private external fun nativeSendNavigation(json: String)
}
