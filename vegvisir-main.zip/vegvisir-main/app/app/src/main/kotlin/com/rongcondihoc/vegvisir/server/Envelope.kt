package com.rongcondihoc.vegvisir.server

import com.rongcondihoc.vegvisir.domain.MessageType

/**
 * The "VEG1" envelope framing — the Kotlin port of the former C++ codec
 * (core/protocol/envelope.*). Byte layout is NORMATIVE and must stay identical
 * to the mazda client (vegvisir-client) and the vietmap hook, both of which
 * still speak this wire format from C++.
 *
 * Fixed header (19 bytes), all integers big-endian:
 *   magic(4) "VEG1" | version(1) | type(1) | flags(1) | id(4) | replyTo(4) | bodyLen(4)
 * followed by `bodyLen` body bytes.
 */
object Veg {
    const val HEADER_SIZE = 19
    const val VERSION = 1
    const val MAX_BODY = 16 * 1024 * 1024   // guards against bogus lengths
}

/** Parsed fixed header. [type] is the raw wire value (see [MessageType]). */
data class FrameHeader(
    val type: Int,
    val binary: Boolean,
    val id: Int,
    val replyTo: Int,
    val bodyLen: Int,
)

/** Serialize a full envelope (header + body) into the bytes to write on the socket. */
fun encodeEnvelope(
    type: Int,
    body: ByteArray,
    id: Int = 0,
    replyTo: Int = 0,
    binary: Boolean = false,
): ByteArray {
    val out = ByteArray(Veg.HEADER_SIZE + body.size)
    out[0] = 'V'.code.toByte()
    out[1] = 'E'.code.toByte()
    out[2] = 'G'.code.toByte()
    out[3] = '1'.code.toByte()
    out[4] = Veg.VERSION.toByte()
    out[5] = type.toByte()
    out[6] = if (binary) 0x01 else 0x00
    putU32(out, 7, id)
    putU32(out, 11, replyTo)
    putU32(out, 15, body.size)
    body.copyInto(out, Veg.HEADER_SIZE)
    return out
}

/** Convenience: build a text (JSON) message with no attached binary. */
fun encodeJsonMessage(type: MessageType, json: String, id: Int = 0, replyTo: Int = 0): ByteArray =
    encodeEnvelope(type.wireValue, json.toByteArray(Charsets.UTF_8), id, replyTo, binary = false)

/** Parse the fixed header from [Veg.HEADER_SIZE] bytes; null on bad magic/version. */
fun parseEnvelopeHeader(b: ByteArray): FrameHeader? {
    if (b.size < Veg.HEADER_SIZE) return null
    if (b[0] != 'V'.code.toByte() || b[1] != 'E'.code.toByte() ||
        b[2] != 'G'.code.toByte() || b[3] != '1'.code.toByte()
    ) {
        return null
    }
    if ((b[4].toInt() and 0xFF) != Veg.VERSION) return null
    return FrameHeader(
        type = b[5].toInt() and 0xFF,
        binary = (b[6].toInt() and 0x01) != 0,
        id = getU32(b, 7),
        replyTo = getU32(b, 11),
        bodyLen = getU32(b, 15),
    )
}

private fun putU32(b: ByteArray, off: Int, v: Int) {
    b[off] = (v ushr 24).toByte()
    b[off + 1] = (v ushr 16).toByte()
    b[off + 2] = (v ushr 8).toByte()
    b[off + 3] = v.toByte()
}

private fun getU32(b: ByteArray, off: Int): Int =
    ((b[off].toInt() and 0xFF) shl 24) or
        ((b[off + 1].toInt() and 0xFF) shl 16) or
        ((b[off + 2].toInt() and 0xFF) shl 8) or
        (b[off + 3].toInt() and 0xFF)
