package com.rongcondihoc.vegvisir.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.rongcondihoc.vegvisir.service.VegvisirService
import com.rongcondihoc.vegvisir.ui.navigation.VegvisirNavHost
import com.rongcondihoc.vegvisir.ui.theme.VegvisirTheme

class MainActivity : ComponentActivity() {

    // Android 13+ needs runtime consent to show the foreground-service notification. The service
    // still runs without it — only the persistent notification is suppressed — so we ask but don't
    // block on the result.
    private val requestNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* best-effort */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ensureNotificationPermission()
        // Ensure the server service is up from a guaranteed-foreground context.
        VegvisirService.start(this)

        enableEdgeToEdge()
        setContent {
            VegvisirTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    VegvisirNavHost()
                }
            }
        }
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) requestNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
}
