package com.rongcondihoc.vegvisir.ui.screen.navsource

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rongcondihoc.vegvisir.domain.ClientType
import com.rongcondihoc.vegvisir.domain.EngineState
import com.rongcondihoc.vegvisir.domain.NavSource
import com.rongcondihoc.vegvisir.ui.component.StatusDot

/**
 * Navigation source picker: a single-choice list of None / VietMap / Google Maps, each map source
 * annotated with whether its hook is currently connected to the server.
 *
 * Two tap targets per row: the radio button picks the source that drives the HUD, and a row whose
 * source is connected pushes that provider's detail page (the trailing chevron marks it). A row
 * with nothing to open just selects.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NavSourceScreen(
    selected: NavSource,
    state: EngineState,
    onSelect: (NavSource) -> Unit,
    onOpenDetail: (ClientType) -> Unit,
    onBack: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Navigation source") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { inner ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                "Only the selected source is relayed to the HUD; the others keep running but are " +
                    "dropped. Switching (and None) blanks the cluster.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            ) {
                Column(Modifier.selectableGroup()) {
                    NavSource.entries.forEachIndexed { index, source ->
                        if (index > 0) HorizontalDivider()
                        SourceRow(
                            source = source,
                            selected = source == selected,
                            connected = source.clientType?.let(state::isConnected) ?: false,
                            onSelect = { onSelect(source) },
                            onOpenDetail = { source.clientType?.let(onOpenDetail) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SourceRow(
    source: NavSource,
    selected: Boolean,
    connected: Boolean,
    onSelect: () -> Unit,
    onOpenDetail: () -> Unit,
) {
    // A detail page exists only for a map source that is currently connected.
    val openable = source.clientType != null && connected

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = if (openable) onOpenDetail else onSelect)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onSelect)
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Text(source.label, style = MaterialTheme.typography.bodyLarge)
            if (source.clientType != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusDot(connected = connected, size = 8)
                    Spacer(Modifier.size(6.dp))
                    Text(
                        text = if (connected) "Connected" else "Not connected",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        if (openable) {
            Icon(
                Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Open ${source.label} details",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
