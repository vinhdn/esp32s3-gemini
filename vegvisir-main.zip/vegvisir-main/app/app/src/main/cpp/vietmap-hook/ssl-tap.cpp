#include "ssl-tap.h"

#include <dlfcn.h>
#include <elf.h>
#include <link.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstring>
#include <deque>
#include <mutex>
#include <thread>
#include <vector>

#include "util/log.h"
#include "shadowhook.h"

namespace ssltap {
namespace {

std::atomic<bool> g_started{false};
uintptr_t g_readOff = 0;
uintptr_t g_writeOff = 0;
std::string g_expectBuildId;
Sink g_sink;

// Plaintext queue — DECOUPLED from the host app's network thread. If the sink is slow the queue
// grows, but it must never slow Vietmap's SSL_read down.
struct Chunk {
    uint64_t ssl;
    bool isRead;
    std::vector<uint8_t> data;
};

std::mutex g_qm;
std::condition_variable g_qcv;
std::deque<Chunk> g_queue;
size_t g_qbytes = 0;
constexpr size_t kQueueCap = 8 * 1024 * 1024;

void enqueue(void *ssl, const void *buf, int len, bool isRead) {
    if (len <= 0 || buf == nullptr) return;
    std::lock_guard<std::mutex> lk(g_qm);
    if (g_qbytes + static_cast<size_t>(len) > kQueueCap) return;  // full -> drop the frame, keep the app smooth
    Chunk c;
    c.ssl = static_cast<uint64_t>(reinterpret_cast<uintptr_t>(ssl));
    c.isRead = isRead;
    c.data.assign(static_cast<const uint8_t *>(buf), static_cast<const uint8_t *>(buf) + len);
    g_qbytes += c.data.size();
    g_queue.push_back(std::move(c));
    g_qcv.notify_one();
}

using SSL_read_t = int (*)(void *, void *, int);
using SSL_write_t = int (*)(void *, const void *, int);
SSL_read_t g_origRead = nullptr;
SSL_write_t g_origWrite = nullptr;

int proxyRead(void *ssl, void *buf, int num) {
    int r = g_origRead ? g_origRead(ssl, buf, num) : -1;
    if (r > 0) enqueue(ssl, buf, r, true);
    return r;
}

int proxyWrite(void *ssl, const void *buf, int num) {
    int r = g_origWrite ? g_origWrite(ssl, buf, num) : -1;
    if (r > 0) enqueue(ssl, buf, r, false);
    return r;
}

uintptr_t moduleBase(const char *name) {
    struct Ctx {
        const char *name;
        uintptr_t base;
    } ctx{name, 0};
    dl_iterate_phdr(
            [](struct dl_phdr_info *info, size_t, void *d) -> int {
                auto *c = static_cast<Ctx *>(d);
                if (info->dlpi_name != nullptr && strstr(info->dlpi_name, c->name) != nullptr) {
                    c->base = static_cast<uintptr_t>(info->dlpi_addr);
                    return 1;
                }
                return 0;
            },
            &ctx);
    return ctx.base;
}

bool moduleBuildId(const char *name, std::string &out) {
    struct Ctx {
        const char *name;
        std::string *out;
        bool found;
    } ctx{name, &out, false};

    dl_iterate_phdr(
            [](struct dl_phdr_info *info, size_t, void *d) -> int {
                auto *c = static_cast<Ctx *>(d);
                if (info->dlpi_name == nullptr || strstr(info->dlpi_name, c->name) == nullptr) {
                    return 0;
                }
                for (int i = 0; i < info->dlpi_phnum; i++) {
                    const ElfW(Phdr) *ph = &info->dlpi_phdr[i];
                    if (ph->p_type != PT_NOTE) continue;
                    auto p = reinterpret_cast<const uint8_t *>(info->dlpi_addr + ph->p_vaddr);
                    auto end = p + ph->p_memsz;
                    while (p + sizeof(ElfW(Nhdr)) <= end) {
                        auto *nh = reinterpret_cast<const ElfW(Nhdr) *>(p);
                        const char *nm = reinterpret_cast<const char *>(p + sizeof(ElfW(Nhdr)));
                        const uint8_t *desc = reinterpret_cast<const uint8_t *>(
                                nm + ((nh->n_namesz + 3) & ~3u));
                        if (nh->n_type == NT_GNU_BUILD_ID && nh->n_namesz == 4 &&
                            strncmp(nm, "GNU", 3) == 0) {
                            static const char *hx = "0123456789abcdef";
                            std::string s;
                            for (uint32_t k = 0; k < nh->n_descsz; k++) {
                                s += hx[desc[k] >> 4];
                                s += hx[desc[k] & 0xf];
                            }
                            *c->out = s;
                            c->found = true;
                            return 1;
                        }
                        p = desc + ((nh->n_descsz + 3) & ~3u);
                    }
                }
                return 1;
            },
            &ctx);
    return ctx.found;
}

void hookerThread() {
    // libflutter loads late (when the FlutterEngine is built), so wait up to 60 s.
    uintptr_t base = 0;
    for (int i = 0; i < 120 && base == 0; i++) {
        base = moduleBase("libflutter.so");
        if (base == 0) std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
    if (base == 0) {
        LOGW("libflutter.so not loaded -> skipping the SSL hook");
        return;
    }

    std::string bid;
    if (moduleBuildId("libflutter.so", bid) && !g_expectBuildId.empty() && bid != g_expectBuildId) {
        LOGW("libflutter build-id MISMATCH (got=%s expect=%s) -> NOT hooking (avoiding a crash)",
             bid.c_str(), g_expectBuildId.c_str());
        return;
    }

    void *raddr = reinterpret_cast<void *>(base + g_readOff);
    void *waddr = reinterpret_cast<void *>(base + g_writeOff);
    void *sr = shadowhook_hook_func_addr(raddr, reinterpret_cast<void *>(proxyRead),
                                         reinterpret_cast<void **>(&g_origRead));
    void *sw = shadowhook_hook_func_addr(waddr, reinterpret_cast<void *>(proxyWrite),
                                         reinterpret_cast<void **>(&g_origWrite));
    LOGI("hook libflutter base=0x%zx SSL_read@%p(stub=%p) SSL_write@%p(stub=%p)",
         static_cast<size_t>(base), raddr, sr, waddr, sw);
}

void drainThread() {
    for (;;) {
        Chunk c;
        {
            std::unique_lock<std::mutex> lk(g_qm);
            g_qcv.wait_for(lk, std::chrono::seconds(2), [] { return !g_queue.empty(); });
            if (g_queue.empty()) continue;
            c = std::move(g_queue.front());
            g_queue.pop_front();
            g_qbytes -= c.data.size();
        }
        if (g_sink) g_sink(c.ssl, c.isRead, c.data.data(), c.data.size());
    }
}

}  // namespace

void start(uintptr_t readOff, uintptr_t writeOff, const std::string &expectBuildId, Sink sink) {
    if (g_started.exchange(true)) return;

    g_readOff = readOff;
    g_writeOff = writeOff;
    g_expectBuildId = expectBuildId;
    g_sink = std::move(sink);

    int r = shadowhook_init(SHADOWHOOK_MODE_UNIQUE, false);
    LOGI("shadowhook_init=%d read_off=0x%zx write_off=0x%zx", r, static_cast<size_t>(readOff),
         static_cast<size_t>(writeOff));

    std::thread(hookerThread).detach();
    std::thread(drainThread).detach();
}

}  // namespace ssltap
