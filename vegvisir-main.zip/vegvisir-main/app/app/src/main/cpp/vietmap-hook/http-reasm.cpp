#include "http-reasm.h"

#include <zlib.h>

#include <cstring>

#include "util/log.h"

namespace http {
namespace {

// DISCOVERY: log every request line the tap sees (tag "Vegvisir"), regardless of the
// path allowlist, so you can read VietMap's real endpoints and set API_PATHS. If you see
// NOTHING here while driving a route, the SSL tap did not arm (build-id/offset mismatch).
// Set to false once the right paths are configured.
constexpr bool kLogAllRequests = true;

// Responses larger than this are dropped (the largest route JSON observed is ~1 MB). A guard so a
// misdetected binary stream cannot blow up the host app process's memory.
constexpr size_t kMaxResp = 4 * 1024 * 1024;

// Prune the connection table if it grows (an SSL* from a closed connection is never reported closed).
constexpr size_t kMaxConns = 512;

const char *kVerbs[] = {"GET ", "POST ", "PUT ", "DELETE ", "HEAD ", "PATCH ", "OPTIONS "};

bool startsWithVerb(const uint8_t *d, size_t n) {
    for (const char *v : kVerbs) {
        size_t vl = std::strlen(v);
        if (n >= vl && std::memcmp(d, v, vl) == 0) return true;
    }
    return false;
}

std::string lower(const std::string &s) {
    std::string o;
    o.reserve(s.size());
    for (char c : s) o.push_back(static_cast<char>(c >= 'A' && c <= 'Z' ? c + 32 : c));
    return o;
}

long findCrlfCrlf(const std::vector<uint8_t> &b, size_t from) {
    if (b.size() < 4) return -1;
    for (size_t i = from; i + 3 < b.size(); i++) {
        if (b[i] == '\r' && b[i + 1] == '\n' && b[i + 2] == '\r' && b[i + 3] == '\n') {
            return static_cast<long>(i);
        }
    }
    return -1;
}

// Header of a "Name: value" line (case-insensitive) within the block [0,end).
bool header(const std::vector<uint8_t> &b, size_t end, const char *name, std::string &out) {
    const std::string hay = lower(std::string(reinterpret_cast<const char *>(b.data()), end));
    const std::string key = lower(std::string(name)) + ":";
    size_t pos = 0;
    while (pos < hay.size()) {
        size_t nl = hay.find('\n', pos);
        std::string line = hay.substr(pos, (nl == std::string::npos ? hay.size() : nl) - pos);
        if (line.rfind(key, 0) == 0) {
            std::string v = line.substr(key.size());
            size_t b0 = v.find_first_not_of(" \t\r");
            size_t b1 = v.find_last_not_of(" \t\r");
            out = (b0 == std::string::npos) ? "" : v.substr(b0, b1 - b0 + 1);
            return true;
        }
        if (nl == std::string::npos) break;
        pos = nl + 1;
    }
    return false;
}

// De-chunk (Transfer-Encoding: chunked). Returns false if the terminating chunk (size 0) has not been
// seen yet, meaning the response is incomplete.
bool dechunk(const uint8_t *in, size_t n, std::vector<uint8_t> &out, size_t &consumed) {
    size_t i = 0;
    while (i < n) {
        size_t j = i;
        while (j + 1 < n && !(in[j] == '\r' && in[j + 1] == '\n')) j++;
        if (j + 1 >= n) return false;  // size line incomplete
        std::string sizeHex(reinterpret_cast<const char *>(in + i), j - i);
        size_t semi = sizeHex.find(';');
        if (semi != std::string::npos) sizeHex = sizeHex.substr(0, semi);
        char *ep = nullptr;
        long size = std::strtol(sizeHex.c_str(), &ep, 16);
        if (ep == sizeHex.c_str() || size < 0) return false;
        size_t start = j + 2;
        if (size == 0) {                       // terminating chunk -> response complete
            consumed = n;                       // (trailers, if any, are ignored)
            return true;
        }
        if (start + static_cast<size_t>(size) + 2 > n) return false;  // chunk body incomplete
        out.insert(out.end(), in + start, in + start + size);
        i = start + static_cast<size_t>(size) + 2;  // +2 = CRLF sau chunk
    }
    return false;
}

bool gunzip(const uint8_t *in, size_t n, std::vector<uint8_t> &out) {
    z_stream zs;
    std::memset(&zs, 0, sizeof(zs));
    if (inflateInit2(&zs, 15 + 32) != Z_OK) return false;  // +32: auto-detect gzip/zlib
    zs.next_in = const_cast<Bytef *>(in);
    zs.avail_in = static_cast<uInt>(n);
    uint8_t buf[65536];
    int ret = Z_OK;
    do {
        zs.next_out = buf;
        zs.avail_out = sizeof(buf);
        ret = inflate(&zs, Z_NO_FLUSH);
        if (ret != Z_OK && ret != Z_STREAM_END && ret != Z_BUF_ERROR) break;
        out.insert(out.end(), buf, buf + (sizeof(buf) - zs.avail_out));
        if (ret == Z_STREAM_END) break;
        if (ret == Z_BUF_ERROR && zs.avail_in == 0) break;  // out of input before STREAM_END
    } while (ret == Z_OK || ret == Z_BUF_ERROR);
    inflateEnd(&zs);
    return !out.empty();
}

}  // namespace

void Reassembler::onPlaintext(uint64_t ssl, bool isRead, const uint8_t *data, size_t len) {
    if (data == nullptr || len == 0) return;
    if (conns.size() > kMaxConns) {
        for (auto it = conns.begin(); it != conns.end();) {
            if (it->second.resp.empty()) it = conns.erase(it);
            else ++it;
        }
    }
    Conn &c = conns[ssl];
    if (isRead) {
        onResponse(ssl, c, data, len);
    } else {
        onRequest(c, data, len);
    }
}

void Reassembler::onRequest(Conn &c, const uint8_t *data, size_t len) {
    // Only the chunk that OPENS a request matters (it has the request line). A POST body arriving in a later chunk is skipped.
    if (!startsWithVerb(data, len)) return;

    // Keep-alive connection: a new request means the previous response (if any) is done -> reset.
    c = Conn{};

    const std::string head(reinterpret_cast<const char *>(data),
                           len < 4096 ? len : 4096);
    size_t sp1 = head.find(' ');
    size_t sp2 = (sp1 == std::string::npos) ? std::string::npos : head.find(' ', sp1 + 1);
    if (sp1 == std::string::npos || sp2 == std::string::npos) return;
    c.method = head.substr(0, sp1);
    c.path = head.substr(sp1 + 1, sp2 - sp1 - 1);

    size_t hpos = lower(head).find("\nhost:");
    if (hpos != std::string::npos) {
        size_t s = hpos + 6;
        size_t e = head.find('\r', s);
        if (e == std::string::npos) e = head.find('\n', s);
        std::string h = head.substr(s, (e == std::string::npos ? head.size() : e) - s);
        size_t b0 = h.find_first_not_of(" \t");
        if (b0 != std::string::npos) c.host = h.substr(b0);
    }

    c.interesting = matchesPath(c.path);

    if (kLogAllRequests) {
        LOGI("req %s %s%s  %s", c.method.c_str(), c.host.c_str(), c.path.c_str(),
             c.interesting ? "[CAPTURE]" : "");
    }
}

bool Reassembler::matchesPath(const std::string &path) const {
    const std::string p = path.substr(0, path.find('?'));
    for (const std::string &want : paths) {
        if (p.size() >= want.size() && p.compare(0, want.size(), want) == 0) return true;
    }
    return false;
}

void Reassembler::onResponse(uint64_t ssl, Conn &c, const uint8_t *data, size_t len) {
    if (!c.interesting) return;
    if (c.resp.size() + len > kMaxResp) {  // too large -> stop tracking until the next request
        c.interesting = false;
        c.resp.clear();
        return;
    }
    c.resp.insert(c.resp.end(), data, data + len);

    if (!c.headerParsed) {
        long sep = findCrlfCrlf(c.resp, 0);
        if (sep < 0) return;
        c.bodyStart = sep + 4;
        c.headerParsed = true;

        size_t nl = 0;
        while (nl < c.resp.size() && c.resp[nl] != '\r') nl++;
        c.status.assign(reinterpret_cast<const char *>(c.resp.data()), nl);

        std::string te, ce, cl;
        if (header(c.resp, static_cast<size_t>(sep), "transfer-encoding", te)) {
            c.chunked = te.find("chunked") != std::string::npos;
        }
        if (header(c.resp, static_cast<size_t>(sep), "content-encoding", ce)) {
            c.gzip = ce.find("gzip") != std::string::npos;
        }
        if (header(c.resp, static_cast<size_t>(sep), "content-length", cl)) {
            char *ep = nullptr;
            long v = std::strtol(cl.c_str(), &ep, 10);
            if (ep != cl.c_str() && v >= 0) c.contentLength = v;
        }
        header(c.resp, static_cast<size_t>(sep), "content-type", c.contentType);
    }
    tryComplete(ssl, c);
}

void Reassembler::tryComplete(uint64_t ssl, Conn &c) {
    if (!c.headerParsed) return;
    const size_t bodyStart = static_cast<size_t>(c.bodyStart);
    const size_t have = c.resp.size() - bodyStart;

    if (c.contentLength >= 0) {
        if (have < static_cast<size_t>(c.contentLength)) return;  // incomplete
        emit(c, bodyStart, bodyStart + static_cast<size_t>(c.contentLength));
        return;
    }
    if (c.chunked) {
        // Is the terminating chunk there yet? de-chunk returns false if not.
        std::vector<uint8_t> tmp;
        size_t consumed = 0;
        if (!dechunk(c.resp.data() + bodyStart, have, tmp, consumed)) return;
        emit(c, bodyStart, c.resp.size());  // chunked: swallow everything collected so far
        return;
    }
    // No Content-Length, not chunked (HTTP/1.0 close-delimited): there is no way to know when it
    // ends -> wait. It gets reset when the next request arrives on the same connection. Vietmap's
    // JSON APIs all use CL or chunked, so this branch almost never runs.
    (void)ssl;
}

void Reassembler::emit(Conn &c, size_t bodyStart, size_t bodyEnd) {
    std::vector<uint8_t> body;
    const uint8_t *raw = c.resp.data() + bodyStart;
    const size_t rawLen = bodyEnd - bodyStart;

    if (c.chunked) {
        size_t consumed = 0;
        if (!dechunk(raw, rawLen, body, consumed)) body.assign(raw, raw + rawLen);
    } else {
        body.assign(raw, raw + rawLen);
    }

    const bool gz = c.gzip || (body.size() > 2 && body[0] == 0x1f &&
                               body[1] == static_cast<uint8_t>(0x8b));
    if (gz) {
        std::vector<uint8_t> plain;
        if (gunzip(body.data(), body.size(), plain)) body.swap(plain);
    }

    Response r;
    r.host = c.host;
    r.method = c.method;
    r.path = c.path;
    r.status = c.status;
    r.contentType = c.contentType;
    r.body = std::move(body);
    if (cb) cb(r);

    // This response is done; wait for the next request on the same connection. Leftover (pipelined)
    // bytes are rare with these APIs, so no effort is made to keep them.
    c.resp.clear();
    c.headerParsed = false;
    c.bodyStart = -1;
    c.status.clear();
    c.contentType.clear();
    c.chunked = false;
    c.gzip = false;
    c.contentLength = -1;
    c.interesting = false;  // avoid collecting the next response's chunks before its request line
}

}  // namespace http
