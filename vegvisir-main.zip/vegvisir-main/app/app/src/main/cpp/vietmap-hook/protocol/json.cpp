#include "json.h"

#include <cstdio>
#include <cstdlib>

namespace vegvisir {
namespace json {
namespace {

// A small recursive-descent parser over a byte range. All payloads we parse are
// UTF-8 JSON produced by our own clients, so the grammar coverage is complete
// enough (objects, arrays, strings, numbers, true/false/null) without the edge
// cases of a general-purpose library (e.g. surrogate pairs, which our keys avoid).
struct Parser {
    const char* p;
    const char* end;

    void skipWs() {
        while (p < end && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) ++p;
    }

    bool parseValue(Value& v) {
        skipWs();
        if (p >= end) return false;
        char c = *p;
        if (c == '"') {
            v.type = Value::Type::String;
            return parseString(v.stringValue);
        }
        if (c == '{') return parseObject(v);
        if (c == '[') return parseArray(v);
        if (c == 't') {
            if (!literal("true", 4)) return false;
            v.type = Value::Type::Bool;
            v.boolValue = true;
            return true;
        }
        if (c == 'f') {
            if (!literal("false", 5)) return false;
            v.type = Value::Type::Bool;
            v.boolValue = false;
            return true;
        }
        if (c == 'n') {
            if (!literal("null", 4)) return false;
            v.type = Value::Type::Null;
            return true;
        }
        return parseNumber(v);
    }

    bool literal(const char* lit, size_t n) {
        if (static_cast<size_t>(end - p) < n) return false;
        for (size_t i = 0; i < n; ++i) {
            if (p[i] != lit[i]) return false;
        }
        p += n;
        return true;
    }

    bool parseNumber(Value& v) {
        const char* start = p;
        if (p < end && (*p == '-' || *p == '+')) ++p;
        bool any = false;
        while (p < end && ((*p >= '0' && *p <= '9') || *p == '.' || *p == 'e' ||
                           *p == 'E' || *p == '+' || *p == '-')) {
            ++p;
            any = true;
        }
        if (!any) return false;
        std::string num(start, p);
        v.type = Value::Type::Number;
        v.numberValue = std::strtod(num.c_str(), nullptr);
        return true;
    }

    bool parseString(std::string& out) {
        if (p >= end || *p != '"') return false;
        ++p;
        while (p < end) {
            char c = *p++;
            if (c == '"') return true;
            if (c != '\\') {
                out += c;
                continue;
            }
            if (p >= end) return false;
            char e = *p++;
            switch (e) {
                case '"': out += '"'; break;
                case '\\': out += '\\'; break;
                case '/': out += '/'; break;
                case 'b': out += '\b'; break;
                case 'f': out += '\f'; break;
                case 'n': out += '\n'; break;
                case 'r': out += '\r'; break;
                case 't': out += '\t'; break;
                case 'u': {
                    if (end - p < 4) return false;
                    int cp = 0;
                    for (int i = 0; i < 4; ++i) {
                        int d = hexDigit(p[i]);
                        if (d < 0) return false;
                        cp = cp * 16 + d;
                    }
                    p += 4;
                    appendUtf8(out, cp);
                    break;
                }
                default: return false;
            }
        }
        return false;  // unterminated string
    }

    bool parseObject(Value& v) {
        v.type = Value::Type::Object;
        ++p;  // consume '{'
        skipWs();
        if (p < end && *p == '}') {
            ++p;
            return true;
        }
        while (p < end) {
            skipWs();
            std::string key;
            if (!parseString(key)) return false;
            skipWs();
            if (p >= end || *p != ':') return false;
            ++p;
            Value child;
            if (!parseValue(child)) return false;
            v.objectValue.emplace_back(std::move(key), std::move(child));
            skipWs();
            if (p >= end) return false;
            if (*p == ',') {
                ++p;
                continue;
            }
            if (*p == '}') {
                ++p;
                return true;
            }
            return false;
        }
        return false;
    }

    bool parseArray(Value& v) {
        v.type = Value::Type::Array;
        ++p;  // consume '['
        skipWs();
        if (p < end && *p == ']') {
            ++p;
            return true;
        }
        while (p < end) {
            Value child;
            if (!parseValue(child)) return false;
            v.arrayValue.push_back(std::move(child));
            skipWs();
            if (p >= end) return false;
            if (*p == ',') {
                ++p;
                continue;
            }
            if (*p == ']') {
                ++p;
                return true;
            }
            return false;
        }
        return false;
    }

    static int hexDigit(char c) {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        return -1;
    }

    static void appendUtf8(std::string& out, int cp) {
        if (cp < 0x80) {
            out += static_cast<char>(cp);
        } else if (cp < 0x800) {
            out += static_cast<char>(0xC0 | (cp >> 6));
            out += static_cast<char>(0x80 | (cp & 0x3F));
        } else {
            out += static_cast<char>(0xE0 | (cp >> 12));
            out += static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
            out += static_cast<char>(0x80 | (cp & 0x3F));
        }
    }
};

}  // namespace

const Value* Value::find(const std::string& key) const {
    if (type != Type::Object) return nullptr;
    for (const auto& kv : objectValue) {
        if (kv.first == key) return &kv.second;
    }
    return nullptr;
}

std::string Value::asString(const std::string& def) const {
    return type == Type::String ? stringValue : def;
}

long long Value::asInt(long long def) const {
    if (type == Type::Number) return static_cast<long long>(numberValue);
    if (type == Type::String) {
        char* endp = nullptr;
        long long n = std::strtoll(stringValue.c_str(), &endp, 10);
        if (endp != stringValue.c_str()) return n;
    }
    return def;
}

bool Value::asBool(bool def) const {
    return type == Type::Bool ? boolValue : def;
}

bool parse(const std::string& text, Value& out) {
    Parser ps{text.data(), text.data() + text.size()};
    if (!ps.parseValue(out)) return false;
    ps.skipWs();
    return ps.p == ps.end;  // reject trailing garbage
}

std::string escape(const std::string& s) {
    std::string out;
    out.reserve(s.size() + 2);
    for (char c : s) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (static_cast<unsigned char>(c) < 0x20) {
                    char buf[7];
                    std::snprintf(buf, sizeof(buf), "\\u%04x", c);
                    out += buf;
                } else {
                    out += c;
                }
        }
    }
    return out;
}

std::string quote(const std::string& s) {
    return "\"" + escape(s) + "\"";
}

}  // namespace json
}  // namespace vegvisir
