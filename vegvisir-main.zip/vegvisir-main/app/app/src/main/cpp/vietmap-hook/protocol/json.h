#pragma once

#include <string>
#include <utility>
#include <vector>

namespace vegvisir {
namespace json {

// A minimal JSON value tree. The core only exchanges small, flat objects
// (register / navigation / upgrade payloads), so this stays deliberately small
// instead of pulling in a full JSON library.
class Value {
public:
    enum class Type { Null, Bool, Number, String, Array, Object };

    Type type = Type::Null;
    bool boolValue = false;
    double numberValue = 0.0;
    std::string stringValue;
    std::vector<Value> arrayValue;
    std::vector<std::pair<std::string, Value>> objectValue;

    bool isObject() const { return type == Type::Object; }

    // Look up an object member by key, or nullptr if missing / not an object.
    const Value* find(const std::string& key) const;

    // Read this value as a string / integer / bool, or the default on a type mismatch.
    std::string asString(const std::string& def = "") const;
    long long asInt(long long def = 0) const;
    bool asBool(bool def = false) const;
};

// Parse a whole JSON document. Returns false on any syntax error.
bool parse(const std::string& text, Value& out);

// Escape a raw string for embedding inside a JSON string literal.
std::string escape(const std::string& s);

// Produce a quoted, escaped JSON string literal ("...").
std::string quote(const std::string& s);

}  // namespace json
}  // namespace vegvisir
