#include "envelope.h"

#include <cstring>

namespace vegvisir {
namespace {

void putU32(std::vector<uint8_t>& out, uint32_t value) {
    out.push_back(static_cast<uint8_t>((value >> 24) & 0xFF));
    out.push_back(static_cast<uint8_t>((value >> 16) & 0xFF));
    out.push_back(static_cast<uint8_t>((value >> 8) & 0xFF));
    out.push_back(static_cast<uint8_t>(value & 0xFF));
}

uint32_t getU32(const uint8_t* p) {
    return (static_cast<uint32_t>(p[0]) << 24) | (static_cast<uint32_t>(p[1]) << 16) |
           (static_cast<uint32_t>(p[2]) << 8) | static_cast<uint32_t>(p[3]);
}

}  // namespace

std::vector<uint8_t> encodeEnvelope(const Envelope& env) {
    std::vector<uint8_t> out;
    out.reserve(kEnvelopeHeaderSize + env.body.size());

    const char magic[4] = {'V', 'E', 'G', '1'};
    out.insert(out.end(), magic, magic + 4);
    out.push_back(kProtocolVersion);
    out.push_back(static_cast<uint8_t>(env.type));
    out.push_back(static_cast<uint8_t>(env.binaryBody ? 0x01 : 0x00));
    putU32(out, env.id);
    putU32(out, env.replyTo);
    putU32(out, static_cast<uint32_t>(env.body.size()));
    out.insert(out.end(), env.body.begin(), env.body.end());
    return out;
}

std::vector<uint8_t> encodeJsonMessage(MessageType type, const std::string& json,
                                       uint32_t id, uint32_t replyTo) {
    Envelope env;
    env.type = type;
    env.id = id;
    env.replyTo = replyTo;
    env.binaryBody = false;
    env.body.assign(json.begin(), json.end());
    return encodeEnvelope(env);
}

bool parseEnvelopeHeader(const uint8_t* data, EnvelopeHeader& out) {
    if (std::memcmp(data, "VEG1", 4) != 0) return false;
    if (data[4] != kProtocolVersion) return false;
    out.type = static_cast<MessageType>(data[5]);
    out.binaryBody = (data[6] & 0x01) != 0;
    out.id = getU32(data + 7);
    out.replyTo = getU32(data + 11);
    out.bodyLen = getU32(data + 15);
    return true;
}

}  // namespace vegvisir
