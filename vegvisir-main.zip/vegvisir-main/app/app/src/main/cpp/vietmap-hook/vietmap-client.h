#pragma once

#include <atomic>
#include <cstdint>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace vietmap {

// A socket client that runs INSIDE vn.vietmap.live (the hooked process) and
// connects to the on-device Vegvisir server as a "vietmap" client. It keeps the
// connection alive (auto-reconnect) and, once the SSL tap has parsed a maneuver,
// forwards it to the server as a Navigation message — the server then routes it
// on to the mazda client(s).
//
// This is deliberately a tiny client (not the full Server): the hooked app must
// stay lightweight and must never be dragged into running the server itself.
class VietmapClient {
public:
    static VietmapClient& instance();

    // Begin connecting in the background. Idempotent.
    void start();
    void stop();

    // Send a Navigation JSON body to the server. No-op if not connected.
    void sendNavigation(const std::string& json);

private:
    VietmapClient() = default;

    void runLoop();
    int connectOnce();
    bool sendFrame(const std::vector<uint8_t>& frame);

    std::atomic<bool> running{false};
    std::thread thread;
    std::mutex sockMutex;
    int fd = -1;
    uint32_t nextId = 1;
};

}  // namespace vietmap
