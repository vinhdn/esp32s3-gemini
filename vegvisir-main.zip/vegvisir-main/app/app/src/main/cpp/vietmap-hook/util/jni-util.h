#pragma once

#include <jni.h>

#include <string>

// Small JNI helpers shared by both native libraries (libvegvisir + libvietmaphook).
namespace jni {

// Copy a Java string into a std::string (UTF-8). Returns "" for null.
inline std::string toString(JNIEnv* env, jstring value) {
    if (value == nullptr) return {};
    const char* chars = env->GetStringUTFChars(value, nullptr);
    std::string result(chars ? chars : "");
    if (chars) env->ReleaseStringUTFChars(value, chars);
    return result;
}

}  // namespace jni
