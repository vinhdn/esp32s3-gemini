#include "vietmap-client.h"

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cerrno>
#include <cstring>
#include <ctime>

#include "util/log.h"
#include "protocol/envelope.h"

namespace vietmap {
namespace {

// The Vegvisir server runs on this device (see core/main-engine.h kServerPort).
// The hook lives inside vn.vietmap.live, so it connects over loopback — no adb
// forward involved (that only bridges host<->device).
constexpr const char* kServerHost = "127.0.0.1";
constexpr int kServerPort = 15985;
constexpr int kReconnectDelayMs = 2000;

const char* kRegisterBody = "{\"clientType\":\"vietmap\"}";

bool writeAll(int fd, const uint8_t* data, size_t len) {
    size_t off = 0;
    while (off < len) {
        ssize_t n = ::send(fd, data + off, len - off, MSG_NOSIGNAL);
        if (n <= 0) return false;
        off += static_cast<size_t>(n);
    }
    return true;
}

void sleepMs(int ms) {
    struct timespec ts{ms / 1000, static_cast<long>(ms % 1000) * 1000000L};
    nanosleep(&ts, nullptr);
}

}  // namespace

VietmapClient& VietmapClient::instance() {
    static VietmapClient client;
    return client;
}

void VietmapClient::start() {
    if (running.exchange(true)) return;  // already started
    thread = std::thread(&VietmapClient::runLoop, this);
    LOGI("vietmap client: started");
}

void VietmapClient::stop() {
    if (!running.exchange(false)) return;
    {
        std::lock_guard<std::mutex> lock(sockMutex);
        if (fd >= 0) {
            ::shutdown(fd, SHUT_RDWR);
            ::close(fd);
            fd = -1;
        }
    }
    if (thread.joinable()) thread.join();
}

int VietmapClient::connectOnce() {
    int sock = ::socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return -1;

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(static_cast<uint16_t>(kServerPort));
    ::inet_pton(AF_INET, kServerHost, &addr.sin_addr);

    if (::connect(sock, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
        ::close(sock);
        return -1;
    }
    return sock;
}

void VietmapClient::runLoop() {
    while (running.load()) {
        int sock = connectOnce();
        if (sock < 0) {
            if (running.load()) sleepMs(kReconnectDelayMs);
            continue;
        }
        {
            std::lock_guard<std::mutex> lock(sockMutex);
            fd = sock;
        }

        // Declare our role to the server the moment we connect.
        sendFrame(vegvisir::encodeJsonMessage(vegvisir::MessageType::Register,
                                              kRegisterBody, nextId++));
        LOGI("vietmap client: connected to %s:%d, registered", kServerHost, kServerPort);

        // Read only to detect the server closing the connection; the server does
        // not send anything to a vietmap client.
        uint8_t scratch[256];
        while (running.load()) {
            ssize_t n = ::recv(sock, scratch, sizeof(scratch), 0);
            if (n <= 0) break;  // EOF / error
        }

        {
            std::lock_guard<std::mutex> lock(sockMutex);
            if (fd == sock) fd = -1;
        }
        ::close(sock);
        LOGW("vietmap client: disconnected");
        if (running.load()) sleepMs(kReconnectDelayMs);
    }
    LOGI("vietmap client: loop ended");
}

bool VietmapClient::sendFrame(const std::vector<uint8_t>& frame) {
    std::lock_guard<std::mutex> lock(sockMutex);
    if (fd < 0) return false;
    return writeAll(fd, frame.data(), frame.size());
}

void VietmapClient::sendNavigation(const std::string& json) {
    // Encode outside the lock, then hand the frame to sendFrame (which locks).
    std::vector<uint8_t> frame =
        vegvisir::encodeJsonMessage(vegvisir::MessageType::Navigation, json, nextId++);
    if (sendFrame(frame)) {
        LOGI("vietmap client: navigation -> server (%zuB)", json.size());
    } else {
        LOGW("vietmap client: navigation dropped (not connected)");
    }
}

}  // namespace vietmap
