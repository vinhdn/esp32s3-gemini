#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace vegvisir {

// The one message type carried over the connection. Wire values are fixed —
// do not renumber (both ends depend on them). New types append at the end.
enum class MessageType : uint8_t {
    Navigation = 1,  // JSON body: maneuver / route guidance (details TBD)
    Upgrade = 2,     // JSON body: upgrade package info (details TBD)

    FileBegin = 3,   // JSON body: { "name", "size", "mime" }; id = fileId
    FileChunk = 4,   // binary body: one slice of the file; id = fileId
    FileEnd = 5,     // empty/JSON body: end of file; id = fileId

    Request = 6,     // JSON body: client -> server request; id = request id
    Response = 7,    // JSON body: server -> client reply; replyTo = request id
    Error = 9,       // JSON body: { "message" }
    Ping = 10,
    Pong = 11,

    Register = 12,   // JSON body: { "clientType" } — client declares its role on connect
};

// One framed message. body is JSON (UTF-8) when binaryBody is false, else raw bytes.
struct Envelope {
    MessageType type = MessageType::Request;
    uint32_t id = 0;       // message / file id (0 = none)
    uint32_t replyTo = 0;  // correlation id for a Response (0 = none)
    bool binaryBody = false;
    std::vector<uint8_t> body;
};

// Fixed header: magic(4) "VEG1" | version(1) | type(1) | flags(1) |
//               id(4) | replyTo(4) | bodyLen(4)   — all integers big-endian.
// The body of bodyLen bytes follows the header.
constexpr size_t kEnvelopeHeaderSize = 19;
constexpr uint8_t kProtocolVersion = 1;
constexpr uint32_t kMaxBodyLen = 16u * 1024 * 1024;  // guards against bogus lengths

struct EnvelopeHeader {
    MessageType type = MessageType::Request;
    bool binaryBody = false;
    uint32_t id = 0;
    uint32_t replyTo = 0;
    uint32_t bodyLen = 0;
};

// Serialize a full envelope (header + body) into bytes to write on the socket.
std::vector<uint8_t> encodeEnvelope(const Envelope& env);

// Convenience: build a text (JSON) message with no attached binary.
std::vector<uint8_t> encodeJsonMessage(MessageType type, const std::string& json,
                                       uint32_t id = 0, uint32_t replyTo = 0);

// Parse the fixed header from at least kEnvelopeHeaderSize bytes.
// Returns false on bad magic or unsupported version.
bool parseEnvelopeHeader(const uint8_t* data, EnvelopeHeader& out);

}  // namespace vegvisir
