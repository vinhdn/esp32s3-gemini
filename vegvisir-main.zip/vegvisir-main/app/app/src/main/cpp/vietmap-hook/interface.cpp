// interface.cpp — JNI surface of libvietmaphook.so.
//
// Loaded by the LSPosed module INTO vn.vietmap.live's process. It hooks libflutter's BoringSSL
// SSL_read/SSL_write by offset (ssl-tap.*), reassembles the plaintext of the API paths nativeStart
// was given into whole HTTP responses (http-reasm.*), and pushes each response UP to the Kotlin
// side (Hook.NativeHook.onApiResponse) to process.

#include <jni.h>

#include <memory>
#include <string>
#include <vector>

#include "http-reasm.h"
#include "util/jni-util.h"
#include "util/log.h"
#include "ssl-tap.h"
#include "vietmap-client.h"

namespace {

// The Kotlin object that receives matched responses. Its JNI name carries the mangled
// inner-object name ("$" -> "…$NativeHook"). onApiResponse is a @JvmStatic method.
constexpr const char* kNativeHookClass =
    "com/rongcondihoc/vegvisir/service/vietmap/Hook$NativeHook";

// Resolved once in nativeStart (on the JVM main thread), used from ssl-tap's drain thread.
JavaVM* g_vm = nullptr;
jclass g_nativeHookClass = nullptr;   // global ref
jmethodID g_onApiResponse = nullptr;  // static void onApiResponse(String path, String status, byte[] body)

// Reassembles only the watched API paths; owns all connection state and lives for the whole
// process. Built in nativeStart (before the tap is armed), used from the drain thread.
std::unique_ptr<http::Reassembler> g_reasm;

// Attach the calling (ssl-tap drain) thread to the JVM. It lives for the whole process,
// so we attach once and never detach.
JNIEnv* jniEnv() {
    if (g_vm == nullptr) return nullptr;
    JNIEnv* env = nullptr;
    if (g_vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) == JNI_OK) return env;
    if (g_vm->AttachCurrentThread(&env, nullptr) == JNI_OK) return env;
    return nullptr;
}

// The reassembler callback: push one captured response up to Kotlin. Body goes as byte[]
// (raw, already de-chunked + gunzipped) so the Kotlin side decodes it — safe for any encoding.
void pushToKotlin(const http::Response& r) {
    JNIEnv* env = jniEnv();
    if (env == nullptr || g_nativeHookClass == nullptr || g_onApiResponse == nullptr) return;

    jstring jpath = env->NewStringUTF(r.path.c_str());
    jstring jstatus = env->NewStringUTF(r.status.c_str());
    jbyteArray jbody = env->NewByteArray(static_cast<jsize>(r.body.size()));
    if (jbody != nullptr && !r.body.empty()) {
        env->SetByteArrayRegion(jbody, 0, static_cast<jsize>(r.body.size()),
                                reinterpret_cast<const jbyte*>(r.body.data()));
    }

    env->CallStaticVoidMethod(g_nativeHookClass, g_onApiResponse, jpath, jstatus, jbody);
    if (env->ExceptionCheck()) {
        env->ExceptionDescribe();
        env->ExceptionClear();
    }
    env->DeleteLocalRef(jpath);
    env->DeleteLocalRef(jstatus);
    env->DeleteLocalRef(jbody);
}

// DISCOVERY: dump the first plaintext chunks (readable preview), regardless of protocol.
// If you see "tap R/W …" lines under tag "Vegvisir", the SSL hook IS armed and delivering
// decrypted bytes — and the preview shows HTTP/1.1 ("GET …") vs HTTP/2 (binary/"PRI * HTTP/2").
// If you see NOTHING, the tap did not arm (build-id/offset mismatch) or the lib failed to load.
// Set to 0 to disable once diagnosed.
constexpr int kTapPreviewCount = 60;

// SSL plaintext sink (ssl-tap's single drain thread). Forwards both directions to the
// reassembler; writes carry the request line, reads carry the response.
void onPlaintext(uint64_t ssl, bool isRead, const uint8_t* data, size_t len) {
    static int previews = 0;
    if (previews < kTapPreviewCount) {
        ++previews;
        char head[97];
        const size_t n = len < 96 ? len : 96;
        for (size_t i = 0; i < n; i++) {
            const unsigned char ch = data[i];
            head[i] = (ch >= 0x20 && ch < 0x7f) ? static_cast<char>(ch) : '.';
        }
        head[n] = '\0';
        LOGI("tap %s len=%zu: %s", isRead ? "R" : "W", len, head);
    }
    if (g_reasm) g_reasm->onPlaintext(ssl, isRead, data, len);
}

// Resolve Hook$NativeHook.onApiResponse once; cache a global class ref + method id.
void resolveCallback(JNIEnv* env) {
    jclass local = env->FindClass(kNativeHookClass);
    if (local == nullptr) {
        env->ExceptionClear();
        LOGE("vietmap hook: %s not found; API responses will not reach Kotlin", kNativeHookClass);
        return;
    }
    g_nativeHookClass = static_cast<jclass>(env->NewGlobalRef(local));
    g_onApiResponse = env->GetStaticMethodID(g_nativeHookClass, "onApiResponse",
                                             "(Ljava/lang/String;Ljava/lang/String;[B)V");
    env->DeleteLocalRef(local);
    if (g_onApiResponse == nullptr) {
        env->ExceptionClear();
        LOGE("vietmap hook: onApiResponse(String,String,byte[]) not found");
    }
}

// Copy the Java String[] of API paths into a std::vector.
std::vector<std::string> readApiPaths(JNIEnv* env, jobjectArray apiPaths) {
    std::vector<std::string> out;
    if (apiPaths == nullptr) return out;
    const jsize n = env->GetArrayLength(apiPaths);
    for (jsize i = 0; i < n; i++) {
        jstring s = static_cast<jstring>(env->GetObjectArrayElement(apiPaths, i));
        std::string path = jni::toString(env, s);
        if (!path.empty()) out.push_back(std::move(path));
        env->DeleteLocalRef(s);
    }
    LOGI("vietmap hook: %zu API path(s) will be pushed to Kotlin", out.size());
    return out;
}

}  // namespace

// --- Kotlin: Hook.NativeHook.nativeStart(readOff, writeOff, buildId, apiPaths) ---
// The Kotlin method lives in the nested object Hook$NativeHook, so the JNI
// symbol carries the mangled inner-class name ("$" -> "_00024").
extern "C" JNIEXPORT void JNICALL
Java_com_rongcondihoc_vegvisir_service_vietmap_Hook_00024NativeHook_nativeStart(
    JNIEnv* env, jobject /*thiz*/, jlong readOff, jlong writeOff, jstring buildId,
    jobjectArray apiPaths) {
    // Cache the JVM + the Kotlin callback for use from the ssl-tap drain thread, then build
    // the reassembler with the watched paths (both must exist before the tap fires).
    env->GetJavaVM(&g_vm);
    resolveCallback(env);
    g_reasm = std::unique_ptr<http::Reassembler>(
        new http::Reassembler(readApiPaths(env, apiPaths), pushToKotlin));

    // Connect to the on-device Vegvisir server and register as a vietmap client.
    // Once captured navigation is parsed it is forwarded via sendNavigation().
    vietmap::VietmapClient::instance().start();

    ssltap::start(static_cast<uintptr_t>(readOff), static_cast<uintptr_t>(writeOff),
                  jni::toString(env, buildId), onPlaintext);
}

// --- Kotlin: RouteGuide.nativeSendNavigation(json) ---
// RouteGuide (Kotlin) parses the captured Route API JSON, and — driven by GpsService fixes —
// builds one HUD-sink Navigation JSON per position update. It hands that JSON here so the
// already-connected VietmapClient forwards it to the Vegvisir server (which relays it to mazda).
// Statically-named symbol: class RouteGuide has no inner-class mangling.
extern "C" JNIEXPORT void JNICALL
Java_com_rongcondihoc_vegvisir_service_RouteGuide_nativeSendNavigation(
    JNIEnv* env, jobject /*thiz*/, jstring json) {
    vietmap::VietmapClient::instance().sendNavigation(jni::toString(env, json));
}
