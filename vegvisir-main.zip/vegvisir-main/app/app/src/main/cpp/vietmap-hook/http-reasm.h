// http::Reassembler — rebuild HTTP responses from ssl-tap plaintext (layer A).
//
// SSL_read/SSL_write hand us plaintext one CHUNK at a time, keyed by SSL* pointer (one connection).
// An HTTP response is torn into several chunks and may be chunked + gzipped. This class groups by
// SSL*, splits header/body, de-chunks, gunzips, then hands the whole response to a callback.
//
// ### Almost-pure mechanism
// It is given a list of request-path prefixes to watch and only reassembles those responses (a body
// for any other path is never collected). It does not understand their schema — it just returns
// (host, method, path, status, body). Choosing the endpoints and parsing the body is the caller's job.
//
// ### Threading contract
// [onPlaintext] may only be called from ONE thread (ssl-tap's drain thread). That is why there is no
// lock; do not call it from another thread.

#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <string>
#include <unordered_map>
#include <vector>

namespace http {

struct Response {
    std::string host;
    std::string method;
    std::string path;
    std::string status;              // the full status line, e.g. "HTTP/1.1 200 OK"
    std::string contentType;         // the response Content-Type header (may be empty)
    std::vector<uint8_t> body;       // already de-chunked + gunzipped
};

class Reassembler {
public:
    using OnResponse = std::function<void(const Response &)>;

    // paths: request-path prefixes to watch (query stripped before matching). Only responses
    // whose request path starts with one of these are reassembled + emitted. Empty = nothing.
    Reassembler(std::vector<std::string> paths, OnResponse cb) {
        this->paths = std::move(paths);
        this->cb = std::move(cb);
    }

    /**
     * @param ssl     connection identity (the SSL* pointer)
     * @param isRead  true = SSL_read (response), false = SSL_write (request)
     */
    void onPlaintext(uint64_t ssl, bool isRead, const uint8_t *data, size_t len);

private:
    struct Conn {
        std::string host;
        std::string method;
        std::string path;
        bool interesting = false;    // request path matched the allowlist -> collect the body
        std::vector<uint8_t> resp;
        bool headerParsed = false;
        long bodyStart = -1;         // index of the body's first byte within resp
        std::string status;
        std::string contentType;
        bool chunked = false;
        bool gzip = false;
        long contentLength = -1;     // -1 = no Content-Length
    };

    void onRequest(Conn &c, const uint8_t *data, size_t len);
    void onResponse(uint64_t ssl, Conn &c, const uint8_t *data, size_t len);
    /** Is a response complete? If so, emit it and keep the leftover bytes (pipelining). */
    void tryComplete(uint64_t ssl, Conn &c);
    void emit(Conn &c, size_t bodyStart, size_t bodyEnd);
    /** Does this request path (query stripped) start with one of the watched prefixes? */
    bool matchesPath(const std::string &path) const;

    std::vector<std::string> paths;
    OnResponse cb;
    std::unordered_map<uint64_t, Conn> conns;
};

}  // namespace http
