// SslTap — hook BoringSSL SSL_read/SSL_write STATICALLY inside libflutter, by OFFSET.
//
// SSL_read/SSL_write operate on *plaintext* → decrypted HTTPS WITHOUT any CA or patching. This is
// "layer A": Vietmap's ORIGINAL route JSON, far more detailed than what crosses the platform channel
// (layer B, see provider/vietmap/vietmap.cpp).
//
// ### Why there is a build-id check
// The offsets are valid for exactly one libflutter build (Flutter 3.16.0, build-id a346b27d…). Hooking
// the wrong address inside some other function crashes the host app. So if the build-id does not
// match we do NOT hook — losing layer A beats killing Vietmap.
//
// Plaintext goes to a C++ sink DIRECTLY (not through JNI): the data stays in native code, so no thread
// has to be attached to the JVM and no byte[] is allocated on the Java heap.

#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <string>

namespace ssltap {

/**
 * @param ssl     the SSL* pointer (connection identity — needed to stitch chunks of the same HTTP
 *                stream back together)
 * @param isRead  true = SSL_read (response), false = SSL_write (request)
 */
using Sink = std::function<void(uint64_t ssl, bool isRead, const uint8_t *data, size_t len)>;

/**
 * Install the hook (idempotent, non-blocking: it waits for libflutter to load on its own thread).
 *
 * @param readOff/writeOff  offsets of SSL_read/SSL_write inside libflutter.so
 * @param expectBuildId     the expected build-id; empty = skip the check (NOT recommended)
 */
void start(uintptr_t readOff, uintptr_t writeOff, const std::string &expectBuildId, Sink sink);

}  // namespace ssltap
