pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Xposed API 82 (rovo89) — for compileOnly de.robv.android.xposed:api
        maven("https://api.xposed.info/")
    }
}
rootProject.name = "Vegvisir"
include(":app")
