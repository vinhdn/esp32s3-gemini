// SPDX-License-Identifier: AGPL-3.0-or-later
// Author: rongcondihoc
//
// Navigation -> HUD bridge for Mazda Connect (CMU150).
//
// Finding the phone without being told its address.
//
// The phone runs the server; this unit is the client. On a USB link the phone's
// address cannot be written down in advance (it is the DHCP server and the CMU
// is the lease), but the *client* can discover the *server* from its own routing
// table. IPv6 makes it configuration-free: every interface gets a link-local
// fe80::/64 by autoconfiguration.
//
// Two ways to get there, in order of preference:
//  1. NEXT HOP from /proc/net/ipv6_route — when the phone advertises itself as a
//     router (Android does when it tethers), the kernel records its link-local
//     address as the gateway of a route out of usb0. Exact, one read, no traffic.
//  2. ALL-NODES MULTICAST ff02::1 (scoped to usb0) when no route carries a
//     gateway. A STREAM socket cannot dial a multicast address, so the socket
//     client treats this as "discovery failed, here is the actionable reason".
//
// This file reads a proc file and returns an address. It does not connect,
// resolve names, or send anything.

#ifndef VEGVISIR_CLIENT_NET_PEER_DISCOVERY_H
#define VEGVISIR_CLIENT_NET_PEER_DISCOVERY_H

#include <net/if.h>
#include <netinet/in.h>

// How the address was arrived at — carried so the log can say which mechanism
// produced it.
#define NET_PEER_VIA_NEXTHOP  1
#define NET_PEER_VIA_ALLNODES 2

struct NetPeer {
    struct in6_addr addr;
    unsigned int    scope_id;          // interface index; required for fe80::/ff02::
    int             via;               // NET_PEER_VIA_*
    char            ifname[IF_NAMESIZE];
};

// Look for the phone on `ifname` (e.g. "usb0"). Returns true and fills *out on
// success; false when the interface has no IPv6 presence at all. `reason` gets a
// short human-readable explanation (>= 160 bytes). Never throws, sends nothing.
bool net_discover_peer(const char *ifname, NetPeer *out,
                       char *reason, unsigned reason_len);

// "fe80::1%usb0" — for logs. Always NUL-terminates.
void net_peer_str(const NetPeer *p, char *buf, unsigned len);

#endif // VEGVISIR_CLIENT_NET_PEER_DISCOVERY_H
