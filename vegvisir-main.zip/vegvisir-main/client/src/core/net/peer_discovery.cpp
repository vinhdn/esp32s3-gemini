// SPDX-License-Identifier: AGPL-3.0-or-later
// Author: rongcondihoc
//
// Navigation -> HUD bridge for Mazda Connect (CMU150).
//
// Peer discovery over IPv6. See peer_discovery.h for why the client discovers
// the server and not the other way round.

#include "core/net/peer_discovery.h"

#include <arpa/inet.h>
#include <cstring>
// <stdio.h>, not <cstdio>: the device's GCC-era libstdc++ leaves the C99
// snprintf out of namespace std.
#include <stdio.h>

namespace {

// /proc/net/ipv6_route, one route per line; every address is 32 raw hex digits
// with no separators. Column 4 (the next hop) holds the link-local address of
// the gateway on that interface — on a USB tether, the phone.
const int      kFields     = 10;
const unsigned kRtfGateway = 0x0002u;   // RTF_GATEWAY (corroboration for the log)

bool hex_nibble(char c, unsigned *out)
{
    if (c >= '0' && c <= '9') { *out = (unsigned)(c - '0');      return true; }
    if (c >= 'a' && c <= 'f') { *out = (unsigned)(c - 'a' + 10); return true; }
    if (c >= 'A' && c <= 'F') { *out = (unsigned)(c - 'A' + 10); return true; }
    return false;
}

// 32 hex digits -> 16 bytes, in the order printed (network order).
bool parse_hex128(const char *s, struct in6_addr *out)
{
    if (std::strlen(s) != 32) return false;
    for (int i = 0; i < 16; i++) {
        unsigned hi, lo;
        if (!hex_nibble(s[i * 2], &hi) || !hex_nibble(s[i * 2 + 1], &lo)) return false;
        out->s6_addr[i] = (unsigned char)((hi << 4) | lo);
    }
    return true;
}

bool is_zero_addr(const struct in6_addr *a)
{
    for (int i = 0; i < 16; i++)
        if (a->s6_addr[i] != 0) return false;
    return true;
}

// Loopback (::1) would be this unit talking to itself; a multicast next hop is
// not a thing. Either means we misread the table, so refuse rather than spend a
// connect timeout on it.
bool plausible_peer(const struct in6_addr *a)
{
    if (is_zero_addr(a))       return false;
    if (a->s6_addr[0] == 0xff) return false;   // multicast
    static const unsigned char lo[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1};
    if (std::memcmp(a->s6_addr, lo, 16) == 0) return false;
    return true;
}

} // namespace

bool net_discover_peer(const char *ifname, NetPeer *out,
                       char *reason, unsigned reason_len)
{
    if (!ifname || !out || !reason || reason_len == 0) return false;
    reason[0] = '\0';

    const unsigned int idx = if_nametoindex(ifname);
    if (idx == 0) {
        snprintf(reason, reason_len,
                 "interface \"%s\" does not exist (cable out, or the USB gadget "
                 "has not come up yet)", ifname);
        return false;
    }

    FILE *fp = fopen("/proc/net/ipv6_route", "r");
    if (!fp) {
        snprintf(reason, reason_len,
                 "/proc/net/ipv6_route is missing — this kernel has NO IPv6 "
                 "support, so IPv6 discovery cannot work on this unit");
        return false;
    }

    struct in6_addr best;
    std::memset(&best, 0, sizeof(best));
    bool     have_best      = false;
    bool     best_is_default = false;
    unsigned best_flags     = 0;
    bool     saw_interface  = false;

    char line[512];
    while (fgets(line, sizeof(line), fp)) {
        char     dst[64], src[64], nh[64], dev[64];
        unsigned dst_len = 0, src_len = 0, metric = 0, ref = 0, use = 0, flags = 0;
        const int n = sscanf(line, "%63s %x %63s %x %63s %x %x %x %x %63s",
                             dst, &dst_len, src, &src_len, nh,
                             &metric, &ref, &use, &flags, dev);
        if (n != kFields) continue;
        if (std::strcmp(dev, ifname) != 0) continue;
        saw_interface = true;

        struct in6_addr gw;
        if (!parse_hex128(nh, &gw)) continue;
        if (!plausible_peer(&gw))   continue;

        // A default route (prefix length 0) via this interface is the strongest
        // signal: the kernel is saying "everything unknown goes to this box", and
        // on a tether that box is the phone.
        const bool is_default = (dst_len == 0);
        if (!have_best || (is_default && !best_is_default)) {
            best            = gw;
            have_best       = true;
            best_is_default = is_default;
            best_flags      = flags;
            if (is_default) break;
        }
    }
    fclose(fp);

    std::memset(out, 0, sizeof(*out));
    std::strncpy(out->ifname, ifname, sizeof(out->ifname) - 1);
    out->scope_id = idx;

    if (have_best) {
        out->addr = best;
        out->via  = NET_PEER_VIA_NEXTHOP;
        snprintf(reason, reason_len,
                 "next hop of a%s route on %s (flags=0x%x%s)",
                 best_is_default ? " default" : "", ifname, best_flags,
                 (best_flags & kRtfGateway) ? ", RTF_GATEWAY" : "");
        return true;
    }

    if (!saw_interface) {
        snprintf(reason, reason_len,
                 "%s exists but has no IPv6 route yet — link still coming up, or "
                 "IPv6 is disabled on this interface", ifname);
        return false;
    }

    // On the link but nothing there is a gateway: fall back to all-nodes
    // multicast (the socket client will report this as unreachable-by-stream).
    if (inet_pton(AF_INET6, "ff02::1", &out->addr) != 1) {
        snprintf(reason, reason_len, "inet_pton(ff02::1) failed — cannot happen");
        return false;
    }
    out->via = NET_PEER_VIA_ALLNODES;
    snprintf(reason, reason_len,
             "no gateway on %s — falling back to all-nodes multicast", ifname);
    return true;
}

void net_peer_str(const NetPeer *p, char *buf, unsigned len)
{
    if (!buf || len == 0) return;
    buf[0] = '\0';
    if (!p) return;
    char ip[INET6_ADDRSTRLEN] = "?";
    inet_ntop(AF_INET6, &p->addr, ip, sizeof(ip));
    snprintf(buf, len, "%s%%%s", ip, p->ifname);
}
