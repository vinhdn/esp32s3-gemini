// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Navigation -> HUD bridge for Mazda Connect (CMU150).
//
// Flat-JSON reader implementation. See json_lite.h for scope and guarantees.

#include "core/net/json_lite.h"

#include <cstring>

namespace json {
namespace {

bool is_ws(char c) { return c == ' ' || c == '\t' || c == '\n' || c == '\r'; }

// Find the byte offset just past the ':' of a top-level "key": pair, or npos.
// Matches a quoted key followed (after optional whitespace) by a colon, so a
// bare substring inside some value cannot be mistaken for the key.
size_t find_value(const std::string &body, const char *key)
{
    std::string needle = "\"";
    needle += key;
    needle += "\"";
    size_t from = 0;
    for (;;) {
        size_t k = body.find(needle, from);
        if (k == std::string::npos) return std::string::npos;
        size_t i = k + needle.size();
        while (i < body.size() && is_ws(body[i])) i++;
        if (i < body.size() && body[i] == ':') {
            i++;
            while (i < body.size() && is_ws(body[i])) i++;
            return i;
        }
        from = k + needle.size();
    }
}

// Read a leading integer (or the integer part of a decimal) out of `text`.
bool parse_long(const std::string &text, long *out)
{
    size_t i = 0;
    while (i < text.size() && is_ws(text[i])) i++;
    bool neg = false;
    if (i < text.size() && (text[i] == '-' || text[i] == '+')) {
        neg = text[i] == '-';
        i++;
    }
    if (i >= text.size() || text[i] < '0' || text[i] > '9') return false;
    long v = 0;
    while (i < text.size() && text[i] >= '0' && text[i] <= '9') {
        v = v * 10 + (text[i] - '0');
        i++;
    }
    *out = neg ? -v : v;
    return true;
}

// Append body[from,to) to `out` with the whitespace trimmed off both ends,
// skipping an empty span (so "[]" and a trailing comma both yield no element).
void push_elem(const std::string &body, size_t from, size_t to,
               std::vector<std::string> *out, size_t maxElems)
{
    while (from < to && is_ws(body[from]))   from++;
    while (to > from && is_ws(body[to - 1])) to--;
    if (from >= to || out->size() >= maxElems) return;
    out->push_back(body.substr(from, to - from));
}

} // namespace

bool getString(const std::string &body, const char *key, char *out, size_t outsz)
{
    if (!out || outsz == 0) return false;
    out[0] = '\0';
    size_t i = find_value(body, key);
    if (i == std::string::npos || i >= body.size() || body[i] != '"') return false;
    i++;   // past opening quote

    size_t o = 0;
    const size_t max = outsz - 1;
    while (i < body.size() && body[i] != '"' && o < max) {
        char c = body[i];
        if (c == '\\' && i + 1 < body.size()) {
            char e = body[i + 1];
            switch (e) {
            case '"':  c = '"';  i += 2; break;
            case '\\': c = '\\'; i += 2; break;
            case '/':  c = '/';  i += 2; break;
            case 'n':  c = '\n'; i += 2; break;
            case 'r':  c = '\r'; i += 2; break;
            case 't':  c = '\t'; i += 2; break;
            case 'b':  c = '\b'; i += 2; break;
            case 'f':  c = '\f'; i += 2; break;
            // \uXXXX and any other escape are passed through as the escaped char
            // (the server sends road names as raw UTF-8, not \u sequences).
            default:   c = e;    i += 2; break;
            }
        } else {
            i++;
        }
        out[o++] = c;
    }
    out[o] = '\0';
    return true;
}

bool getInt(const std::string &body, const char *key, long *out)
{
    if (!out) return false;
    size_t i = find_value(body, key);
    if (i == std::string::npos || i >= body.size()) return false;

    bool neg = false;
    if (body[i] == '-') { neg = true; i++; }
    if (i >= body.size() || body[i] < '0' || body[i] > '9') return false;

    long v = 0;
    while (i < body.size() && body[i] >= '0' && body[i] <= '9') {
        v = v * 10 + (body[i] - '0');
        i++;
    }
    *out = neg ? -v : v;
    return true;
}

bool getBool(const std::string &body, const char *key, bool *out)
{
    if (!out) return false;
    size_t i = find_value(body, key);
    if (i == std::string::npos || i >= body.size()) return false;
    if (body.compare(i, 4, "true") == 0)  { *out = true;  return true; }
    if (body.compare(i, 5, "false") == 0) { *out = false; return true; }
    return false;
}

bool getArray(const std::string &body, const char *key,
              std::vector<std::string> *out, size_t maxElems)
{
    if (!out) return false;
    out->clear();

    size_t i = find_value(body, key);
    if (i == std::string::npos || i >= body.size() || body[i] != '[') return false;
    i++;   // past the opening bracket

    // Split on the commas that sit at OUR level: a comma inside a nested object /
    // array, or inside a string, belongs to the element, not to us. `depth` tracks
    // the nesting the element opened; the ']' that closes it at depth 0 ends the
    // array.
    int    depth = 0;
    bool   instr = false;
    size_t start = i;
    for (; i < body.size(); ++i) {
        const char c = body[i];
        if (instr) {
            if (c == '\\')     i++;          // the escaped byte is never a delimiter
            else if (c == '"') instr = false;
            continue;
        }
        switch (c) {
        case '"': instr = true; break;
        case '[': case '{': depth++; break;
        case '}': if (depth > 0) depth--; break;
        case ']':
            if (depth > 0) { depth--; break; }
            push_elem(body, start, i, out, maxElems);
            return true;
        case ',':
            if (depth == 0) {
                push_elem(body, start, i, out, maxElems);
                start = i + 1;
            }
            break;
        default: break;
        }
    }
    out->clear();
    return false;   // ran off the end: the array was never closed
}

bool getIntArray(const std::string &body, const char *key,
                 long *out, size_t maxCount, size_t *count)
{
    if (!out || !count) return false;
    *count = 0;

    std::vector<std::string> elems;
    if (!getArray(body, key, &elems, maxCount)) return false;
    for (size_t k = 0; k < elems.size() && *count < maxCount; ++k) {
        long v = 0;
        if (parse_long(elems[k], &v)) out[(*count)++] = v;
    }
    return true;
}

} // namespace json
