// SPDX-License-Identifier: AGPL-3.0-or-later
// Author: rongcondihoc
//
// Navigation -> HUD bridge for Mazda Connect (CMU150).
//
// TCP/IPv6 client implementation. See socket_client.h for the rationale.
//
// Cloned from vegvisir-client v1.3 (discovery + dial + liveness + reframing,
// unchanged). One addition for v2: the link callback hudnav uses to wipe the
// HUD when the socket drops (clientSetLinkCallback).

#define LOG_TAG "NET"
#include "core/log.h"

#include "core/net/socket_client.h"
#include "core/net/message_router.h"
#include "core/net/peer_discovery.h"

#include <arpa/inet.h>
#include <atomic>
#include <cerrno>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fcntl.h>
#include <mutex>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <pthread.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
// <stdio.h>, not <cstdio>: the device's GCC-era libstdc++ leaves snprintf out
// of namespace std.
#include <stdio.h>

// Old kernels/headers do not export these; the values are Linux ABI constants.
#ifndef TCP_KEEPIDLE
#define TCP_KEEPIDLE 4
#endif
#ifndef TCP_KEEPINTVL
#define TCP_KEEPINTVL 5
#endif
#ifndef TCP_KEEPCNT
#define TCP_KEEPCNT 6
#endif
#ifndef TCP_USER_TIMEOUT
#define TCP_USER_TIMEOUT 18
#endif

namespace net {
namespace {

const uint16_t kDefaultPort     = 15985;   // the vegvisir server port
const long     kReconnectSec    = 3;
const long     kConnectTimeout  = 5;

// LIVENESS — why an idle socket is not proof of a live server.
//
// The server dying is only the easy case: the kernel that owned it sends a FIN
// and recv() returns 0. The case that used to hang the client forever is the
// server dying *with the link*: the phone re-tethers, usb0 is torn down and
// comes back with a new address, and no FIN is ever delivered. Nothing is
// written on the socket after Register, so the receive loop just kept ticking
// its 1 s idle timeout against a socket that would never speak again — g_sock
// stayed >= 0, so try_connect() (and therefore re-discovery) was never reached.
//
// Three detectors, cheapest first:
//   1. re-run discovery every kPeerRecheckSec — an address change is visible in
//      the routing table immediately, before any timeout has to expire,
//   2. an application Ping after kIdlePingSec of silence — puts a packet on the
//      wire so the write path has something to fail on,
//   3. TCP keepalive + TCP_USER_TIMEOUT (below) — the kernel backstop.
const long kPeerRecheckSec = 5;
const long kIdlePingSec    = 10;
const long kIdleDeadSec    = 40;   // only armed once the server has answered a Ping

// Per-socket keepalive. The kernel default (2 h idle, 9 probes 75 s apart) is
// not a reconnect policy for a car; this gives up after ~25 s.
const int kKeepIdleSec   = 10;
const int kKeepIntvlSec  = 5;
const int kKeepCnt       = 3;
const int kUserTimeoutMs = 20000;   // drop a write that stays unacked this long

int               g_sock = -1;
std::mutex        g_send_mu;              // guards writes + g_sock teardown
uint16_t          g_port = 0;
char              g_iface[IF_NAMESIZE] = "usb0";
pthread_t         g_thread = 0;
bool              g_thread_up = false;
std::atomic<bool> g_stop(false);

NetPeer           g_peer;                 // the address the live socket was dialled on
std::atomic<bool> g_pong_seen(false);     // this server answers Ping -> the idle deadline is real

LinkCallback      g_link_cb = nullptr;    // hudnav: HUD clear on link down (v2 addition)

// Discovery log throttle: log only when the answer changes (a car with no phone
// would otherwise fill /tmp).
char g_last_reason[192] = {0};

void log_discovery(const char *reason, bool ok)
{
    if (std::strcmp(reason, g_last_reason) == 0) return;
    std::strncpy(g_last_reason, reason, sizeof(g_last_reason) - 1);
    g_last_reason[sizeof(g_last_reason) - 1] = '\0';
    if (ok) LOGD("client: peer found — %s", reason);
    else    LOGD("client: no peer yet — %s", reason);
}

char g_last_cerr[192] = {0};
long g_cerr_next_repeat = 0;

void log_connect_error(const char *peer, unsigned port, const char *err)
{
    char line[192];
    snprintf(line, sizeof(line), "connect to [%s]:%u failed: %s", peer, port, err);
    const long now     = (long)std::time(nullptr);
    const bool changed = std::strcmp(line, g_last_cerr) != 0;
    if (!changed && now < g_cerr_next_repeat) return;
    std::strncpy(g_last_cerr, line, sizeof(g_last_cerr) - 1);
    g_last_cerr[sizeof(g_last_cerr) - 1] = '\0';
    g_cerr_next_repeat = now + 60;
    LOGE("client: %s%s", line, changed ? "" : " (still retrying)");
}

// Sleep that notices a stop request.
void nap(long secs)
{
    for (long i = 0; i < secs * 5 && !g_stop.load(std::memory_order_relaxed); i++)
        usleep(200 * 1000);
}

// --- config -----------------------------------------------------------------

uint16_t configured_port()
{
    const char *e = std::getenv("VEGVISIR_PORT");
    if (!e || !*e) return kDefaultPort;
    long v = std::strtol(e, nullptr, 10);
    if (v < 0 || v > 65535) {
        LOGW("client: VEGVISIR_PORT=\"%s\" out of range — using %u", e, (unsigned)kDefaultPort);
        return kDefaultPort;
    }
    return (uint16_t)v;   // 0 disables the client
}

void configure_iface()
{
    const char *e = std::getenv("VEGVISIR_IFACE");
    if (!e || !*e) return;
    std::strncpy(g_iface, e, sizeof(g_iface) - 1);
    g_iface[sizeof(g_iface) - 1] = '\0';
}

bool peer_from_env(NetPeer *out)
{
    const char *e = std::getenv("VEGVISIR_PEER");
    if (!e || !*e) return false;
    std::memset(out, 0, sizeof(*out));
    if (inet_pton(AF_INET6, e, &out->addr) != 1) {
        LOGW("client: VEGVISIR_PEER=\"%s\" is not an IPv6 literal — ignoring", e);
        return false;
    }
    out->scope_id = if_nametoindex(g_iface);
    out->via      = NET_PEER_VIA_NEXTHOP;
    std::strncpy(out->ifname, g_iface, sizeof(out->ifname) - 1);
    return true;
}

// --- low-level send ---------------------------------------------------------

// Write all bytes to the socket under the send lock. Caller must NOT hold it.
bool send_all_locked(const uint8_t *data, size_t len)
{
    size_t off = 0;
    while (off < len) {
        ssize_t w = ::send(g_sock, data + off, len - off, MSG_NOSIGNAL);
        if (w < 0) {
            if (errno == EINTR) continue;
            LOGE("client: send failed: %s", std::strerror(errno));
            return false;
        }
        off += (size_t)w;
    }
    return true;
}

// --- connect ----------------------------------------------------------------

// Non-blocking connect with a bounded wait.
bool connect_timeout(int fd, const sockaddr *sa, socklen_t len, long secs)
{
    const int flags = fcntl(fd, F_GETFL, 0);
    if (flags >= 0) fcntl(fd, F_SETFL, flags | O_NONBLOCK);

    int rc = ::connect(fd, sa, len);
    if (rc == 0) {
        if (flags >= 0) fcntl(fd, F_SETFL, flags);
        return true;
    }
    if (errno != EINPROGRESS) return false;

    for (long i = 0; i < secs; i++) {
        if (g_stop.load(std::memory_order_relaxed)) return false;
        fd_set wf;
        FD_ZERO(&wf);
        FD_SET(fd, &wf);
        timeval tv;
        std::memset(&tv, 0, sizeof(tv));
        tv.tv_sec = 1;
        rc = select(fd + 1, nullptr, &wf, nullptr, &tv);
        if (rc < 0) { if (errno == EINTR) continue; return false; }
        if (rc == 0) continue;

        int       err = 0;
        socklen_t el  = sizeof(err);
        if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &el) != 0) return false;
        if (err != 0) { errno = err; return false; }
        if (flags >= 0) fcntl(fd, F_SETFL, flags);
        return true;
    }
    errno = ETIMEDOUT;
    return false;
}

void send_register()
{
    // Announce our role so the server routes navigation + upgrades to us.
    const std::string body = "{\"clientType\":\"mazda\"}";
    std::vector<uint8_t> bytes = encodeJsonMessage(MessageType::Register, body);
    std::lock_guard<std::mutex> lk(g_send_mu);
    if (g_sock >= 0 && send_all_locked(bytes.data(), bytes.size()))
        LOGD("client: sent Register{clientType:mazda}");
}

// Where is the server right now? Pinned address wins, else the routing table.
// `announce` is off for the periodic re-check on a live link, which must not
// narrate discovery to the log every few seconds.
bool resolve_peer(NetPeer *out, bool announce)
{
    char reason[192];

    if (peer_from_env(out)) {
        if (announce) log_discovery("address pinned by VEGVISIR_PEER", true);
        return true;
    }
    if (!net_discover_peer(g_iface, out, reason, sizeof(reason))) {
        if (announce) log_discovery(reason, false);
        return false;
    }
    if (out->via == NET_PEER_VIA_ALLNODES) {
        // A stream socket cannot dial the multicast fallback: TCP is
        // point-to-point. Spell out the two one-line fixes for the operator.
        if (announce)
            log_discovery("no IPv6 gateway on the link — the phone is not advertising "
                          "itself as a router, so TCP has no address to dial. Enable "
                          "IPv6 tethering on the phone, or pin VEGVISIR_PEER=<fe80::...> "
                          "in sm.conf", false);
        return false;
    }
    if (announce) log_discovery(reason, true);
    return true;
}

// Same box on the same link? The interface index counts: usb0 torn down and
// re-created is a different link even when the address happens to repeat.
bool same_peer(const NetPeer &a, const NetPeer &b)
{
    return a.scope_id == b.scope_id &&
           std::memcmp(&a.addr, &b.addr, sizeof(a.addr)) == 0;
}

// One discovery + connect attempt. Leaves g_sock >= 0 and Register sent on OK.
bool try_connect()
{
    NetPeer peer;
    if (!resolve_peer(&peer, true)) return false;

    char peerstr[96];
    net_peer_str(&peer, peerstr, sizeof(peerstr));

    const int fd = socket(AF_INET6, SOCK_STREAM, 0);
    if (fd < 0) {
        LOGC("client: socket(AF_INET6) failed: %s", std::strerror(errno));
        return false;
    }

    // 1 s read timeout gives the receive loop its heartbeat for the stop flag.
    timeval tv;
    std::memset(&tv, 0, sizeof(tv));
    tv.tv_sec = 1;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    int one = 1;
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
    setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &one, sizeof(one));

    // Keepalive with the kernel defaults would notice a vanished phone after two
    // hours. Probe an idle link after 10 s and give up ~25 s in, so recv() fails
    // and the loop below redials.
    int v = kKeepIdleSec;
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPIDLE, &v, sizeof(v));
    v = kKeepIntvlSec;
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPINTVL, &v, sizeof(v));
    v = kKeepCnt;
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPCNT, &v, sizeof(v));
    // And fail an unacked write (the idle Ping) after 20 s rather than
    // retransmitting into a dead link for ~15 min.
    v = kUserTimeoutMs;
    setsockopt(fd, IPPROTO_TCP, TCP_USER_TIMEOUT, &v, sizeof(v));

    sockaddr_in6 sa;
    std::memset(&sa, 0, sizeof(sa));
    sa.sin6_family   = AF_INET6;
    sa.sin6_port     = htons(g_port);
    sa.sin6_addr     = peer.addr;
    sa.sin6_scope_id = peer.scope_id;   // required for fe80:: link-local

    if (!connect_timeout(fd, reinterpret_cast<sockaddr *>(&sa), sizeof(sa), kConnectTimeout)) {
        log_connect_error(peerstr, (unsigned)g_port, std::strerror(errno));
        close(fd);
        return false;
    }
    g_last_cerr[0]     = '\0';
    g_cerr_next_repeat = 0;

    {
        std::lock_guard<std::mutex> lk(g_send_mu);
        g_sock = fd;
        g_peer = peer;
    }
    g_pong_seen.store(false, std::memory_order_relaxed);
    LOGD("client: connected to [%s]:%u (%s) — VEG1", peerstr, (unsigned)g_port,
         peer.via == NET_PEER_VIA_NEXTHOP ? "via route next-hop" : "pinned");
    send_register();
    return true;
}

void close_sock()
{
    std::lock_guard<std::mutex> lk(g_send_mu);
    if (g_sock >= 0) { close(g_sock); g_sock = -1; }
}

// --- receive + reframe ------------------------------------------------------

// Handle Ping at the transport level (reply Pong); route everything else.
void deliver(const Envelope &env)
{
    if (env.type == MessageType::Pong) {
        // The answer to our idle probe. Also the proof that this server speaks
        // Ping at all, which is what arms the idle deadline in idle_tick().
        g_pong_seen.store(true, std::memory_order_relaxed);
        return;
    }
    if (env.type == MessageType::Ping) {
        Envelope pong;
        pong.type    = MessageType::Pong;
        pong.replyTo = env.id;
        std::vector<uint8_t> bytes = encodeEnvelope(pong);
        std::lock_guard<std::mutex> lk(g_send_mu);
        if (g_sock >= 0) send_all_locked(bytes.data(), bytes.size());
        return;
    }
    routerDispatch(env);
}

// When each timed thing is next due on a live link.
struct LinkClock {
    long last_rx;        // last byte from the server
    long next_ping;      // next idle probe
    long next_recheck;   // next discovery re-check
};

// Runs on every idle second of the receive loop. Returns a reason to drop the
// link, or nullptr to keep waiting. This is the whole answer to "the server came
// back somewhere else and we never noticed".
const char *idle_tick(LinkClock *c)
{
    const long now = (long)std::time(nullptr);

    // 1. Has the phone moved? A re-tether hands out a new address (and a new
    //    interface index), and the routing table says so at once — no waiting
    //    for a timeout on a socket pointed at an address nobody answers.
    //
    //    Only worth asking on a quiet link: bytes arriving IS the peer answering,
    //    so during guidance (navigation lands at ~1 Hz) the routing table is
    //    never read at all and this costs exactly nothing.
    if (now - c->last_rx >= kPeerRecheckSec && now >= c->next_recheck) {
        c->next_recheck = now + kPeerRecheckSec;
        NetPeer fresh;
        if (resolve_peer(&fresh, false)) {
            NetPeer current;
            {
                std::lock_guard<std::mutex> lk(g_send_mu);
                current = g_peer;
            }
            if (!same_peer(fresh, current)) {
                char a[96], b[96];
                net_peer_str(&current, a, sizeof(a));
                net_peer_str(&fresh,   b, sizeof(b));
                LOGD("client: peer moved %s -> %s — redialling", a, b);
                return "peer address changed";
            }
        }
    }

    // 2. Silence: probe, so the write path has something to fail on. On a link
    //    that is physically gone this write goes unacked and TCP_USER_TIMEOUT
    //    kills the socket, which surfaces as a recv error below.
    if (now >= c->next_ping) {
        c->next_ping = now + kIdlePingSec;
        Envelope ping;
        ping.type = MessageType::Ping;
        std::vector<uint8_t> bytes = encodeEnvelope(ping);
        std::lock_guard<std::mutex> lk(g_send_mu);
        if (g_sock < 0)                                    return "socket closed";
        if (!send_all_locked(bytes.data(), bytes.size()))   return "ping write failed";
    }

    // 3. This server has answered a Ping before, so silence this long is proof
    //    the link is gone even if the kernel has not given up on it yet. Not
    //    armed against a server that ignores Ping — that link would be dropped
    //    while perfectly healthy.
    if (g_pong_seen.load(std::memory_order_relaxed) && now - c->last_rx >= kIdleDeadSec)
        return "no traffic from the server";

    return nullptr;
}

// Read the connected socket until it dies. Re-frames the byte stream into
// envelopes using each header's bodyLen. Returns a short reason.
const char *rx_stream()
{
    std::vector<uint8_t> buf;
    buf.reserve(4096);
    uint8_t tmp[4096];

    const long now = (long)std::time(nullptr);
    LinkClock  clk;
    clk.last_rx      = now;
    clk.next_ping    = now + kIdlePingSec;
    clk.next_recheck = now + kPeerRecheckSec;

    while (!g_stop.load(std::memory_order_relaxed)) {
        const ssize_t n = recv(g_sock, tmp, sizeof(tmp), 0);
        if (n < 0) {
            if (errno == EINTR) continue;
            if (errno == EAGAIN || errno == EWOULDBLOCK) {   // 1 s idle tick
                if (g_stop.load(std::memory_order_relaxed)) return "stopping";
                const char *why = idle_tick(&clk);
                if (why) return why;
                continue;
            }
            if (g_stop.load(std::memory_order_relaxed)) return "stopping";
            LOGE("client: recv failed: %s", std::strerror(errno));
            return "recv error";
        }
        if (n == 0) return "peer closed the connection";

        clk.last_rx   = (long)std::time(nullptr);
        clk.next_ping = clk.last_rx + kIdlePingSec;
        buf.insert(buf.end(), tmp, tmp + n);

        // Drain every whole envelope currently buffered.
        for (;;) {
            if (buf.size() < kEnvelopeHeaderSize) break;
            EnvelopeHeader hdr;
            if (!parseEnvelopeHeader(buf.data(), hdr)) {
                // A trusted point-to-point link should never desync; if the magic
                // is wrong the stream is unusable, so drop the connection.
                return "bad framing (magic/version)";
            }
            if (hdr.bodyLen > kMaxBodyLen) return "body length over cap";
            const size_t total = kEnvelopeHeaderSize + hdr.bodyLen;
            if (buf.size() < total) break;   // whole body not here yet

            Envelope env;
            env.type       = hdr.type;
            env.id         = hdr.id;
            env.replyTo    = hdr.replyTo;
            env.binaryBody = hdr.binaryBody;
            env.body.assign(buf.begin() + kEnvelopeHeaderSize, buf.begin() + total);
            deliver(env);

            buf.erase(buf.begin(), buf.begin() + total);
        }
    }
    return "stopping";
}

void *rx_main(void *)
{
    while (!g_stop.load(std::memory_order_relaxed)) {
      try {  // nothing may escape this thread (std::terminate -> SIGABRT -> host gone)
        if (g_sock < 0) {
            if (!try_connect()) { nap(kReconnectSec); continue; }
            if (g_link_cb) g_link_cb(true, "connected");
        }
        const char *why = rx_stream();
        close_sock();
        LOGD("client: link down (%s)", why);
        if (g_link_cb) g_link_cb(false, why);
        if (!g_stop.load(std::memory_order_relaxed)) nap(kReconnectSec);
      } catch (...) {
        LOGE("client: exception swallowed — continuing (no thread escape)");
        close_sock();
        usleep(200 * 1000);
      }
    }
    close_sock();
    LOGD("client: receiver thread exiting");
    return nullptr;
}

} // namespace

void clientStart()
{
    if (g_thread_up) { LOGD("client: already running"); return; }

    const uint16_t port = configured_port();
    if (port == 0) {
        LOGD("client: VEGVISIR_PORT=0 — TCP client disabled by configuration");
        return;
    }
    configure_iface();

    g_stop.store(false, std::memory_order_release);
    g_port = port;

    if (pthread_create(&g_thread, nullptr, rx_main, nullptr) != 0) {
        LOGC("client: failed to spawn receiver thread");
        return;
    }
    g_thread_up = true;
    LOGD("client: dialling out on %s port %u — peer address is discovered, not configured",
         g_iface, (unsigned)port);
}

void clientStop()
{
    if (!g_thread_up) return;
    g_stop.store(true, std::memory_order_release);
    pthread_join(g_thread, nullptr);
    g_thread_up = false;
    g_thread    = 0;
    close_sock();
    LOGD("client: stopped");
}

bool clientSend(const Envelope &env)
{
    std::vector<uint8_t> bytes = encodeEnvelope(env);
    std::lock_guard<std::mutex> lk(g_send_mu);
    if (g_sock < 0) return false;
    return send_all_locked(bytes.data(), bytes.size());
}

void clientSetLinkCallback(LinkCallback cb)
{
    g_link_cb = cb;
}

} // namespace net
