// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Navigation -> HUD bridge for Mazda Connect (CMU150).
//
// Message router implementation. See message_router.h.

#define LOG_TAG "NET"
#include "core/log.h"

#include "core/net/message_router.h"

#include <map>

namespace net {
namespace {

std::map<MessageType, MessageHandler> &table()
{
    static std::map<MessageType, MessageHandler> handlers;
    return handlers;
}

} // namespace

void routerRegister(MessageType type, MessageHandler handler)
{
    table()[type] = handler;
    LOGD("router: handler registered for %s", messageTypeName(type));
}

void routerDispatch(const Envelope &env)
{
    std::map<MessageType, MessageHandler>::iterator it = table().find(env.type);
    if (it == table().end() || !it->second) {
        LOGD("router: no handler for %s (id=%u, %u body bytes) — dropped",
             messageTypeName(env.type), env.id, (unsigned)env.body.size());
        return;
    }
    try {
        it->second(env);
    } catch (...) {
        // A handler must never let an exception reach the socket thread (it would
        // std::terminate -> SIGABRT -> host process gone).
        LOGE("router: handler for %s threw — swallowed", messageTypeName(env.type));
    }
}

} // namespace net
