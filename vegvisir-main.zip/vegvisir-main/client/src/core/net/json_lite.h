// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Navigation -> HUD bridge for Mazda Connect (CMU150).
//
// A deliberately tiny reader for the near-flat JSON objects the server sends as
// message bodies (Navigation). It is NOT a general JSON parser: it finds a "key"
// and reads the value after it.
//
// Arrays get just enough support for the one nested thing on the wire — the
// Navigation lane row, an array of small flat objects. getArray hands back each
// element verbatim, and an element that is itself an object is then read with the
// same scalar getters, which is what keeps this a reader and not a parser. Deeper
// nesting is still out of scope.
//
// Every function is non-throwing and bounds-checked: a body from the socket is
// untrusted input, so a missing or malformed field simply yields "not found"
// rather than a crash.

#ifndef VEGVISIR_CLIENT_NET_JSON_LITE_H
#define VEGVISIR_CLIENT_NET_JSON_LITE_H

#include <cstddef>
#include <string>
#include <vector>

namespace json {

// "key":"..."  -> out (unescaped UTF-8, NUL-terminated, truncated to outsz).
// Returns true if the key was found and its value was a string.
bool getString(const std::string &body, const char *key, char *out, size_t outsz);

// "key":<number>  -> *out. Accepts an integer or the integer part of a decimal.
bool getInt(const std::string &body, const char *key, long *out);

// "key":true|false  -> *out. Returns true if the key was found as a boolean.
bool getBool(const std::string &body, const char *key, bool *out);

// "key":[e0, e1, …]  -> *out, one entry per element, each the element's own text
// with surrounding whitespace trimmed (an object element keeps its braces, so it
// can be fed straight back into the getters above). Elements past `maxElems` are
// dropped. Returns true if the key was found and its value was an array; an empty
// array yields true with an empty vector.
bool getArray(const std::string &body, const char *key,
              std::vector<std::string> *out, size_t maxElems);

// "key":[1, -2, 3]  -> out[0..*count-1]. Non-numeric elements are skipped, so
// *count is how many numbers were actually read (never more than maxCount).
bool getIntArray(const std::string &body, const char *key,
                 long *out, size_t maxCount, size_t *count);

} // namespace json

#endif // VEGVISIR_CLIENT_NET_JSON_LITE_H
