// SPDX-License-Identifier: AGPL-3.0-or-later
// Author: rongcondihoc
//
// Navigation -> HUD bridge for Mazda Connect (CMU150).
//
// The TCP/IPv6 client. It dials the phone-side server, speaks VEG1, and feeds
// every received message to the router (core/net/message_router.h).
//
// This is the vegvisir-client v1.3 socket client, cloned together with its peer
// discovery (peer_discovery.h). The client finds the phone by itself, from its
// own routing table, on its own thread — it needs nothing from the USB watcher.
// v2's earlier variant (watcher -> clientSetTarget) is gone: a connection that
// depended on netlink/sysfs recognising the link never came up on the unit,
// while this mechanism did. The one addition is clientSetLinkCallback(), which
// hudnav uses to wipe the HUD when the link drops.
//
// THE UNIT DIALS OUT; THE PHONE LISTENS
//
// The phone's address on a USB link cannot be written down in advance, but the
// client can read its own routing table and find the server (peer_discovery.h).
// So the unit is the side that dials.
//
// On connect the client announces its role with a Register{clientType:"mazda"}
// message, then reads the stream. A dead peer surfaces as a closed socket (HUD
// clears at once, not after a watchdog), and discovery has somewhere to fail
// with a diagnosable errno. The cost is the reconnect loop and re-framing the
// byte stream back into envelopes using each header's bodyLen.
//
// A CLOSED SOCKET IS NOT THE ONLY WAY A LINK DIES
//
// The server going away *with the link* (the phone re-tethers and comes back on
// a new address) delivers no FIN at all, so "recv returned 0" would never fire
// and the client would sit on a socket nobody is listening to. The receive loop
// therefore also re-runs discovery every few seconds and redials the moment the
// peer address changes, probes an idle link with a Ping, and tightens the TCP
// keepalive so the kernel gives up in seconds rather than two hours. See the
// LIVENESS comment in socket_client.cpp.
//
// Configuration (all optional; install.sh writes them into the service's
// <environ_var> block in sm.conf when set in its environment):
//   VEGVISIR_PORT=<n>   server port. Default 15985. VEGVISIR_PORT=0 disables.
//   VEGVISIR_IFACE=<s>  interface the phone is on. Default "usb0".
//   VEGVISIR_PEER=<ip>  pin the server's IPv6 address instead of discovering it.

#ifndef VEGVISIR_CLIENT_NET_SOCKET_CLIENT_H
#define VEGVISIR_CLIENT_NET_SOCKET_CLIENT_H

#include "core/net/envelope.h"

namespace net {

// Start the discovery + connect + receive thread. Idempotent; never blocks or
// throws. Every failure logs and retries on a slow cadence.
void clientStart();

// Stop the receiver and close the socket. Joins within the receive timeout.
void clientStop();

// Send an envelope to the server. Thread-safe. Returns false when not connected
// or the write failed.
bool clientSend(const Envelope &env);

// Observe the link: `up` after Register went out, `down` (with a short reason)
// when the socket is dropped. Called on the client thread — do not block.
typedef void (*LinkCallback)(bool up, const char *why);
void clientSetLinkCallback(LinkCallback cb);

} // namespace net

#endif // VEGVISIR_CLIENT_NET_SOCKET_CLIENT_H
