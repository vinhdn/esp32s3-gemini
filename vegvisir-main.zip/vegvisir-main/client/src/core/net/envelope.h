// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Navigation -> HUD bridge for Mazda Connect (CMU150).
//
// The "VEG1" envelope: the framing spoken with the phone-side server (the
// vegvisir module) over the TCP/IPv6 link on port 15985. Wire-compatible with
// the server's C++/Kotlin/Python implementations — the byte layout and the
// MessageType values are normative and must not be renumbered.
//
// Fixed header (19 bytes), all integers big-endian:
//   magic(4) "VEG1" | version(1) | type(1) | flags(1) | id(4) | replyTo(4) | bodyLen(4)
// followed by `bodyLen` body bytes (JSON UTF-8 unless the binary flag is set).

#ifndef VEGVISIR_CLIENT_NET_ENVELOPE_H
#define VEGVISIR_CLIENT_NET_ENVELOPE_H

#include <stdint.h>
#include <cstddef>
#include <string>
#include <vector>

namespace net {

// The message carried over the connection. Wire values are fixed — do not
// renumber. New types append at the end.
//
// The Mazda unit is a ClientType::Mazda client: it RECEIVES Navigation and
// Upgrade, and SENDS Register / Pong / Response.
enum class MessageType : uint8_t {
    Navigation = 1,   // JSON body: maneuver / route guidance  -> hud-navigate
    Upgrade    = 2,   // binary body: replacement libvegvisir-client.so -> upgrade feature

    FileBegin  = 3,   // JSON body: { "name", "size", "mime" }; id = fileId
    FileChunk  = 4,   // binary body: one slice of the file; id = fileId
    FileEnd    = 5,   // empty/JSON body: end of file; id = fileId

    Request    = 6,   // JSON body: client -> server request; id = request id
    Response   = 7,   // JSON body: server -> client reply; replyTo = request id
    Error      = 9,   // JSON body: { "message" }
    Ping       = 10,
    Pong       = 11,

    Register   = 12,  // JSON body: { "clientType" } — sent by us right after connect
};

// One framed message. body is JSON (UTF-8) when binaryBody is false, else raw.
struct Envelope {
    MessageType          type = MessageType::Request;
    uint32_t             id = 0;        // message / file id (0 = none)
    uint32_t             replyTo = 0;   // correlation id for a Response (0 = none)
    bool                 binaryBody = false;
    std::vector<uint8_t> body;
};

constexpr size_t   kEnvelopeHeaderSize = 19;
constexpr uint8_t  kProtocolVersion    = 1;
constexpr uint32_t kMaxBodyLen         = 16u * 1024 * 1024;   // guards bogus lengths

struct EnvelopeHeader {
    MessageType type = MessageType::Request;
    bool        binaryBody = false;
    uint32_t    id = 0;
    uint32_t    replyTo = 0;
    uint32_t    bodyLen = 0;
};

// Serialize a full envelope (header + body) into bytes to write on the socket.
std::vector<uint8_t> encodeEnvelope(const Envelope &env);

// Convenience: build a text (JSON) message with no attached binary.
std::vector<uint8_t> encodeJsonMessage(MessageType type, const std::string &json,
                                       uint32_t id = 0, uint32_t replyTo = 0);

// Parse the fixed header from at least kEnvelopeHeaderSize bytes. Returns false
// on bad magic or unsupported version.
bool parseEnvelopeHeader(const uint8_t *data, EnvelopeHeader &out);

// Human-readable name for a MessageType, for logs.
const char *messageTypeName(MessageType type);

} // namespace net

#endif // VEGVISIR_CLIENT_NET_ENVELOPE_H
