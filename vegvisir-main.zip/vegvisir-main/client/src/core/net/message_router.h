// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Navigation -> HUD bridge for Mazda Connect (CMU150).
//
// The message router: the single place that turns an incoming VEG1 message into
// a feature call. The socket client hands every decoded Envelope to dispatch();
// each feature registers a handler for the MessageType it owns:
//
//   Navigation -> hudnav/   (turn-by-turn onto the HUD)
//
// (v1.3 also routed Upgrade to its self-update feature; this build has none, so
// an Upgrade message is logged and dropped like any other unhandled type.)
//
// A handler is registered once at start and never removed, so registration is
// not synchronised; dispatch() is called only from the socket receive thread.
// Handlers must not throw — dispatch() wraps each call defensively anyway, since
// an exception escaping into the socket thread would abort the host process.

#ifndef VEGVISIR_CLIENT_NET_MESSAGE_ROUTER_H
#define VEGVISIR_CLIENT_NET_MESSAGE_ROUTER_H

#include "core/net/envelope.h"

#include <functional>

namespace net {

typedef std::function<void(const Envelope &)> MessageHandler;

// Register the handler for one message type (replaces any previous one).
void routerRegister(MessageType type, MessageHandler handler);

// Route one received message to its handler. Logs and drops when no handler is
// registered for the type. Never throws.
void routerDispatch(const Envelope &env);

} // namespace net

#endif // VEGVISIR_CLIENT_NET_MESSAGE_ROUTER_H
