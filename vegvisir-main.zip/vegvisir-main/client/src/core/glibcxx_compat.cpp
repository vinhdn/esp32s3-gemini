// SPDX-License-Identifier: AGPL-3.0-or-later
// Author: rongcondihoc
//
// libstdc++ compatibility shim for the CMU's runtime.
//
// The toolchain is GCC 4.9.1 (libstdc++.so.6.0.20), but the Mazda CMU ships
// libstdc++.so.6.0.14 (GCC 4.5 era): its newest symbol version is
// GLIBCXX_3.4.14 (glibc is 2.11). Any symbol our binary imports beyond that
// makes the dynamic loader refuse to start it:
//
//     vegvisir-client: libstdc++.so.6: version `GLIBCXX_3.4.20' not found
//
// GCC 4.9's headers route every range-checked std::string / std::vector call
// (substr, compare(pos, n, ...), at, erase(pos), insert(pos, ...)) through
// std::__throw_out_of_range_fmt, which libstdc++ only exports since
// GLIBCXX_3.4.20. Defining it here, with the exact declared signature, makes
// the linker bind those calls to this local copy (hidden visibility, no
// dynamic import), so the device's older libstdc++ satisfies the rest.
//
// This is deliberately NOT solved with -static-libstdc++: the OEM libraries we
// dlopen (libjcidbus, libjcivbsnaviclient) are linked against the device's
// libstdc++.so.6, and a second, statically baked runtime in the same process
// (its own locale/heap bookkeeping) is exactly what corrupted the heap in the
// oem-aa-mod project. One runtime — the device's — plus this one shim.
//
// build.sh checks the linked binary's version references and fails the build
// if anything newer than the device's runtime sneaks in again.

#include <cstdarg>
#include <stdexcept>
#include <string>
// <stdio.h>, not <cstdio>: the device-era libstdc++ leaves vsnprintf out of std.
#include <stdio.h>

namespace std {

void __throw_out_of_range_fmt(const char *fmt, ...)
{
    char msg[256];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(msg, sizeof msg, fmt, ap);
    va_end(ap);
    // std::string overload of the constructor: present since GLIBCXX_3.4 (the
    // const char* one only arrived with C++11-era libstdc++).
    throw out_of_range(string(msg));
}

} // namespace std
