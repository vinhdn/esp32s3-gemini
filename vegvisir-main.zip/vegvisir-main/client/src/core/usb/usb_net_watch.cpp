// SPDX-License-Identifier: AGPL-3.0-or-later
// Author: rongcondihoc
//
// USB-ethernet link watcher implementation. See usb_net_watch.h for the model.
//
// Netlink parsing follows the usb-bridge research daemon (netwatch.h); the IPv4
// gateway read is its QueryGateway; the IPv6 next-hop read is ported from
// vegvisir-client v1.3 core/net/peer_discovery.cpp.

#define LOG_TAG "USB"
#include "core/log.h"

#include "core/usb/usb_net_watch.h"

#include <arpa/inet.h>
#include <atomic>
#include <cerrno>
#include <cstring>
#include <dirent.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <map>
#include <net/if.h>
#include <netinet/in.h>
#include <poll.h>
#include <pthread.h>
#include <stdint.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
// <stdio.h>, not <cstdio>: the device's GCC-era libstdc++ leaves snprintf out
// of namespace std.
#include <stdio.h>

namespace usbnet {
namespace {

Listener         *g_listener = nullptr;
char              g_pin[IF_NAMESIZE] = "";
int               g_nl = -1;
pthread_t         g_thread = 0;
bool              g_thread_up = false;
std::atomic<bool> g_stop(false);

// Every interface we watch, keyed by kernel index. Touched only on the watcher
// thread. Function-local static: watchStart() is called from a load-time
// constructor, before this TU's own globals are guaranteed to be built.
std::map<unsigned, LinkState> &links()
{
    static std::map<unsigned, LinkState> m;
    return m;
}

// --- identification ----------------------------------------------------------

// Is `ifname` backed by a USB device? sysfs answers this for any usbnet driver
// and any name: /sys/class/net/<if>/device is the USB interface the network
// device hangs off, and its `subsystem` link ends in "/bus/usb". The built-in
// FEC ethernet's ends in "/bus/platform"; lo has no device link at all.
bool usb_backed(const char *ifname)
{
    char path[160];
    snprintf(path, sizeof(path), "/sys/class/net/%s/device/subsystem", ifname);
    char    target[256];
    ssize_t n = readlink(path, target, sizeof(target) - 1);
    if (n > 0) {
        target[n] = '\0';
        const char *base = std::strrchr(target, '/');
        base = base ? base + 1 : target;
        return std::strcmp(base, "usb") == 0;
    }
    // No device link to read (very old sysfs): the usbnet drivers name their
    // interfaces usb%d, so trust the name.
    return std::strncmp(ifname, "usb", 3) == 0;
}

bool candidate(const char *ifname)
{
    if (g_pin[0]) return std::strcmp(ifname, g_pin) == 0;   // pinned: that one, USB or not
    if (std::strcmp(ifname, "lo") == 0) return false;
    return usb_backed(ifname);
}

// --- queries (read-only; nothing is sent, nothing is configured) -------------

void ipv4_to_str(uint32_t s_addr_be, char *out, size_t n)
{
    in_addr a;
    a.s_addr = s_addr_be;
    if (!inet_ntop(AF_INET, &a, out, (socklen_t)n) && n) out[0] = '\0';
}

// Link flags (SIOCGIFFLAGS) and own IPv4 (SIOCGIFADDR) of the interface.
void query_iface(LinkState *st)
{
    st->up     = false;
    st->ip4[0] = '\0';

    const int s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0) return;

    ifreq ifr;
    std::memset(&ifr, 0, sizeof(ifr));
    std::strncpy(ifr.ifr_name, st->ifname, IFNAMSIZ - 1);
    if (ioctl(s, SIOCGIFFLAGS, &ifr) == 0)
        st->up = (ifr.ifr_flags & IFF_UP) != 0 && (ifr.ifr_flags & IFF_RUNNING) != 0;

    std::memset(&ifr, 0, sizeof(ifr));
    std::strncpy(ifr.ifr_name, st->ifname, IFNAMSIZ - 1);
    if (ioctl(s, SIOCGIFADDR, &ifr) == 0) {
        const sockaddr_in *sin = reinterpret_cast<const sockaddr_in *>(&ifr.ifr_addr);
        if (sin->sin_addr.s_addr != 0)
            ipv4_to_str(sin->sin_addr.s_addr, st->ip4, sizeof(st->ip4));
    }
    close(s);
}

// IPv4 default gateway out of `ifname`, from /proc/net/route. On a USB tether
// that is the phone: udhcpc installs it from the DHCP lease. "" when none yet.
void query_gw4(const char *ifname, char *out, size_t n)
{
    out[0] = '\0';
    FILE *f = fopen("/proc/net/route", "r");
    if (!f) return;

    char line[256];
    (void)fgets(line, sizeof(line), f);   // header
    while (fgets(line, sizeof(line), f)) {
        char     dev[64];
        unsigned dest = 0, gw = 0, flags = 0;
        if (sscanf(line, "%63s %x %x %x", dev, &dest, &gw, &flags) != 4) continue;
        // dest 0 = default route; flags must carry RTF_UP | RTF_GATEWAY (0x3).
        // /proc prints the address as the raw little-endian word, so reading it
        // back with %x on this (little-endian) CPU gives s_addr as the kernel
        // holds it.
        if (std::strcmp(dev, ifname) == 0 && dest == 0 && gw != 0 &&
            (flags & 0x0003u) == 0x0003u) {
            ipv4_to_str(gw, out, n);
            break;
        }
    }
    fclose(f);
}

bool hex_nibble(char c, unsigned *out)
{
    if (c >= '0' && c <= '9') { *out = (unsigned)(c - '0');      return true; }
    if (c >= 'a' && c <= 'f') { *out = (unsigned)(c - 'a' + 10); return true; }
    if (c >= 'A' && c <= 'F') { *out = (unsigned)(c - 'A' + 10); return true; }
    return false;
}

// 32 hex digits (as /proc/net/ipv6_route prints an address) -> 16 bytes.
bool parse_hex128(const char *s, in6_addr *out)
{
    if (std::strlen(s) != 32) return false;
    for (int i = 0; i < 16; i++) {
        unsigned hi, lo;
        if (!hex_nibble(s[i * 2], &hi) || !hex_nibble(s[i * 2 + 1], &lo)) return false;
        out->s6_addr[i] = (unsigned char)((hi << 4) | lo);
    }
    return true;
}

// A next hop worth dialling: not unspecified (a route with no gateway prints
// all zeros), not multicast, not loopback (that would be us).
bool plausible_peer6(const in6_addr *a)
{
    bool zero = true;
    for (int i = 0; i < 16; i++) if (a->s6_addr[i] != 0) { zero = false; break; }
    if (zero)                  return false;
    if (a->s6_addr[0] == 0xff) return false;
    static const unsigned char lo[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1};
    if (std::memcmp(a->s6_addr, lo, 16) == 0) return false;
    return true;
}

// IPv6 next hop out of `ifname`, from /proc/net/ipv6_route: the link-local
// address of the router the phone advertises when it tethers. A default route
// wins; any other gateway route on the interface otherwise. "" when none.
void query_gw6(const char *ifname, char *out, size_t n)
{
    out[0] = '\0';
    FILE *fp = fopen("/proc/net/ipv6_route", "r");
    if (!fp) return;   // no IPv6 on this kernel — IPv4 carries the day

    in6_addr best;
    std::memset(&best, 0, sizeof(best));
    bool have = false, best_default = false;

    char line[512];
    while (fgets(line, sizeof(line), fp)) {
        char     dst[64], src[64], nh[64], dev[64];
        unsigned dst_len = 0, src_len = 0, metric = 0, ref = 0, use = 0, flags = 0;
        if (sscanf(line, "%63s %x %63s %x %63s %x %x %x %x %63s",
                   dst, &dst_len, src, &src_len, nh, &metric, &ref, &use, &flags, dev) != 10)
            continue;
        if (std::strcmp(dev, ifname) != 0) continue;

        in6_addr gw;
        if (!parse_hex128(nh, &gw) || !plausible_peer6(&gw)) continue;

        const bool is_default = (dst_len == 0);
        if (!have || (is_default && !best_default)) {
            best         = gw;
            have         = true;
            best_default = is_default;
            if (is_default) break;
        }
    }
    fclose(fp);

    if (have && !inet_ntop(AF_INET6, &best, out, (socklen_t)n)) out[0] = '\0';
}

// --- state -------------------------------------------------------------------

bool same_state(const LinkState &a, const LinkState &b)
{
    return a.up == b.up &&
           std::strcmp(a.ifname, b.ifname) == 0 &&
           std::strcmp(a.ip4, b.ip4) == 0 &&
           std::strcmp(a.gw4, b.gw4) == 0 &&
           std::strcmp(a.gw6, b.gw6) == 0;
}

// Re-read everything about one watched interface and tell the listener if the
// picture changed (or when `force`d, for a first sighting). Netlink events come
// in bursts — link, then address, then route — and every one of them lands
// here; only a real change leaves, so the listener sees a clean sequence.
void evaluate(LinkState &st, bool force)
{
    LinkState fresh;
    std::memset(&fresh, 0, sizeof(fresh));
    std::strncpy(fresh.ifname, st.ifname, IF_NAMESIZE - 1);
    fresh.ifindex = st.ifindex;
    query_iface(&fresh);
    query_gw4(fresh.ifname, fresh.gw4, sizeof(fresh.gw4));
    query_gw6(fresh.ifname, fresh.gw6, sizeof(fresh.gw6));

    if (!force && same_state(fresh, st)) return;
    st = fresh;

    LOGD("%s (idx %u): %s ip=%s gw4=%s gw6=%s",
         st.ifname, st.ifindex, st.up ? "up" : "down",
         st.ip4[0] ? st.ip4 : "-", st.gw4[0] ? st.gw4 : "-", st.gw6[0] ? st.gw6 : "-");
    if (g_listener) g_listener->onUsbNetChanged(st);
}

void track(unsigned idx, const char *name)
{
    LinkState st;
    std::memset(&st, 0, sizeof(st));
    std::strncpy(st.ifname, name, IF_NAMESIZE - 1);
    st.ifindex = idx;

    LinkState &slot = links()[idx];
    slot = st;
    LOGD("USB ethernet interface %s (idx %u) — watching%s", name, idx,
         g_pin[0] ? " (pinned by VEGVISIR_IFACE)" : "");
    evaluate(slot, /*force=*/true);
}

void untrack(unsigned idx)
{
    std::map<unsigned, LinkState>::iterator it = links().find(idx);
    if (it == links().end()) return;
    LinkState last = it->second;
    links().erase(it);
    LOGD("%s (idx %u) removed — cable out", last.ifname, idx);
    if (g_listener) g_listener->onUsbNetRemoved(last);
}

// Interfaces that already exist (service started with the phone plugged in, or
// udev raced our netlink bind): the kernel will not replay their events, so
// walk sysfs once. Also the recovery path after a netlink overrun.
void scan()
{
    DIR *d = opendir("/sys/class/net");
    if (!d) {
        LOGE("cannot open /sys/class/net: %s", std::strerror(errno));
        return;
    }
    while (dirent *e = readdir(d)) {
        if (e->d_name[0] == '.') continue;
        if (!candidate(e->d_name)) continue;
        const unsigned idx = if_nametoindex(e->d_name);
        if (idx == 0) continue;
        std::map<unsigned, LinkState>::iterator it = links().find(idx);
        if (it != links().end()) evaluate(it->second, false);
        else                     track(idx, e->d_name);
    }
    closedir(d);

    // Anything we still watch that sysfs no longer has (a missed RTM_DELLINK).
    std::map<unsigned, LinkState>::iterator it = links().begin();
    while (it != links().end()) {
        const unsigned idx = it->first;
        ++it;   // advance first: untrack() erases idx
        char name[IF_NAMESIZE];
        if (!if_indextoname(idx, name)) untrack(idx);
    }
}

// --- netlink -----------------------------------------------------------------

void on_link(nlmsghdr *nh)
{
    ifinfomsg     *ifi = static_cast<ifinfomsg *>(NLMSG_DATA(nh));
    const unsigned idx = (unsigned)ifi->ifi_index;

    char name[IF_NAMESIZE] = "";
    int  len = (int)IFLA_PAYLOAD(nh);
    for (rtattr *rta = IFLA_RTA(ifi); RTA_OK(rta, len); rta = RTA_NEXT(rta, len)) {
        if (rta->rta_type == IFLA_IFNAME) {
            std::strncpy(name, static_cast<const char *>(RTA_DATA(rta)), IF_NAMESIZE - 1);
            break;
        }
    }

    std::map<unsigned, LinkState>::iterator it = links().find(idx);

    if (nh->nlmsg_type == RTM_DELLINK) {
        if (it != links().end()) untrack(idx);
        return;
    }

    if (it == links().end()) {
        // A new interface. Is it a phone?
        if (!name[0] && !if_indextoname(idx, name)) return;
        if (!candidate(name)) return;
        track(idx, name);
        return;
    }

    // A known interface: a rename (udev's 99-usbnet.rules turns asix adapters
    // into eth1 right after creation) or a flag change (carrier up / down).
    if (name[0] && std::strcmp(it->second.ifname, name) != 0) {
        LOGD("%s renamed to %s", it->second.ifname, name);
        std::strncpy(it->second.ifname, name, IF_NAMESIZE - 1);
        it->second.ifname[IF_NAMESIZE - 1] = '\0';
    }
    evaluate(it->second, false);
}

void on_addr(nlmsghdr *nh)
{
    const ifaddrmsg *ifa = static_cast<const ifaddrmsg *>(NLMSG_DATA(nh));
    std::map<unsigned, LinkState>::iterator it = links().find((unsigned)ifa->ifa_index);
    if (it != links().end()) evaluate(it->second, false);
}

void on_route(nlmsghdr *nh)
{
    rtmsg *rtm = static_cast<rtmsg *>(NLMSG_DATA(nh));
    // Per-destination cache entries (older IPv6 stacks announce them) are noise:
    // they never change which gateway the interface has.
    if (rtm->rtm_flags & RTM_F_CLONED) return;

    unsigned oif = 0;
    int      len = (int)RTM_PAYLOAD(nh);
    for (rtattr *rta = RTM_RTA(rtm); RTA_OK(rta, len); rta = RTA_NEXT(rta, len)) {
        if (rta->rta_type == RTA_OIF) {
            std::memcpy(&oif, RTA_DATA(rta), sizeof(oif));
            break;
        }
    }
    if (oif == 0) return;
    std::map<unsigned, LinkState>::iterator it = links().find(oif);
    if (it != links().end()) evaluate(it->second, false);
}

// Read every netlink message currently queued.
void drain()
{
    char buf[8192];
    for (;;) {
        const ssize_t n = recv(g_nl, buf, sizeof(buf), MSG_DONTWAIT);
        if (n < 0) {
            if (errno == EINTR) continue;
            if (errno == ENOBUFS) {
                // The queue overflowed during a burst; whatever we missed is
                // still visible in sysfs / proc, so re-read it all.
                LOGW("netlink overrun — rescanning");
                scan();
                continue;
            }
            break;   // EAGAIN: drained
        }
        if (n == 0) break;

        int len = (int)n;
        for (nlmsghdr *nh = reinterpret_cast<nlmsghdr *>(buf);
             NLMSG_OK(nh, static_cast<unsigned>(len));
             nh = NLMSG_NEXT(nh, len)) {
            if (nh->nlmsg_type == NLMSG_DONE) break;
            if (nh->nlmsg_type == NLMSG_ERROR) continue;
            switch (nh->nlmsg_type) {
            case RTM_NEWLINK:  case RTM_DELLINK:  on_link(nh);  break;
            case RTM_NEWADDR:  case RTM_DELADDR:  on_addr(nh);  break;
            case RTM_NEWROUTE: case RTM_DELROUTE: on_route(nh); break;
            default: break;
            }
        }
    }
}

void *watch_main(void *)
{
    scan();   // what is already plugged in
    while (!g_stop.load(std::memory_order_relaxed)) {
      try {  // nothing may escape this thread (std::terminate would take the service down)
        pollfd pfd;
        pfd.fd      = g_nl;
        pfd.events  = POLLIN;
        pfd.revents = 0;
        const int r = poll(&pfd, 1, 500);   // 500 ms heartbeat for the stop flag
        if (r < 0) {
            if (errno == EINTR) continue;
            LOGE("poll: %s", std::strerror(errno));
            usleep(200 * 1000);
            continue;
        }
        if (r == 0) continue;
        drain();
      } catch (...) {
        LOGE("watcher exception swallowed — continuing");
        usleep(200 * 1000);
      }
    }
    LOGD("watcher thread exiting");
    return nullptr;
}

} // namespace

bool watchStart(Listener *listener, const char *pinIface)
{
    if (g_thread_up) return true;

    g_listener = listener;
    g_pin[0]   = '\0';
    if (pinIface && *pinIface) {
        std::strncpy(g_pin, pinIface, IF_NAMESIZE - 1);
        g_pin[IF_NAMESIZE - 1] = '\0';
    }

    g_nl = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
    if (g_nl < 0) {
        LOGC("netlink socket failed: %s", std::strerror(errno));
        return false;
    }
    sockaddr_nl sa;
    std::memset(&sa, 0, sizeof(sa));
    sa.nl_family = AF_NETLINK;
    sa.nl_groups = RTMGRP_LINK | RTMGRP_IPV4_IFADDR | RTMGRP_IPV6_IFADDR |
                   RTMGRP_IPV4_ROUTE | RTMGRP_IPV6_ROUTE;
    if (bind(g_nl, reinterpret_cast<sockaddr *>(&sa), sizeof(sa)) < 0) {
        LOGC("netlink bind failed: %s", std::strerror(errno));
        close(g_nl);
        g_nl = -1;
        return false;
    }
    // A plug-in is a burst (link + addresses + routes); do not let it overrun us.
    int rcvbuf = 256 * 1024;
    setsockopt(g_nl, SOL_SOCKET, SO_RCVBUF, &rcvbuf, sizeof(rcvbuf));

    g_stop.store(false, std::memory_order_release);
    if (pthread_create(&g_thread, nullptr, watch_main, nullptr) != 0) {
        LOGC("failed to spawn watcher thread");
        close(g_nl);
        g_nl = -1;
        return false;
    }
    g_thread_up = true;

    if (g_pin[0]) LOGD("watching interface %s (pinned by VEGVISIR_IFACE)", g_pin);
    else          LOGD("watching for USB ethernet interfaces (rtnetlink link/addr/route)");
    return true;
}

void watchStop()
{
    if (!g_thread_up) return;
    g_stop.store(true, std::memory_order_release);
    pthread_join(g_thread, nullptr);
    g_thread_up = false;
    g_thread    = 0;
    if (g_nl >= 0) { close(g_nl); g_nl = -1; }
    links().clear();
    LOGD("stopped");
}

} // namespace usbnet
