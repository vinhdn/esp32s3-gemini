// SPDX-License-Identifier: AGPL-3.0-or-later
// Author: rongcondihoc
//
// The USB-ethernet link watcher: "a phone was plugged in, this is its address".
//
// WHAT HAPPENS ON THE UNIT WHEN A PHONE IS PLUGGED IN
//
// The stock CMU already does the network setup — nothing here changes it:
//   1. the kernel binds a usbnet driver (cdc_ether / cdc_ncm / rndis_host / asix)
//      and creates an interface (usb0, or eth1 for asix via 99-usbnet.rules);
//   2. /etc/udev/rules.d/99-usbdiscoverer.rules recognises the USB interface
//      class (02/01 CDC, e0/01 + ef/01 RNDIS) and runs linux_dhcp_setup.sh %k;
//   3. that script does `ifconfig up` + `udhcpc -i <if>`: the phone's DHCP
//      server leases us an IPv4 and udhcpc installs a default route through the
//      phone. A phone that also does IPv6 tethering additionally advertises
//      itself as a router, so the kernel records its link-local address as the
//      next hop of a route out of the interface.
//
// HOW WE LEARN ABOUT IT WITHOUT TOUCHING ANY OF THAT
//
// The kernel broadcasts every step on rtnetlink: RTM_NEWLINK when the interface
// appears, RTM_NEWADDR when udhcpc assigns the lease, RTM_NEWROUTE when the
// gateway lands (the usb-bridge research daemon proved this out; this is the same
// RTMGRP_IPV4_IFADDR subscription plus the link and route groups). We subscribe
// once and wait — no polling, no hook into the DHCP flow, no udev rule of our
// own. "Is this interface USB?" is answered by sysfs: /sys/class/net/<if>/device
// is the USB interface the network device hangs off, and its `subsystem` link
// ends in /bus/usb (the built-in ethernet's ends in /bus/platform), so udev's
// class-matching trick is not needed to tell a phone from the wired port.
//
// On every event for a watched interface we re-read its own IPv4 (SIOCGIFADDR),
// the IPv4 default gateway through it (/proc/net/route) and the IPv6 next hop
// through it (/proc/net/ipv6_route), and report the picture to the listener when
// it changed. THE PEER IS THE GATEWAY: the phone runs the server, and on a tether
// the phone is the router, so "the gateway out of the USB interface" is the
// address to dial. Interfaces that already exist at start are picked up from
// sysfs (the kernel does not replay events for them).
//
// ROLE IN v2: DIAGNOSTICS. The socket client finds the phone by itself (the v1.3
// mechanism, core/net/peer_discovery.h) and never waits for this watcher; what
// the watcher adds is the link's timeline in the log — interface up, lease,
// gw4/gw6, cable out — so a "no peer" can be read off the log. main.cpp starts
// it with a NULL listener (allowed: every callback is skipped).
//
// Callbacks run on the watcher thread and must not block or throw — do the
// bookkeeping and return.

#ifndef VEGVISIR_CLIENT_USB_NET_WATCH_H
#define VEGVISIR_CLIENT_USB_NET_WATCH_H

#include <net/if.h>
#include <netinet/in.h>

namespace usbnet {

// Everything known about one USB ethernet interface. Empty string = not (yet).
struct LinkState {
    char     ifname[IF_NAMESIZE];
    unsigned ifindex;                   // kernel interface index (IPv6 scope id)
    bool     up;                        // IFF_UP and IFF_RUNNING (carrier)
    char     ip4[INET_ADDRSTRLEN];      // our own IPv4 on it (the DHCP lease)
    char     gw4[INET_ADDRSTRLEN];      // IPv4 default gateway through it = the phone
    char     gw6[INET6_ADDRSTRLEN];     // IPv6 next hop through it = the phone (link-local)
};

class Listener {
public:
    virtual ~Listener() {}
    // The interface exists and something about it changed (also fired once when
    // it is first seen). Addresses may still be empty — DHCP takes a moment.
    virtual void onUsbNetChanged(const LinkState &st) = 0;
    // The interface is gone (cable pulled). `last` is the final state it had.
    virtual void onUsbNetRemoved(const LinkState &last) = 0;
};

// Start the watcher thread. `pinIface` (NULL/empty = auto-detect USB interfaces)
// restricts watching to one interface name and skips the USB-bus check —
// VEGVISIR_IFACE, for a unit whose interface is not USB-backed or for a test
// box. Idempotent. Returns false if the netlink socket could not be opened.
bool watchStart(Listener *listener, const char *pinIface);

// Stop the watcher thread and forget every interface. Joins.
void watchStop();

} // namespace usbnet

#endif // VEGVISIR_CLIENT_USB_NET_WATCH_H
