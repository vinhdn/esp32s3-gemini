// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Navigation -> HUD bridge for Mazda Connect (CMU150).
//
// The navigation model shared by the two halves of the bridge: hudnav decodes
// the server's Navigation JSON into these types and the HUD sink renders them.
// The types are source-neutral (they predate hudnav), so the sink knows nothing
// about JSON or the socket.

#ifndef VEGVISIR_CLIENT_NAV_TYPES_H
#define VEGVISIR_CLIENT_NAV_TYPES_H

#include <stdint.h>

// Turn event. Numbering follows the Android-Auto hu.proto
// NAVTurnMessage.TURN_EVENT enum (sparse) because the HUD glyph lookup table
// was validated against it; the server's "event" field uses these values.
enum NavEvent : uint32_t {
    NAV_EV_UNKNOWN     = 0,
    NAV_EV_DEPART      = 1,
    NAV_EV_NAME_CHANGE = 2,
    NAV_EV_SLIGHT      = 3,
    NAV_EV_TURN        = 4,
    NAV_EV_SHARP       = 5,
    NAV_EV_UTURN       = 6,
    NAV_EV_ON_RAMP     = 7,
    NAV_EV_OFF_RAMP    = 8,
    NAV_EV_FORK        = 9,
    NAV_EV_MERGE       = 10,
    NAV_EV_ROUNDABOUT  = 13,   // directional glyph chosen from `angle`
    NAV_EV_STRAIGHT    = 14,
    NAV_EV_FERRY       = 16,
    NAV_EV_DEST        = 19,
};

// Turn side. Matches hu.proto TURN_SIDE.
enum NavSide : uint32_t {
    NAV_SIDE_LEFT  = 1,
    NAV_SIDE_RIGHT = 2,
    NAV_SIDE_NONE  = 3,   // unspecified / straight
};

// Distance unit. Matches hu.proto DISPLAY_DISTANCE_UNIT; the
// HUD sink maps it to the OEM cluster's own unit enum.
enum NavDistanceUnit : uint32_t {
    NAV_UNIT_METERS      = 1,
    NAV_UNIT_KILOMETERS10 = 2,
    NAV_UNIT_KILOMETERS  = 3,
    NAV_UNIT_MILES10     = 4,
    NAV_UNIT_MILES       = 5,
    NAV_UNIT_FEET        = 6,
};

// A single normalized maneuver ready for HUD display.
struct NavManeuver {
    uint32_t event;         // NavEvent
    uint32_t side;          // NavSide
    int32_t  angle;         // roundabout exit bearing [0,360); 0 otherwise
    int32_t  number;        // roundabout exit number (1..19); 0 otherwise
    char     road[256];     // NUL-terminated UTF-8; road this maneuver leads onto
};

// A distance readout to the next maneuver.
struct NavDistance {
    int32_t  meters;            // raw metres to next maneuver
    int32_t  timeUntilSeconds;  // ETA seconds (0 if unknown)
    int32_t  displayDistance;   // raw display unit * 1000 (proto convention)
    uint32_t displayUnit;       // NavDistanceUnit
};

// The approach lanes at the next maneuver, described the way a routing source
// describes them: per lane, every direction it allows, which of those the route
// actually takes, and whether the driver should be in it. Nothing here knows the
// OEM lane codes — hud/hud_lane.h turns this into the cluster's lane glyphs.

// Model capacity. 8 lanes because that is the cluster's own lane row width.
enum {
    NAV_LANE_MAX        = 8,   // lanes carried in one NavLanes
    NAV_LANE_ANGLES_MAX = 8,   // directions carried in one NavLane
};

// `NavLane::highlight` value for "this lane highlights no direction".
const int32_t NAV_LANE_NO_HIGHLIGHT = 0x7fffffff;

// One approach lane.
struct NavLane {
    int32_t angles[NAV_LANE_ANGLES_MAX];  // directions this lane allows, degrees:
                                          // 0 = straight, negative = left,
                                          // positive = right
    int32_t angleCount;                   // valid entries in `angles` (0..8)
    int32_t highlight;                    // direction the route takes, degrees, or
                                          // NAV_LANE_NO_HIGHLIGHT
    int32_t recommended;                  // 1 = a lane to be in for the maneuver
};

// The whole lane row for the maneuver in play, left to right. `count == 0`
// blanks the row (the normal state — most maneuvers carry no lane data).
struct NavLanes {
    NavLane lanes[NAV_LANE_MAX];
    int32_t count;
};

#endif // VEGVISIR_CLIENT_NAV_TYPES_H
