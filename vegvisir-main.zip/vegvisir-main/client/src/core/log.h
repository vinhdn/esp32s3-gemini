// SPDX-License-Identifier: AGPL-3.0-or-later
// Author: rongcondihoc
//
// Shared logging helpers, used by every translation unit.
//
// Each line carries a timestamp, the subsystem tag (LOG_TAG) and a level letter,
// so the log reads as a timeline and greps by subsystem:
//
//   2026-08-25 14:46:43 [vegvisir-client][USB][D] usb0 (idx 5): up ip=192.168.42.12 ...
//   2026-08-25 14:46:44 [vegvisir-client][NET][D] client: connected to ...
//
// Define LOG_TAG before including this header to label a TU's lines, e.g.
//
//   #define LOG_TAG "USB"
//   #include "core/log.h"
//
// Output goes to g_logf (the file main.cpp opens on load — the service has no
// terminal and sm swallows stderr) and falls back to stderr while it is NULL.
//
// Levels are compile-time gated by LOG_LEVEL. Anything below the threshold
// expands to an `if (false)` guard: the format string stays type-checked, the
// call is dead-code-eliminated. Release (-DNDEBUG) keeps DEBUG and up — the
// lifecycle lines (USB plugged, IP + peer found, connected, link down) are the
// whole point of the log on a unit with no shell — and drops VERBOSE (the
// per-message chatter: every Navigation frame, every HUD send). Debug keeps all.

#ifndef VEGVISIR_CLIENT_LOG_H
#define VEGVISIR_CLIENT_LOG_H

#include <cstddef>
#include <cstdio>
#include <ctime>
#include <stdint.h>

// Log sink, opened by main.cpp on load. NULL -> fall back to stderr.
extern std::FILE *g_logf;

#define LOG_LEVEL_VERBOSE  0
#define LOG_LEVEL_DEBUG    1
#define LOG_LEVEL_WARN     2
#define LOG_LEVEL_ERROR    3
#define LOG_LEVEL_CRITICAL 4
#define LOG_LEVEL_SILENT   5

#ifndef LOG_LEVEL
// #  ifdef NDEBUG
// #    define LOG_LEVEL LOG_LEVEL_DEBUG
// #  else
#    define LOG_LEVEL LOG_LEVEL_VERBOSE
// #  endif
#endif

// Subsystem tag for this translation unit. Default "CORE".
#ifndef LOG_TAG
#  define LOG_TAG "CORE"
#endif

// "YYYY-MM-DD HH:MM:SS" into buf (>= 20 bytes); empty string if the clock is unavailable.
inline void log_stamp(char *buf, size_t n)
{
    if (n == 0) return;
    buf[0] = '\0';
    time_t    now = time(nullptr);
    struct tm tmv;
    if (localtime_r(&now, &tmv))
        strftime(buf, n, "%Y-%m-%d %H:%M:%S", &tmv);
}

#define LOG_EMIT(level, fmt, ...)                                              \
    do {                                                                       \
        std::FILE *_lf = g_logf ? g_logf : stderr;                             \
        char _ts[24];                                                          \
        log_stamp(_ts, sizeof _ts);                                            \
        std::fprintf(_lf, "%s [vegvisir-client][" LOG_TAG "][" level "] " fmt "\n", \
                     _ts, ##__VA_ARGS__);                                      \
        std::fflush(_lf);                                                      \
    } while (0)

// Keep the format string type-checked even when the level is compiled out.
#define LOG_DROP(fmt, ...)                                                     \
    do {                                                                       \
        if (false) {                                                           \
            std::fprintf(stderr, "[vegvisir-client][" LOG_TAG "] " fmt "\n",   \
                         ##__VA_ARGS__);                                       \
        }                                                                      \
    } while (0)

#if LOG_LEVEL <= LOG_LEVEL_VERBOSE
#  define LOGV(fmt, ...) LOG_EMIT("V", fmt, ##__VA_ARGS__)
#else
#  define LOGV(fmt, ...) LOG_DROP(fmt, ##__VA_ARGS__)
#endif

#if LOG_LEVEL <= LOG_LEVEL_DEBUG
#  define LOGD(fmt, ...) LOG_EMIT("D", fmt, ##__VA_ARGS__)
#else
#  define LOGD(fmt, ...) LOG_DROP(fmt, ##__VA_ARGS__)
#endif

#if LOG_LEVEL <= LOG_LEVEL_WARN
#  define LOGW(fmt, ...) LOG_EMIT("W", fmt, ##__VA_ARGS__)
#else
#  define LOGW(fmt, ...) LOG_DROP(fmt, ##__VA_ARGS__)
#endif

#if LOG_LEVEL <= LOG_LEVEL_ERROR
#  define LOGE(fmt, ...) LOG_EMIT("E", fmt, ##__VA_ARGS__)
#else
#  define LOGE(fmt, ...) LOG_DROP(fmt, ##__VA_ARGS__)
#endif

#if LOG_LEVEL <= LOG_LEVEL_CRITICAL
#  define LOGC(fmt, ...) LOG_EMIT("C", fmt, ##__VA_ARGS__)
#else
#  define LOGC(fmt, ...) LOG_DROP(fmt, ##__VA_ARGS__)
#endif

#endif // VEGVISIR_CLIENT_LOG_H
