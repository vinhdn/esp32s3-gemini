// SPDX-License-Identifier: AGPL-3.0-or-later
// Author: rongcondihoc
//
// Locating the OEM libraries from a standalone process.
//
// vegvisir-client v1.3 was an LD_PRELOAD guest inside jciCARPLAY, where
// libjcidbus / libjcivbsnaviclient were already mapped and dlopen(soname) could
// not fail. This service is its own process (sm runs a stock host binary with
// LD_PRELOAD set to us), so nothing is resident and the search path matters:
// try the bare soname first (LD_LIBRARY_PATH / ld.so.conf — install.sh puts
// /jci/lib:/usr/lib in the service's environment), then the directories the
// OEM keeps its libraries in.

#ifndef VEGVISIR_CLIENT_OEM_LOAD_H
#define VEGVISIR_CLIENT_OEM_LOAD_H

#include <dlfcn.h>
#include <string.h>
// <stdio.h>, not <cstdio>: the device's GCC-era libstdc++ leaves snprintf out
// of namespace std.
#include <stdio.h>

// dlopen `soname` (RTLD_NOW | RTLD_GLOBAL). Returns the handle, or NULL when no
// search location had it (dlerror() then describes the last failure). `where`
// (>= 128 bytes, may be NULL) receives the path that succeeded, for the log.
inline void *oem_dlopen(const char *soname, char *where, unsigned where_len)
{
    static const char *const kDirs[] = { "", "/jci/lib/", "/usr/lib/", "/lib/" };
    for (unsigned i = 0; i < sizeof(kDirs) / sizeof(kDirs[0]); ++i) {
        char path[128];
        snprintf(path, sizeof(path), "%s%s", kDirs[i], soname);
        void *h = dlopen(path, RTLD_NOW | RTLD_GLOBAL);
        if (h == nullptr) continue;
        if (where && where_len) {
            strncpy(where, path, where_len - 1);
            where[where_len - 1] = '\0';
        }
        return h;
    }
    return nullptr;
}

#endif // VEGVISIR_CLIENT_OEM_LOAD_H
