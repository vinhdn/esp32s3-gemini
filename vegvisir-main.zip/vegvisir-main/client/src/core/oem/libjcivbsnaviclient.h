// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Navigation -> HUD bridge for Mazda Connect (CMU150).
//
// OEM D-Bus HUD bindings (libjcivbsnaviclient, layered on libjcidbus).
//
// This header reads like the vendor header that never shipped: just the structs
// and prototypes of the OEM C functions we call. Each prototype is backed by a
// self-resolving thunk in libjcivbsnaviclient.cpp that lazily dlsym()s the real
// symbol on first use, caches it, and forwards. An unresolved symbol degrades to
// a benign failure return (0 / -1) instead of crashing.
//
// The connection lifecycle (JCIDBUS_conn_*, worker, bus selectors) lives in the
// sibling libjcidbus.h, included here so callers get the whole HUD surface from
// this one header.
//
// All signatures were hand-derived from the Ghidra decompile of
// libjcivbsnaviclient.so — no header ships. Re-verify after any firmware update.

#ifndef VEGVISIR_CLIENT_LIBJCIVBSNAVICLIENT_H
#define VEGVISIR_CLIENT_LIBJCIVBSNAVICLIENT_H

#include <stdint.h>

#include "core/oem/libjcidbus.h"   // connection lifecycle + kJci*Bus selectors

// 12-byte com.jci.vbs.navi HUD frame, signature (uqyqyy). Field offsets verified
// against VBS_NAVI_HUD_Display_s_t_pack: u32@0, u16@4, u8@6, u16@8, u8@10, u8@11
// (sizeof == 12 with the natural pad byte at offset 7).
struct VbsNaviHudDisplay {
    uint32_t nextManeuverInfo;
    uint16_t distanceValue;
    uint8_t  distanceUnit;
    uint16_t displaySpeedLimit;
    uint8_t  displaySpeedUnit;
    uint8_t  text_ID3;
};

// 8-byte com.jci.vbs.navi.tmc street-name struct, signature (sy): char*@0, u8@4.
// The library transcodes UTF-8 -> UCS-2 and pages it internally; we just hand it
// a NUL-terminated C string.
struct VbsNaviHudMsg2 {
    const char *guidancePointName;
    uint8_t     syncBit;
};

// --- HUD setters ------------------------------------------------------------
// Setters: (conn, &struct, unused, completion_cb, user) -> int (0 = queued OK).
// Pass NULL completion_cb/user when no reply is needed. GetHUDStatus(conn, cb,
// user); the reply callback is invoked as cb(conn, status_byte, user) — a zero
// status byte means the HUD is not installed / not powered.
int VBS_NAVI_SetHUDDisplayMsgReq(void *conn, VbsNaviHudDisplay *disp,
                                 void *unused, void *cb, void *user);
int VBS_NAVI_TMC_SetHUD_Display_Msg2(void *conn, VbsNaviHudMsg2 *msg2,
                                     void *unused, void *cb, void *user);
int VBS_NAVI_GetHUDStatus(void *conn, void *cb, void *user);

// --- recommended-lane setter -------------------------------------------------
// The lane row is a DIFFERENT OEM method from the maneuver block: one byte array
// (D-Bus signature (ay)), one lane-glyph code per cluster lane slot, 0xFF for a
// slot that draws nothing. Unlike the setters above it takes the array out of
// line — a pointer to the buffer pointer plus a pointer to the element count —
// which is the call form the hudbridge-hud reference drives a real cluster with
// (mcu/src/lane, see NOTICE.md). If a firmware ever ignores it, the alternative
// reading of the decompile is the usual `(conn, &struct{ptr,len}, unused, …)`
// shape of the setters above.
int VBS_NAVI_SetRecommLaneReq(void *conn, const uint8_t *const *lane,
                              const uint32_t *laneCount, void *cb, void *user);

#endif // VEGVISIR_CLIENT_LIBJCIVBSNAVICLIENT_H
