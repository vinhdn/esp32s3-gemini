// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Navigation -> HUD bridge for Mazda Connect (CMU150).
//
// Self-resolving thunks for libjcidbus connection lifecycle. See libjcidbus.h
// for the rationale and the hand-derived ABI, and oem_thunk.h for the macros.

#define LOG_TAG "LIBJCIDBUS"
#include "core/log.h"

#include "core/oem/libjcidbus.h"
#include "core/oem/oem_load.h"
#include "core/oem/oem_thunk.h"

#include <dlfcn.h>

namespace {

// Open the library once (see oem_load.h for why the search path matters here).
void *oem_handle()
{
	char  where[128] = "";
	void *h = oem_dlopen("libjcidbus.so", where, sizeof(where));
	if (h) LOGD("oem: %s loaded", where);
	else   LOGC("oem: dlopen(libjcidbus.so) failed on every search path: %s", dlerror());
	return h;
}

// Resolve one libjcidbus symbol by name, falling back to the global scope if
// the dlopen did not take.
void *oem_sym(const char *name)
{
	static void *handle = oem_handle();
	void *sym = dlsym(handle ? handle : RTLD_DEFAULT, name);
	if (sym == nullptr) {
		LOGC("oem: dlsym(%s) failed: %s", name, dlerror());
	}
	return sym;
}

} // namespace

OEM_THUNK(void *, JCIDBUS_conn_create,
          (void *error_cb, int reserved), (error_cb, reserved), nullptr)
OEM_THUNK(int, JCIDBUS_conn_connect,
          (void *conn, const char *name, int jcibus, void *reserved),
          (conn, name, jcibus, reserved), 0)
OEM_THUNK(int, JCIDBUS_worker_start, (void *conn), (conn), -1)
OEM_THUNK_VOID(JCIDBUS_worker_stop, (void *conn), (conn))
OEM_THUNK_VOID(JCIDBUS_conn_disconnect, (void *conn), (conn))
OEM_THUNK_VOID(JCIDBUS_conn_free, (void *conn), (conn))
