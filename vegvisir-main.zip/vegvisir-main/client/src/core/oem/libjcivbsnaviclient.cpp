// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Navigation -> HUD bridge for Mazda Connect (CMU150).
//
// Self-resolving thunks for the OEM HUD setters (libjcivbsnaviclient). See
// libjcivbsnaviclient.h for the rationale and ABI, and oem_thunk.h for the macro.

#define LOG_TAG "LIBJCIVBSNAVICLIENT"
#include "core/log.h"

#include "core/oem/libjcivbsnaviclient.h"
#include "core/oem/oem_load.h"
#include "core/oem/oem_thunk.h"

#include <dlfcn.h>

namespace {

// Open the library once (see oem_load.h for why the search path matters here).
void *oem_handle()
{
	char  where[128] = "";
	void *h = oem_dlopen("libjcivbsnaviclient.so", where, sizeof(where));
	if (h) LOGD("oem: %s loaded", where);
	else   LOGC("oem: dlopen(libjcivbsnaviclient.so) failed on every search path: %s", dlerror());
	return h;
}

// Resolve one symbol by name, falling back to the global scope if the dlopen
// did not take.
void *oem_sym(const char *name)
{
	static void *handle = oem_handle();
	void *sym = dlsym(handle ? handle : RTLD_DEFAULT, name);
	if (sym == nullptr) {
		LOGC("oem: dlsym(%s) failed: %s", name, dlerror());
	}
	return sym;
}

} // namespace

OEM_THUNK(int, VBS_NAVI_SetHUDDisplayMsgReq,
          (void *conn, VbsNaviHudDisplay *disp, void *unused, void *cb, void *user),
          (conn, disp, unused, cb, user), -1)
OEM_THUNK(int, VBS_NAVI_TMC_SetHUD_Display_Msg2,
          (void *conn, VbsNaviHudMsg2 *msg2, void *unused, void *cb, void *user),
          (conn, msg2, unused, cb, user), -1)
OEM_THUNK(int, VBS_NAVI_GetHUDStatus,
          (void *conn, void *cb, void *user), (conn, cb, user), -1)
OEM_THUNK(int, VBS_NAVI_SetRecommLaneReq,
          (void *conn, const uint8_t *const *lane, const uint32_t *laneCount,
           void *cb, void *user),
          (conn, lane, laneCount, cb, user), -1)
