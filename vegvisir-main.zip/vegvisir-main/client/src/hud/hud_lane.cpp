// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Adapted from hudbridge-hud (mcu/src/lane), which ports the tables from
// VitaliyKurokhtin's oem-aa-mod hud_lane.h. AGPL-3.0 — see NOTICE.md.
//
// Lane-row translation. See hud_lane.h for the interface.
//
// The chain is three tables in a row:
//
//   angles -> direction bitmask (OD_*)   the lane's allowed directions, bucketed
//   bitmask (+ highlight) -> OEM code    0..70, the OEM's own lane vocabulary
//   OEM code -> cluster glyph            Table A, what the ECU actually draws
//
// All three are ported VERBATIM — same tables, same order of decisions — from a
// chain that has been verified against a real cluster. They are not re-derived
// here on purpose: a second, independently written table is how lane arrows
// silently start pointing the wrong way.

#define LOG_TAG "HUDLANE"
#include "core/log.h"
#include "hud/hud_lane.h"

namespace {

// ---- direction bitmask (VitaliyKurokhtin OD_*) -----------------------------
enum {
    OD_STRAIGHT = 1, OD_SLIGHT_R = 2, OD_RIGHT = 4, OD_SHARP_R = 8,
    OD_SLIGHT_L = 16, OD_LEFT = 32, OD_SHARP_L = 64,
};

unsigned angle_to_od(int32_t deg)
{
    if (deg <= -110) return OD_SHARP_L;
    if (deg <=  -45) return OD_LEFT;
    if (deg <=  -15) return OD_SLIGHT_L;
    if (deg <    15) return OD_STRAIGHT;
    if (deg <    45) return OD_SLIGHT_R;
    if (deg <   110) return OD_RIGHT;
    return OD_SHARP_R;
}

// The OEM lane code for a set of allowed directions, ignoring any highlight.
// 0 = the combination has no code of its own (the caller then falls back).
int oem_base_for_dirs(unsigned d)
{
    switch (d) {
    case OD_STRAIGHT: return 1;  case OD_SLIGHT_R: return 2;  case OD_RIGHT: return 3;
    case OD_SHARP_R: return 4;   case OD_SLIGHT_L: return 5;  case OD_LEFT: return 6;
    case OD_SHARP_L: return 7;
    case OD_STRAIGHT|OD_SLIGHT_R: return 8;  case OD_STRAIGHT|OD_SLIGHT_L: return 9;
    case OD_SLIGHT_L|OD_STRAIGHT|OD_SLIGHT_R: return 10;
    case OD_STRAIGHT|OD_RIGHT: return 11;     case OD_STRAIGHT|OD_LEFT: return 12;
    case OD_LEFT|OD_STRAIGHT|OD_RIGHT: return 13;
    case OD_SLIGHT_R|OD_SHARP_R: return 14;   case OD_SLIGHT_L|OD_SHARP_L: return 15;
    case OD_SLIGHT_L|OD_SLIGHT_R: return 16;  case OD_LEFT|OD_RIGHT: return 19;
    default: return 0;
    }
}

// A multi-direction lane with ONE highlighted direction has its own code, which
// draws the highlighted arrow solid and the rest faint. 0 = no such variant.
int oem_detail(int base, unsigned hl)
{
    switch (base) {
    case 8:  return hl==OD_STRAIGHT?23: hl==OD_SLIGHT_R?24:0;
    case 9:  return hl==OD_STRAIGHT?25: hl==OD_SLIGHT_L?26:0;
    case 10: return hl==OD_STRAIGHT?27: hl==OD_SLIGHT_L?28: hl==OD_SLIGHT_R?29:0;
    case 11: return hl==OD_STRAIGHT?30: hl==OD_RIGHT?31:0;
    case 12: return hl==OD_STRAIGHT?32: hl==OD_LEFT?33:0;
    case 13: return hl==OD_STRAIGHT?34: hl==OD_LEFT?35: hl==OD_RIGHT?36:0;
    case 14: return hl==OD_SLIGHT_R?37: hl==OD_SHARP_R?38:0;
    case 15: return hl==OD_SLIGHT_L?39: hl==OD_SHARP_L?40:0;
    case 16: return hl==OD_SLIGHT_L?41: hl==OD_SLIGHT_R?42:0;
    case 19: return hl==OD_LEFT?47: hl==OD_RIGHT?48:0;
    default: return 0;
    }
}

// present = OR of every direction the lane allows; hl = the highlighted one (0 =
// none); rec = the lane is one to be in. Returns the OEM lane code 0..70.
int oem_lane_code(unsigned present, unsigned hl, bool rec)
{
    if (present == 0) return 0;
    int  base   = oem_base_for_dirs(present);
    bool one_hl = hl != 0 && ((hl & (hl - 1)) == 0);
    if (rec && one_hl) {
        int d = oem_detail(base, hl);
        if (d != 0) return d;
    }
    if (base == 0) {
        // No code for this direction combination: fall back to a single arrow —
        // the highlighted direction if there is exactly one, else the lowest bit
        // set (OD_STRAIGHT first, by the enum order).
        unsigned pick = one_hl ? hl : (present & (0u - present));
        base = oem_base_for_dirs(pick);
        if (base == 0) base = 1;
    }
    return rec ? base : base + 48;      // +48 = the non-recommended variant
}

// OEM lane code (0..70) -> cluster glyph byte, Table A (VitaliyKurokhtin).
uint8_t oem_glyph(int code)
{
    static const uint8_t A[71] = {
         0, 1, 2, 2, 3, 4, 4, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,19,20,21, 6,
         7, 8, 9,10,11,12, 6, 7, 8, 9,10,15,13,13,14,15,16,17,18, 6, 7, 8, 9, 9,
         7,22,23,23,24,25,25,26,27,28,29,27,28,29,30,31,32,30,31,32,33,34,35 };
    return (code >= 0 && code < 71) ? A[code] : 0;
}

} // namespace

uint8_t hud_lane_glyph(const NavLane &lane)
{
    unsigned present = 0;
    int32_t  n = lane.angleCount;
    if (n > NAV_LANE_ANGLES_MAX) n = NAV_LANE_ANGLES_MAX;
    for (int32_t i = 0; i < n; ++i) present |= angle_to_od(lane.angles[i]);

    unsigned hl = (lane.highlight == NAV_LANE_NO_HIGHLIGHT)
                      ? 0u : angle_to_od(lane.highlight);
    return oem_glyph(oem_lane_code(present, hl, lane.recommended != 0));
}

void hud_lane_encode(const NavLanes &in, uint8_t out[kLaneSlots])
{
    for (int i = 0; i < kLaneSlots; ++i) out[i] = kLaneHidden;

    if (in.count > kLaneSlots) {
        LOGW("lane: %d lanes given, the cluster row holds %d — extras dropped",
             static_cast<int>(in.count), kLaneSlots);
    }
    int32_t n = in.count;
    if (n < 0)            n = 0;
    if (n > NAV_LANE_MAX) n = NAV_LANE_MAX;   // never READ past in.lanes
    if (n > kLaneSlots)   n = kLaneSlots;     // never WRITE past the row
    for (int32_t i = 0; i < n; ++i) out[i] = hud_lane_glyph(in.lanes[i]);
}
