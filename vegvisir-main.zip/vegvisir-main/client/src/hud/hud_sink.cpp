// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Adapted from headunit (https://github.com/Trevelopment/headunit),
// licensed under GNU AGPL v3. See NOTICE.md for the full attribution.
//
// HUD output sink — converts the nav model hudnav pushes in (core/nav_types.h)
// into Mazda "Active Driving Display" HUD frames.
//
// === Transport: OEM libjcidbus (NOT dbus-c++) ==============================
//
// Talks to com.jci.vbs.navi through the OEM libjcidbus + libjcivbsnaviclient C
// libraries (core/oem/). libjcidbus disables libdbus exit-on-disconnect (so a
// private service-bus teardown is non-fatal instead of killing the host
// process) and runs its own I/O worker thread (so we never poll a dead socket).
//
// === Producer / consumer ===================================================
//
// Each hud:: setter (maneuver / distance / routeActive / ...) runs on the
// caller's thread — the socket receive thread — and MUST NOT block: it writes a
// seqlock-protected snapshot, bumps the sequence, and wakes the sender thread.
// The sender thread re-reads the snapshot, diffs it against the previous one,
// and makes the warranted OEM calls (SetHUDDisplayMsgReq for the
// maneuver/distance block, SetHUD_Display_Msg2 for the road strip,
// SetRecommLaneReq for the lane row). A ~2Hz keep-alive re-asserts the last
// frame so the cluster ECU does not age the maneuver out.

#define LOG_TAG "HUD"
#include "core/log.h"
#include "hud/hud_sink.h"
#include "hud/hud_lane.h"                   // lane row -> cluster glyph bytes
#include "core/oem/libjcivbsnaviclient.h"   // OEM transport (libjcidbus + VBS_NAVI_*)

#include <atomic>
#include <condition_variable>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <mutex>
#include <pthread.h>
#include <sched.h>
#include <string>
#include <unistd.h>

namespace {

// ===== Vietnamese UTF-8 normalization ======================================
//
// The Mazda HUD cluster ECU font renders 1-byte ASCII and 2-byte UTF-8 (Latin-1
// Supplement + Latin Extended-A/B: ô ư ơ â ê ă đ á à) but silently DROPS 3-byte
// UTF-8 (Latin Extended Additional U+1E00..) and combining marks. Vietnamese
// precomposed chars with two stacked diacritics (ề ớ ấ …) live in U+1E00.. and
// are 3-byte, so without this they vanish from the road strip.
//
// Fix: map each 3-byte VN char to its nearest 2-byte equivalent, dropping the
// tone mark but keeping the circumflex/horn/breve structure (ề -> ê, ớ -> ơ,
// ấ -> â …); chars with no 2-byte form fall back to ASCII (ạ -> a). 1-byte and
// 2-byte input pass through unchanged.
//
// Toggle: 1 = normalize (default, matches the HUD font); 0 = pass UTF-8 through.
#ifndef VEGVISIR_CLIENT_VN_NORMALIZE
#define VEGVISIR_CLIENT_VN_NORMALIZE 1
#endif

// Map a 3-byte Vietnamese codepoint (U+1E00..U+1EFF) to its best 2-byte or
// 1-byte equivalent. Returns the replacement codepoint (>= 0x80 -> write as
// 2-byte UTF-8; < 0x80 -> ASCII; 0 -> no mapping, caller substitutes '?').
uint32_t vn_normalize_3byte_cp(uint32_t cp)
{
    switch (cp) {
    // Uppercase
    case 0x1EA0: case 0x1EA2:                                        return 'A';    // Ạ Ả
    case 0x1EA4: case 0x1EA6: case 0x1EA8: case 0x1EAA: case 0x1EAC: return 0x00C2; // Ấ Ầ Ẩ Ẫ Ậ -> Â
    case 0x1EAE: case 0x1EB0: case 0x1EB2: case 0x1EB4: case 0x1EB6: return 0x0102; // Ắ Ằ Ẳ Ẵ Ặ -> Ă
    case 0x1EB8: case 0x1EBA: case 0x1EBC:                           return 'E';    // Ẹ Ẻ Ẽ
    case 0x1EBE: case 0x1EC0: case 0x1EC2: case 0x1EC4: case 0x1EC6: return 0x00CA; // Ế Ề Ể Ễ Ệ -> Ê
    case 0x1EC8: case 0x1ECA:                                        return 'I';    // Ỉ Ị
    case 0x1ECC: case 0x1ECE:                                        return 'O';    // Ọ Ỏ
    case 0x1ED0: case 0x1ED2: case 0x1ED4: case 0x1ED6: case 0x1ED8: return 0x00D4; // Ố Ồ Ổ Ỗ Ộ -> Ô
    case 0x1EDA: case 0x1EDC: case 0x1EDE: case 0x1EE0: case 0x1EE2: return 0x01A0; // Ớ Ờ Ở Ỡ Ợ -> Ơ
    case 0x1EE4: case 0x1EE6:                                        return 'U';    // Ụ Ủ
    case 0x1EE8: case 0x1EEA: case 0x1EEC: case 0x1EEE: case 0x1EF0: return 0x01AF; // Ứ Ừ Ử Ữ Ự -> Ư
    case 0x1EF2: case 0x1EF4: case 0x1EF6: case 0x1EF8:              return 'Y';    // Ỳ Ỵ Ỷ Ỹ
    // Lowercase
    case 0x1EA1: case 0x1EA3:                                        return 'a';    // ạ ả
    case 0x1EA5: case 0x1EA7: case 0x1EA9: case 0x1EAB: case 0x1EAD: return 0x00E2; // ấ ầ ẩ ẫ ậ -> â
    case 0x1EAF: case 0x1EB1: case 0x1EB3: case 0x1EB5: case 0x1EB7: return 0x0103; // ắ ằ ẳ ẵ ặ -> ă
    case 0x1EB9: case 0x1EBB: case 0x1EBD:                           return 'e';    // ẹ ẻ ẽ
    case 0x1EBF: case 0x1EC1: case 0x1EC3: case 0x1EC5: case 0x1EC7: return 0x00EA; // ế ề ể ễ ệ -> ê
    case 0x1EC9: case 0x1ECB:                                        return 'i';    // ỉ ị
    case 0x1ECD: case 0x1ECF:                                        return 'o';    // ọ ỏ
    case 0x1ED1: case 0x1ED3: case 0x1ED5: case 0x1ED7: case 0x1ED9: return 0x00F4; // ố ồ ổ ỗ ộ -> ô
    case 0x1EDB: case 0x1EDD: case 0x1EDF: case 0x1EE1: case 0x1EE3: return 0x01A1; // ớ ờ ở ỡ ợ -> ơ
    case 0x1EE5: case 0x1EE7:                                        return 'u';    // ụ ủ
    case 0x1EE9: case 0x1EEB: case 0x1EED: case 0x1EEF: case 0x1EF1: return 0x01B0; // ứ ừ ử ữ ự -> ư
    case 0x1EF3: case 0x1EF5: case 0x1EF7: case 0x1EF9:              return 'y';    // ỳ ỵ ỷ ỹ
    default:                                                         return 0;
    }
}

// Normalize UTF-8 src -> dst. 1-byte and 2-byte chars pass through; 3-byte VN
// chars are normalized; other 3/4-byte chars become '?'. Always NUL-terminates.
size_t normalize_vn(const char *src, char *dst, size_t dst_sz)
{
    if (!dst || dst_sz == 0) return 0;
    if (!src) { dst[0] = '\0'; return 0; }

    size_t       di  = 0;
    const size_t max = dst_sz - 1;
    const unsigned char *s = reinterpret_cast<const unsigned char *>(src);

    while (*s && di < max) {
        unsigned char c  = *s;
        uint32_t      cp = 0;
        size_t        nb = 1;

        if ((c & 0x80) == 0) {
            dst[di++] = static_cast<char>(c);
            s++;
            continue;
        } else if ((c & 0xE0) == 0xC0 && s[1]) {
            if (di + 2 > max) break;
            dst[di++] = static_cast<char>(c);
            dst[di++] = static_cast<char>(s[1]);
            s += 2;
            continue;
        } else if ((c & 0xF0) == 0xE0 && s[1] && s[2]) {
            cp = ((c & 0x0F) << 12) | ((s[1] & 0x3F) << 6) | (s[2] & 0x3F);
            nb = 3;
        } else if ((c & 0xF8) == 0xF0 && s[1] && s[2] && s[3]) {
            cp = ((c & 0x07) << 18) | ((s[1] & 0x3F) << 12) |
                 ((s[2] & 0x3F) << 6) | (s[3] & 0x3F);
            nb = 4;
        } else {
            s++;   // invalid start byte
            continue;
        }

        uint32_t mapped = (nb == 3) ? vn_normalize_3byte_cp(cp) : 0;
        if (mapped != 0 && mapped < 0x80) {
            dst[di++] = static_cast<char>(mapped);
        } else if (mapped >= 0x80 && mapped < 0x800) {
            if (di + 2 > max) break;
            dst[di++] = static_cast<char>(0xC0 | (mapped >> 6));
            dst[di++] = static_cast<char>(0x80 | (mapped & 0x3F));
        } else {
            dst[di++] = '?';
        }
        s += nb;
    }

    dst[di] = '\0';
    return di;
}

// ===== Mazda HUD glyph mapping =============================================
//
// Integer codes the HUD ECU interprets; the glyph atlas is baked into the ECU
// firmware. Mirrors NaviTurns from the reference headunit hud.h.
enum MazdaIcon : uint8_t {
    HUD_STRAIGHT          = 1,
    HUD_LEFT              = 2,
    HUD_RIGHT             = 3,
    HUD_SLIGHT_LEFT       = 4,
    HUD_SLIGHT_RIGHT      = 5,
    HUD_OFF_RAMP_RIGHT    = 7,
    HUD_DESTINATION       = 8,
    HUD_SHARP_RIGHT       = 9,
    HUD_U_TURN_RIGHT      = 10,
    HUD_SHARP_LEFT        = 11,
    HUD_FLAG              = 12,
    HUD_U_TURN_LEFT       = 13,
    HUD_FORK_RIGHT        = 14,
    HUD_FORK_LEFT         = 15,
    HUD_MERGE_LEFT        = 16,
    HUD_MERGE_RIGHT       = 17,
    HUD_OFF_RAMP_LEFT     = 30,
    HUD_DESTINATION_LEFT  = 33,
    HUD_DESTINATION_RIGHT = 34,
    HUD_FLAG_LEFT         = 35,
    HUD_FLAG_RIGHT        = 36,
};

// Lookup: kTurnIcons[nav_event][side] where side is 0=LEFT, 1=RIGHT,
// 2=NONE/STRAIGHT. Indexed by NavEvent (0..19, sparse). A 0 entry -> blank.
// NAV_EV_ROUNDABOUT (13) is handled by roundabout_icon(). Copied verbatim from
// the reference headunit turns[][] table (validated on real cars).
constexpr uint8_t kTurnIcons[20][3] = {
    /*  0 UNKNOWN     */ {0, 0, 0},
    /*  1 DEPART      */ {HUD_FLAG_LEFT, HUD_FLAG_RIGHT, HUD_FLAG},
    /*  2 NAME_CHANGE */ {HUD_STRAIGHT, HUD_STRAIGHT, HUD_STRAIGHT},
    /*  3 SLIGHT      */ {HUD_SLIGHT_LEFT, HUD_SLIGHT_RIGHT, HUD_STRAIGHT},
    /*  4 TURN        */ {HUD_LEFT, HUD_RIGHT, HUD_STRAIGHT},
    /*  5 SHARP       */ {HUD_SHARP_LEFT, HUD_SHARP_RIGHT, HUD_STRAIGHT},
    /*  6 U_TURN      */ {HUD_U_TURN_LEFT, HUD_U_TURN_RIGHT, HUD_STRAIGHT},
    /*  7 ON_RAMP     */ {HUD_LEFT, HUD_RIGHT, HUD_STRAIGHT},
    /*  8 OFF_RAMP    */ {HUD_OFF_RAMP_LEFT, HUD_OFF_RAMP_RIGHT, HUD_STRAIGHT},
    /*  9 FORK        */ {HUD_FORK_LEFT, HUD_FORK_RIGHT, HUD_STRAIGHT},
    /* 10 MERGE       */ {HUD_MERGE_LEFT, HUD_MERGE_RIGHT, HUD_STRAIGHT},
    /* 11 (unused)    */ {0, 0, 0},
    /* 12 (unused)    */ {0, 0, 0},
    /* 13 ROUNDABOUT  */ {0, 0, 0},   // handled by roundabout_icon()
    /* 14 STRAIGHT    */ {HUD_STRAIGHT, HUD_STRAIGHT, HUD_STRAIGHT},
    /* 15 (unused)    */ {0, 0, 0},
    /* 16 FERRY       */ {0, 0, 0},
    /* 17 (unused)    */ {0, 0, 0},
    /* 18 (unused)    */ {0, 0, 0},
    /* 19 DEST        */ {HUD_DESTINATION_LEFT, HUD_DESTINATION_RIGHT, HUD_DESTINATION},
};

// Roundabout exit glyph: 12 directional glyphs per side, indexed by exit angle
// (nearest 30°). The ECU bank sector 0 (icon 37/49) points DOWN (entry leg) and
// runs counter-clockwise, whereas the exit bearing is 0=straight, +=right/CW —
// so feed d = 180 - bearing. Offsets 37 (RHT) and 49 (LHT) from the reference.
uint8_t roundabout_icon(int32_t degrees, int32_t side_index_lr)
{
    int32_t d = (180 - degrees) % 360;
    if (d < 0) d += 360;
    uint8_t nearest = static_cast<uint8_t>(((d + 15) / 30) % 12);
    uint8_t offset  = (side_index_lr == 0) ? 49 : 37;
    return static_cast<uint8_t>(nearest + offset);
}

// hu.proto DISPLAY_DISTANCE_UNIT -> Mazda HUD unit (1=m 2=mi 3=km 4=yd 5=ft).
uint8_t map_distance_unit(uint32_t nav_unit)
{
    switch (nav_unit) {
    case NAV_UNIT_METERS:       return 1;
    case NAV_UNIT_KILOMETERS10: return 3;
    case NAV_UNIT_KILOMETERS:   return 3;
    case NAV_UNIT_MILES10:      return 2;
    case NAV_UNIT_MILES:        return 2;
    case NAV_UNIT_FEET:         return 5;
    default:                    return 0;
    }
}

// Well-known name acquired on the service bus. A novel name avoids colliding
// with the real com.jci.vbs.navi service (we only send method calls to it).
constexpr const char *kBusName = "com.jci.vegvisir.nav";

// Shared snapshot (seqlock-protected).
struct NaviSnapshot {
    char     road_name[256];   // NUL-terminated UTF-8
    uint32_t turn_side;        // NavSide
    uint32_t turn_event;       // NavEvent
    int32_t  turn_angle;       // degrees, signed
    int32_t  turn_number;      // maneuver / exit number
    int32_t  distance_dec;     // value * 10 (one decimal place)
    uint8_t  distance_unit;    // ALREADY mapped to the Mazda enum
    int32_t  time_until;       // seconds
    NavLanes lanes;            // approach lanes at this maneuver (count 0 = none)
    // NOTE: the speed limit is NOT here. It is a SEPARATE path (HudSink::extSplim):
    // the sign has its own life — it can show with no active route and must survive
    // a routeActive(false) snapshot wipe — so it is not part of the maneuver frame.
};

// ===== The HUD sink =========================================================
//
// One instance (the hud:: functions at the bottom of this file), one producer:
// hudnav. No per-source views and no refcounted open — nobody to share with.
class HudSink {
public:
    void open();
    void close();
    void routeActive(bool on);
    void maneuver(const NavManeuver &m);
    void distance(const NavDistance &d);
    void speedLimit(int limitKmh);
    void lanes(const NavLanes &l);
    void clear();

private:
    // Sender-thread side. `laneWire` is the sender's memory of the lane glyphs the
    // cluster currently shows — the lane row is a separate OEM method with its own
    // change tracking, so it is threaded through instead of diffed from snapshots.
    void senderLoop();
    bool senderSetup();
    void senderTeardown();
    bool sendOne(const NaviSnapshot &cur, const NaviSnapshot &prev,
                 uint8_t &syncBit, uint8_t laneWire[kLaneSlots],
                 uint16_t splim, bool splimChanged, bool force);
    bool sendClear(uint8_t &syncBit, uint8_t laneWire[kLaneSlots]);
    void sendLaneRow(const uint8_t lane[kLaneSlots], uint8_t laneWire[kLaneSlots]);
    void keepaliveLoop();

    static void *senderTramp(void *self);
    static void *keepaliveTramp(void *self);

    // Producer-thread helpers.
    void seqlockBegin() { seq.fetch_add(1, std::memory_order_acq_rel); }
    void seqlockEnd()   { seq.fetch_add(1, std::memory_order_acq_rel); cv.notify_one(); }

    // OEM callbacks (static so their address is a plain C function pointer).
    static void dbusErrorCb(void *conn, void *closure);
    static void hudStatusCb(void *conn, unsigned char status, void *user);

    // --- shared state ---
    NaviSnapshot            snapshot = {};
    std::atomic<uint32_t>   seq{0};
    std::condition_variable cv;
    std::mutex              cvMu;
    std::atomic<bool>       stopReq{false};
    std::atomic<bool>       active{false};
    std::atomic<uint32_t>   keepaliveTick{0};
    std::atomic<bool>       haveGuidance{false};
    std::atomic<bool>       clearReq{false};
    static std::atomic<bool> hudAbsent;   // static: hudStatusCb needs to reach it

    void *conn = nullptr;

    pthread_t         senderThread = 0;
    std::atomic<bool> senderThreadUp{false};   // spawned by open(), joined by close()
    pthread_t         keepaliveThread = 0;
    bool              keepaliveUp = false;

    // Posted speed-limit sign (km/h; 0 = none). A SEPARATE path from the maneuver
    // snapshot — pushed by speedLimit(), re-polled by the sender every tick and
    // threaded into sendOne. Kept out of the seqlock frame so it survives a
    // routeActive(false) wipe and can show with no active route.
    std::atomic<uint16_t>   extSplim{0};

    // open()/close() may come from any thread; they serialise on this.
    std::mutex lifeMu;
};

std::atomic<bool> HudSink::hudAbsent{false};

// --- OEM callbacks ---------------------------------------------------------

void HudSink::dbusErrorCb(void *conn, void *closure)
{
    (void)conn; (void)closure;
    LOGW("hud sink: libjcidbus signalled a service-bus error "
         "(non-fatal; exit-on-disconnect is off)");
}

void HudSink::hudStatusCb(void *conn, unsigned char status, void *user)
{
    (void)conn; (void)user;
    const bool absent = (status == 0);
    hudAbsent.store(absent, std::memory_order_release);
    LOGD("hud sink: GetHUDStatus reply = %u (%s)",
         static_cast<unsigned>(status), absent ? "no HUD" : "HUD present");
}

// --- send logic ------------------------------------------------------------

// Push the lane row (a separate OEM method from the maneuver frame) and record
// what the cluster now shows. Never propagates failure: the lane arrows are a
// bonus, never a reason to report the maneuver frame as lost.
void HudSink::sendLaneRow(const uint8_t lane[kLaneSlots], uint8_t laneWire[kLaneSlots])
{
    const uint8_t *data = lane;
    uint32_t       cnt  = kLaneSlots;
    int rc = VBS_NAVI_SetRecommLaneReq(conn, &data, &cnt, nullptr, nullptr);
    if (rc != 0) {
        // Leave laneWire untouched so the next tick retries this row.
        LOGE("hud_send: SetRecommLaneReq failed rc=%d", rc);
        return;
    }
    LOGV("hud_send: SetRecommLaneReq [%u %u %u %u %u %u %u %u]",
         lane[0], lane[1], lane[2], lane[3], lane[4], lane[5], lane[6], lane[7]);
    std::memcpy(laneWire, lane, kLaneSlots);
}

bool HudSink::sendOne(const NaviSnapshot &cur, const NaviSnapshot &prev,
                      uint8_t &syncBit, uint8_t laneWire[kLaneSlots],
                      uint16_t splim, bool splimChanged, bool force)
{
    if (hudAbsent.load(std::memory_order_acquire)) return true;   // no HUD -> drain

    bool maneuver_changed = (std::strncmp(cur.road_name, prev.road_name,
                                          sizeof(cur.road_name)) != 0) ||
                            cur.turn_event  != prev.turn_event ||
                            cur.turn_side   != prev.turn_side  ||
                            cur.turn_number != prev.turn_number;
    bool distance_changed = maneuver_changed ||
                            cur.distance_dec  != prev.distance_dec  ||
                            cur.distance_unit != prev.distance_unit ||
                            cur.turn_angle    != prev.turn_angle;

    // The lane row is diffed on its ENCODED bytes, not on the NavLanes struct:
    // that is what the cluster actually shows, so two different lane lists that
    // resolve to the same glyphs cost no D-Bus traffic.
    uint8_t lane[kLaneSlots];
    hud_lane_encode(cur.lanes, lane);
    const bool lane_changed = std::memcmp(lane, laneWire, kLaneSlots) != 0;
    bool       lane_visible = false;
    for (int i = 0; i < kLaneSlots; ++i)
        if (lane[i] != kLaneHidden) { lane_visible = true; break; }

    // A speed-limit-only or lane-only change (same maneuver + distance) must still
    // trigger a send so that part repaints — both are threaded in separately from
    // the maneuver/distance diff above.
    if (!maneuver_changed && !distance_changed && !splimChanged && !lane_changed && !force)
        return true;   // nothing to send

    VbsNaviHudDisplay disp = {};
    VbsNaviHudMsg2    msg2 = {};
    std::string       road;   // owns the bytes msg2.guidancePointName points at

    // The native path sends Msg1 (SetHUDDisplayMsgReq) and Msg2
    // (SetHUD_Display_Msg2) as an inseparable pair on every guidance push, so we
    // couple them: build + send the street strip on the same condition as the
    // maneuver frame. Msg1's text_ID3 re-pages only on a maneuver change.
    if (maneuver_changed)
        syncBit = static_cast<uint8_t>((syncBit % 7) + 1);   // bump -> cluster re-pages

#if VEGVISIR_CLIENT_VN_NORMALIZE
    char hud_name[sizeof(cur.road_name)];
    normalize_vn(cur.road_name, hud_name, sizeof(hud_name));
    road = hud_name;
#else
    road = cur.road_name;
#endif
    // An empty road name makes the cluster ECU render uninitialised font memory
    // (garbage) in the street slot; a single space draws a clean blank instead.
    if (road.empty()) road = " ";
    msg2.guidancePointName = road.c_str();
    // Msg2 is sent PAIRED with Msg1 on every push (including the ~2 Hz keep-alive),
    // which is what keeps the strip from ageing out between turns; syncBit re-pages
    // only on a maneuver change (bumped above), matching the OEM native path.
    msg2.syncBit           = syncBit;

    uint32_t icon = 0;
    if (cur.turn_event == NAV_EV_ROUNDABOUT) {
        int32_t side_lr = (cur.turn_side == NAV_SIDE_LEFT) ? 0 : 1;
        icon = roundabout_icon(cur.turn_angle, side_lr);
    } else if (cur.turn_event < 20) {
        int32_t side_idx = static_cast<int32_t>(cur.turn_side) - 1;
        if (side_idx < 0 || side_idx > 2) side_idx = 2;
        icon = kTurnIcons[cur.turn_event][side_idx];
    }

    // Never wrap a far maneuver (>65535) to a tiny value; clamp to uint16.
    int32_t draw = cur.distance_dec;
    if (draw < 0)      draw = 0;
    if (draw > 0xFFFF) draw = 0xFFFF;
    disp.nextManeuverInfo  = icon;
    disp.distanceValue     = static_cast<uint16_t>(draw);
    disp.distanceUnit      = cur.distance_unit ? cur.distance_unit
                                               : static_cast<uint8_t>(1);
    // Posted speed limit (0 = none -> blank sign). Unit 1 = km/h. Threaded in
    // separately (not from the snapshot) so it repaints on its own cadence.
    disp.displaySpeedLimit = splim;
    disp.displaySpeedUnit  = splim ? static_cast<uint8_t>(1) : static_cast<uint8_t>(0);
    disp.text_ID3          = syncBit;

    LOGV("hud_send: SetHUDDisplayMsgReq icon=%u dist=%u unit=%u speed=%u sync=%u",
         static_cast<unsigned>(disp.nextManeuverInfo),
         static_cast<unsigned>(disp.distanceValue),
         static_cast<unsigned>(disp.distanceUnit),
         static_cast<unsigned>(disp.displaySpeedLimit),
         static_cast<unsigned>(disp.text_ID3));
    int rc = VBS_NAVI_SetHUDDisplayMsgReq(conn, &disp, nullptr, nullptr, nullptr);
    if (rc != 0) { LOGE("hud_send: SetHUDDisplayMsgReq failed rc=%d", rc); return false; }

    LOGV("hud_send: SetHUD_Display_Msg2 road=\"%s\" sync=%u",
         road.c_str(), static_cast<unsigned>(msg2.syncBit));
    rc = VBS_NAVI_TMC_SetHUD_Display_Msg2(conn, &msg2, nullptr, nullptr, nullptr);
    if (rc != 0) { LOGE("hud_send: SetHUD_Display_Msg2 failed rc=%d", rc); return false; }

    // The lane row goes out when its glyphs changed, and is re-asserted on the
    // keep-alive only while it is not blank: an all-hidden row has nothing to age
    // out, so re-sending it forever would be pure D-Bus traffic.
    if (lane_changed || (force && lane_visible)) sendLaneRow(lane, laneWire);
    return true;
}

// Push a blank maneuver frame + blank street strip + blank lane row to wipe the HUD.
bool HudSink::sendClear(uint8_t &syncBit, uint8_t laneWire[kLaneSlots])
{
    if (conn == nullptr) return false;
    if (hudAbsent.load(std::memory_order_acquire)) return true;

    VbsNaviHudDisplay disp = {};   // all-zero -> blank maneuver/distance
    int rc = VBS_NAVI_SetHUDDisplayMsgReq(conn, &disp, nullptr, nullptr, nullptr);
    if (rc != 0) { LOGE("hud_send: clear Msg1 failed rc=%d", rc); return false; }

    syncBit = static_cast<uint8_t>((syncBit % 7) + 1);
    VbsNaviHudMsg2 msg2 = {};
    const char    *blank = " ";
    msg2.guidancePointName = blank;
    msg2.syncBit           = syncBit;
    rc = VBS_NAVI_TMC_SetHUD_Display_Msg2(conn, &msg2, nullptr, nullptr, nullptr);
    if (rc != 0) { LOGE("hud_send: clear Msg2 failed rc=%d", rc); return false; }

    uint8_t  laneBlank[kLaneSlots];
    NavLanes none = {};
    hud_lane_encode(none, laneBlank);      // count 0 -> every slot hidden
    if (std::memcmp(laneBlank, laneWire, kLaneSlots) != 0)
        sendLaneRow(laneBlank, laneWire);

    LOGD("hud_send: HUD cleared (blank maneuver + street + lanes)");
    return true;
}

// --- sender-thread lifecycle -----------------------------------------------

bool HudSink::senderSetup()
{
    if (stopReq.load(std::memory_order_relaxed)) return false;

    conn = JCIDBUS_conn_create(reinterpret_cast<void *>(&HudSink::dbusErrorCb), 0);
    if (conn == nullptr) {
        LOGC("hud sink: JCIDBUS_conn_create failed (OEM symbols unavailable?)");
        return false;
    }

    LOGD("hud sink: connecting to service bus as %s", kBusName);
    if (JCIDBUS_conn_connect(conn, kBusName, kJciServiceBus, nullptr) == 0) {
        LOGE("hud sink: JCIDBUS_conn_connect failed — no HUD this session");
        JCIDBUS_conn_free(conn);
        conn = nullptr;
        return false;
    }

    JCIDBUS_worker_start(conn);
    LOGD("hud sink: service bus connected, worker started");

    if (stopReq.load(std::memory_order_relaxed)) return false;

    VBS_NAVI_GetHUDStatus(conn, reinterpret_cast<void *>(&HudSink::hudStatusCb), nullptr);
    LOGD("hud sink: HUD-status probe sent (sending enabled, fail-open)");
    return true;
}

void HudSink::senderTeardown()
{
    if (conn == nullptr) return;

    if (!hudAbsent.load(std::memory_order_acquire)) {
        VbsNaviHudDisplay clear = {};
        int rc = VBS_NAVI_SetHUDDisplayMsgReq(conn, &clear, nullptr, nullptr, nullptr);
        if (rc != 0) LOGE("hud sink: clear-frame send failed rc=%d", rc);
        else         LOGD("hud sink: sent HUD clear frame");

        // The lane row lives in a separate OEM frame, so a blank maneuver does not
        // blank it — say so explicitly or the arrows outlive the shim.
        uint8_t blank[kLaneSlots], sent[kLaneSlots];
        NavLanes none = {};
        hud_lane_encode(none, blank);
        std::memset(sent, 0xFE, sizeof(sent));   // force the send
        sendLaneRow(blank, sent);

        usleep(50 * 1000);   // let the worker flush before we stop it
    }

    JCIDBUS_worker_stop(conn);
    JCIDBUS_conn_disconnect(conn);
    JCIDBUS_conn_free(conn);
    conn = nullptr;
    LOGD("hud sink: worker stopped, connection freed");
}

// ~2Hz keep-alive: nudge the sender to re-assert the HUD frame even when the
// snapshot is static, so the cluster ECU does not age the maneuver out. Uses
// usleep() + a plain cv notify (NOT wait_for, whose std::chrono dependency needs
// a libstdc++ symbol the CMU lacks).
void HudSink::keepaliveLoop()
{
    while (!stopReq.load(std::memory_order_relaxed)) {
        usleep(500 * 1000);
        keepaliveTick.fetch_add(1, std::memory_order_relaxed);
        cv.notify_one();
    }
}

void *HudSink::keepaliveTramp(void *self)
{
    static_cast<HudSink *>(self)->keepaliveLoop();
    return nullptr;
}

void HudSink::senderLoop()
{
    if (!senderSetup()) {
        senderTeardown();
        LOGD("hud sink: setup did not complete; thread exiting");
        return;
    }
    active.store(true, std::memory_order_release);
    LOGD("hud sink: HUD plumbing ready (OEM transport)");

    if (pthread_create(&keepaliveThread, nullptr, &HudSink::keepaliveTramp, this) == 0) {
        keepaliveUp = true;
    } else {
        LOGC("hud sink: failed to spawn keep-alive ticker");
    }

    NaviSnapshot prev = {};
    uint8_t      syncBit = 0;
    uint32_t     lastProcessed = 0;
    uint32_t     lastTick = 0;
    uint16_t     prevSplim = 0;   // last speed limit painted, to detect a change
    // The lane glyphs the cluster shows. Seeded with something no encoding can
    // produce (0xFE) so the first row always goes out, even a blank one — the ECU
    // may have kept a lane row across a power cycle.
    uint8_t      laneWire[kLaneSlots];
    std::memset(laneWire, 0xFE, sizeof(laneWire));

    // Fresh bring-up with no active route: wipe any maneuver the cluster ECU
    // retained from a previous session / cold boot (we get no teardown across a
    // power cycle or source switch).
    if (!haveGuidance.load(std::memory_order_relaxed)) {
        if (sendClear(syncBit, laneWire))
            LOGD("hud sink: startup HUD clear (no active route)");
    }

    while (!stopReq.load(std::memory_order_relaxed)) {
      try {  // no exception may escape this thread (std::terminate -> SIGABRT)
        // Seqlock read: consistent iff seq is even before and after the copy and
        // both reads match. Retry on tear.
        NaviSnapshot snap;
        uint32_t s1, s2;
        for (;;) {
            s1 = seq.load(std::memory_order_acquire);
            if (s1 & 1u) { sched_yield(); continue; }
            std::memcpy(&snap, &snapshot, sizeof(snap));
            std::atomic_thread_fence(std::memory_order_acquire);
            s2 = seq.load(std::memory_order_relaxed);
            if (s1 == s2) break;
        }

        // Re-poll the speed limit every iteration (separate from the maneuver
        // snapshot). A change alone drives a send; a live limit keeps the keep-alive
        // re-asserting even with no active route so the sign has its own life.
        const uint16_t splim = extSplim.load(std::memory_order_relaxed);
        const bool splimChanged = (splim != prevSplim);

        if (s2 != lastProcessed || splimChanged) {
            sendOne(snap, prev, syncBit, laneWire, splim, splimChanged, /*force=*/false);
            prev = snap;
            prevSplim = splim;
            lastProcessed = s2;
        } else if (haveGuidance.load(std::memory_order_relaxed) || prevSplim != 0) {
            // Keep-alive woke us with no change -> re-assert the last frame so the
            // cluster ages out neither the maneuver NOR the speed-limit sign. Also
            // active when only a posted limit is present (no live route), so the
            // sign persists on its own.
            sendOne(prev, prev, syncBit, laneWire, splim,
                    /*splimChanged=*/false, /*force=*/true);
        }

        // Explicit wipe requested by hudnav (the link to the phone is gone).
        if (clearReq.exchange(false, std::memory_order_relaxed)) {
            LOGD("hud sink: clear requested -> HUD wipe");
            if (sendClear(syncBit, laneWire)) {
                haveGuidance.store(false, std::memory_order_relaxed);
                extSplim.store(0, std::memory_order_relaxed);
                prev          = {};
                prevSplim     = 0;
                lastProcessed = seq.load(std::memory_order_acquire);
            }
        }

        lastTick = keepaliveTick.load(std::memory_order_relaxed);
        std::unique_lock<std::mutex> lk(cvMu);
        cv.wait(lk, [&]() {
            return stopReq.load(std::memory_order_relaxed) ||
                   seq.load(std::memory_order_acquire) != lastProcessed ||
                   keepaliveTick.load(std::memory_order_relaxed) != lastTick ||
                   clearReq.load(std::memory_order_relaxed);
        });
      } catch (...) {
        LOGE("hud sink: sender loop exception swallowed — continuing");
        usleep(200 * 1000);
      }
    }

    active.store(false, std::memory_order_release);
    if (keepaliveUp) {
        pthread_join(keepaliveThread, nullptr);
        keepaliveUp     = false;
        keepaliveThread = 0;
    }
    senderTeardown();
    LOGD("hud sink: thread exiting cleanly");
}

void *HudSink::senderTramp(void *self)
{
    static_cast<HudSink *>(self)->senderLoop();
    return nullptr;
}

// --- the hud:: API, on the instance ------------------------------------------

void HudSink::open()
{
    // Idempotent, and silent + cheap once up: hudnav calls this on every frame.
    if (senderThreadUp.load(std::memory_order_acquire)) return;

    std::lock_guard<std::mutex> lk(lifeMu);
    if (senderThreadUp.load(std::memory_order_relaxed)) return;

    // Keep the caller cheap: spawn the sender thread and return. All D-Bus work
    // (connect, HUD-presence probe) happens on that thread.
    stopReq.store(false, std::memory_order_release);
    active.store(false, std::memory_order_release);

    if (pthread_create(&senderThread, nullptr, &HudSink::senderTramp, this) != 0) {
        LOGC("hud sink open: failed to spawn sender thread");
        return;
    }
    senderThreadUp.store(true, std::memory_order_release);
    LOGD("hud sink open: sender thread spawned (OEM D-Bus setup deferred)");
}

void HudSink::close()
{
    std::lock_guard<std::mutex> lk(lifeMu);
    if (!senderThreadUp.load(std::memory_order_relaxed)) return;

    stopReq.store(true, std::memory_order_release);
    haveGuidance.store(false, std::memory_order_relaxed);
    cv.notify_all();

    pthread_join(senderThread, nullptr);
    senderThreadUp.store(false, std::memory_order_release);
    senderThread = 0;
    active.store(false, std::memory_order_release);
    LOGD("hud sink close: sender thread stopped, OEM D-Bus released");
}

void HudSink::routeActive(bool on)
{
    if (!on) {
        haveGuidance.store(false, std::memory_order_relaxed);
        seqlockBegin();
        std::memset(&snapshot, 0, sizeof(snapshot));
        seqlockEnd();
    } else {
        haveGuidance.store(true, std::memory_order_relaxed);
        cv.notify_one();
    }
}

void HudSink::maneuver(const NavManeuver &m)
{
    seqlockBegin();
    // Smart UTF-8 truncation: never cut mid multi-byte sequence.
    const size_t max = sizeof(snapshot.road_name) - 1;
    size_t n = strnlen(m.road, max + 1);
    if (n > max) {
        n = max;
        while (n > 0 && (static_cast<unsigned char>(m.road[n]) & 0xC0) == 0x80) n--;
    }
    std::memcpy(snapshot.road_name, m.road, n);
    snapshot.road_name[n] = '\0';

    snapshot.turn_side   = m.side;
    snapshot.turn_event  = m.event;
    snapshot.turn_angle  = m.angle;
    snapshot.turn_number = m.number;
    seqlockEnd();
    haveGuidance.store(true, std::memory_order_relaxed);
}

void HudSink::distance(const NavDistance &d)
{
    seqlockBegin();
    snapshot.distance_dec  = d.displayDistance / 100;   // raw*1000 -> raw*10
    snapshot.distance_unit = map_distance_unit(d.displayUnit);
    snapshot.time_until    = d.timeUntilSeconds;
    seqlockEnd();
}

void HudSink::lanes(const NavLanes &l)
{
    seqlockBegin();
    std::memcpy(&snapshot.lanes, &l, sizeof(snapshot.lanes));
    // The row is drawn from `count` alone, so a bogus count is the one field that
    // could walk off the array — clamp it here, once, on the way in.
    if (snapshot.lanes.count < 0)            snapshot.lanes.count = 0;
    if (snapshot.lanes.count > NAV_LANE_MAX) snapshot.lanes.count = NAV_LANE_MAX;
    seqlockEnd();
}

void HudSink::speedLimit(int limitKmh)
{
    if (limitKmh < 0)      limitKmh = 0;
    if (limitKmh > 0xFFFF) limitKmh = 0xFFFF;
    // Separate path from the maneuver seqlock: store + wake the sender (a bumped
    // keepaliveTick satisfies the wait predicate) so the sign repaints promptly.
    extSplim.store(static_cast<uint16_t>(limitKmh), std::memory_order_relaxed);
    keepaliveTick.fetch_add(1, std::memory_order_relaxed);
    cv.notify_one();
}

void HudSink::clear()
{
    clearReq.store(true, std::memory_order_relaxed);
    cv.notify_one();
}

// The one sink behind the hud:: API. Function-local static, as v1.3 had it: built
// on first use (the first Navigation frame), not while the shared object loads.
HudSink &sink()
{
    static HudSink s;
    return s;
}

} // namespace

namespace hud {

void open()                          { sink().open(); }
void close()                         { sink().close(); }
void routeActive(bool active)        { sink().routeActive(active); }
void maneuver(const NavManeuver &m)  { sink().maneuver(m); }
void distance(const NavDistance &d)  { sink().distance(d); }
void lanes(const NavLanes &l)        { sink().lanes(l); }
void speedLimit(int limitKmh)        { sink().speedLimit(limitKmh); }
void clear()                         { sink().clear(); }

} // namespace hud
