// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Adapted from hudbridge-hud (mcu/src/lane), which ports the tables from
// VitaliyKurokhtin's oem-aa-mod hud_lane.h. AGPL-3.0 — see NOTICE.md.
//
// Lane-row translation: NavLanes (core/nav_types.h) -> the cluster's lane glyph
// bytes. The bytes go out through a different OEM method from the maneuver block
// (VBS_NAVI_SetRecommLaneReq, an (ay) byte array), which HudSink sends on its own
// connection alongside the maneuver frame.
//
// Split out from hud_sink.cpp because it is pure table lookup with no state and
// no transport: the direction-bitmask -> OEM lane code -> cluster glyph chain is
// three reverse-engineered tables and nothing else, which makes it the one piece
// of the HUD path that can be checked by reading it.

#ifndef VEGVISIR_CLIENT_HUD_LANE_H
#define VEGVISIR_CLIENT_HUD_LANE_H

#include "core/nav_types.h"

// Lane slots the cluster draws, and the code for "this slot shows nothing".
// A cluster property, deliberately separate from NAV_LANE_MAX (a model capacity)
// even though both are 8 today.
enum { kLaneSlots = 8 };
const uint8_t kLaneHidden = 0xFF;

// Fill `out` with one glyph code per lane slot: the lanes of `in` left to right,
// every remaining slot kLaneHidden. Lanes past kLaneSlots are dropped. Total,
// never fails — `in.count == 0` yields an all-hidden (blank) row.
void hud_lane_encode(const NavLanes &in, uint8_t out[kLaneSlots]);

// The glyph one lane on its own resolves to. Exposed for inspection/testing.
uint8_t hud_lane_glyph(const NavLane &lane);

#endif // VEGVISIR_CLIENT_HUD_LANE_H
