// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Adapted from headunit (https://github.com/Trevelopment/headunit),
// licensed under GNU AGPL v3. See NOTICE.md for the full attribution.
//
// The HUD output sink: the one place that draws on the Mazda instrument-cluster
// "Active Driving Display". hudnav (hudnav/hudnav.cpp) decodes the server's
// Navigation JSON into NavManeuver / NavDistance / NavLanes and pushes them in
// here; the sink turns them into OEM com.jci.vbs.navi D-Bus frames (via
// core/oem/, not dbus-c++): the maneuver icon, the distance readout, the
// road-name strip, the posted speed-limit sign (0 = blank) and the lane row.
//
// One process-wide sink behind plain functions — this service has exactly one
// producer, so there is no interface to implement and no handle to obtain.
//
// Threading: every call below is safe from any thread and never blocks on the
// bus — the setters write a seqlock-protected snapshot and wake the sender
// thread, which owns the OEM D-Bus connection. open()/close() are idempotent;
// open() only spawns that thread, all D-Bus work happens on it.

#ifndef VEGVISIR_CLIENT_HUD_SINK_H
#define VEGVISIR_CLIENT_HUD_SINK_H

#include "core/nav_types.h"

namespace hud {

// Bring the output pipeline up (sender thread + OEM D-Bus + ~2 Hz keep-alive) /
// tear it down (clear frame, stop the thread, release the bus). Call open() when
// navigation first arrives, not at load, so no bus connection is made with no
// phone present; once up it is an atomic check, cheap enough for every frame.
void open();
void close();

// Route became active (true) or ended (false: blanks the maneuver frame + lanes).
void routeActive(bool active);

// The next maneuver to display changed (icon + road strip).
void maneuver(const NavManeuver &m);

// The distance readout changed.
void distance(const NavDistance &d);

// The lane row for the next maneuver changed. `count == 0` blanks the row — push
// that (not nothing) when a maneuver carries no lane data, otherwise the previous
// maneuver's lanes stay on the glass.
void lanes(const NavLanes &l);

// The posted speed limit changed, km/h; 0 = none posted (the sign is blanked).
void speedLimit(int limitKmh);

// Wipe the HUD (maneuver, street strip, lanes and the speed-limit sign) — for a
// source that is gone (phone unplugged, link lost) and cannot send "route ended".
void clear();

} // namespace hud

#endif // VEGVISIR_CLIENT_HUD_SINK_H
