// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Navigation -> HUD bridge for Mazda Connect (CMU150).
//
// hudnav: turn-by-turn pulled from the phone-side vegvisir server over the TCP
// socket (core/net/), decoded from the Navigation JSON body and drawn on the
// cluster HUD (hud/hud_sink.h) — directly. This service has exactly one
// navigation source, so there is no provider abstraction in between: hudnav
// calls hud::maneuver() and friends itself.
//
// start() registers the handler for the router's Navigation messages and
// listens to the socket's link state, so a phone unplugged mid-route wipes the
// HUD instead of leaving the last arrow on the glass. The socket client itself
// is core infrastructure (core/net/socket_client.h); hudnav owns only the
// Navigation message type.
//
// (vegvisir-client v1.3 carried an iAP2/CarPlay source next to hudnav, behind
// NavProvider/NavSink interfaces and a registry that started whichever applied.
// That source lived on interposed libc calls inside jciCARPLAY and has no place
// in a standalone service — and with one source left, neither had the layer.)

#ifndef VEGVISIR_CLIENT_HUDNAV_H
#define VEGVISIR_CLIENT_HUDNAV_H

namespace hudnav {

// Hook into the socket (Navigation handler + link callback). Call once at load;
// the HUD comes up lazily, on the first Navigation message.
void start();

// Unhook and release the HUD.
void stop();

} // namespace hudnav

#endif // VEGVISIR_CLIENT_HUDNAV_H
