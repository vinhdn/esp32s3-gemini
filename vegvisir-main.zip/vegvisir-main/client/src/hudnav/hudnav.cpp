// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Navigation -> HUD bridge for Mazda Connect (CMU150).
//
// hudnav — the Navigation JSON from the phone-side server, decoded and pushed
// straight into the HUD sink (hud/hud_sink.h).
//
// === Navigation JSON body (the wire contract with the server) ==============
//
// The Navigation message body is a flat JSON object. This is the schema this
// consumer expects and the server must produce (unchanged from v1.3):
//
//   {
//     "active":   true,        // false = guidance ended (blank the maneuver)
//     "event":    4,           // NavEvent (turn kind): 4=turn, 13=roundabout, ...
//     "side":     1,           // NavSide: 1=left, 2=right, 3=none/straight
//     "angle":    0,           // roundabout exit bearing, degrees (0 otherwise)
//     "number":   0,           // roundabout exit number 1..19 (0 otherwise)
//     "road":     "Nguyễn Huệ",// road the maneuver leads onto (UTF-8)
//     "distance": 1400,        // metres to the maneuver
//     "unit":     3,           // NavDistanceUnit (optional; auto if absent)
//     "eta":      0,           // seconds to the maneuver (optional)
//     "speedLimit": 60,        // posted speed limit km/h (optional; 0 = none)
//     "lanes": [               // approach lanes, left to right (optional; the only
//                              // nested field — max 8, extras dropped)
//       { "angles": [0, -90],  //   directions this lane allows, degrees:
//                              //   0 = straight, negative = left, positive = right
//         "highlight": -90,    //   the one the route takes (optional; omit = none)
//         "recommended": true  //   is this a lane to be in? (optional; false)
//       }
//     ]
//   }
//
// Every message is a FULL snapshot: a missing "lanes" (or "speedLimit") means "none
// now", not "unchanged", so the row is blanked rather than left showing the previous
// maneuver's lanes.
//
// Everything is validated / range-checked before it crosses into the HUD sink —
// the socket accepts whatever is on the link, so this is a trust boundary.

#define LOG_TAG "HUDNAV"
#include "core/log.h"
#include "core/net/message_router.h"
#include "core/net/json_lite.h"
#include "core/net/socket_client.h"
#include "core/nav_types.h"
#include "hud/hud_sink.h"
#include "hudnav/hudnav.h"

#include <atomic>
#include <string.h>

namespace {

std::atomic<bool> g_on_glass(false);   // a route from the phone is showing on the HUD

uint32_t safe_event(long v)
{
    switch (v) {
    case NAV_EV_DEPART: case NAV_EV_NAME_CHANGE: case NAV_EV_SLIGHT:
    case NAV_EV_TURN: case NAV_EV_SHARP: case NAV_EV_UTURN:
    case NAV_EV_ON_RAMP: case NAV_EV_OFF_RAMP: case NAV_EV_FORK:
    case NAV_EV_MERGE: case NAV_EV_ROUNDABOUT: case NAV_EV_STRAIGHT:
    case NAV_EV_FERRY: case NAV_EV_DEST:
        return (uint32_t)v;
    default:
        return NAV_EV_STRAIGHT;
    }
}

uint32_t safe_side(long v)
{
    return (v >= (long)NAV_SIDE_LEFT && v <= (long)NAV_SIDE_NONE) ? (uint32_t)v : NAV_SIDE_NONE;
}

// Build a NavDistance from a metre count, matching the display convention the
// HUD sink expects (displayDistance = value-in-unit * 1000).
NavDistance make_distance(long metres, long unit, long eta)
{
    NavDistance d{};
    d.meters           = (int32_t)metres;
    d.timeUntilSeconds = (int32_t)eta;
    if (unit == NAV_UNIT_KILOMETERS || (unit <= 0 && metres >= 1000)) {
        d.displayUnit     = NAV_UNIT_KILOMETERS;
        d.displayDistance = (int32_t)metres;          // /100 -> tenths of km
    } else {
        d.displayUnit     = NAV_UNIT_METERS;
        d.displayDistance = (int32_t)(metres * 1000); // /100 -> tenths of metre
    }
    return d;
}

// Decode the "lanes" array into a NavLanes. Absent / malformed / empty all give
// count 0, which blanks the lane row — the safe reading in every one of those cases.
NavLanes parse_lanes(const std::string &body)
{
    NavLanes out = {};

    std::vector<std::string> elems;
    if (!json::getArray(body, "lanes", &elems, NAV_LANE_MAX)) return out;

    for (size_t i = 0; i < elems.size() && out.count < NAV_LANE_MAX; ++i) {
        const std::string &e = elems[i];

        long   angles[NAV_LANE_ANGLES_MAX];
        size_t n = 0;
        if (!json::getIntArray(e, "angles", angles, NAV_LANE_ANGLES_MAX, &n) || n == 0)
            continue;   // a lane with no direction at all has nothing to draw

        NavLane &lane = out.lanes[out.count];
        lane.angleCount = 0;
        for (size_t k = 0; k < n; ++k) {
            long a = angles[k];
            if (a < -180 || a > 180) continue;   // not a bearing; ignore this one
            lane.angles[lane.angleCount++] = (int32_t)a;
        }
        if (lane.angleCount == 0) continue;

        long hl = 0;
        lane.highlight = (json::getInt(e, "highlight", &hl) && hl >= -180 && hl <= 180)
                             ? (int32_t)hl : NAV_LANE_NO_HIGHLIGHT;

        bool rec = false;
        json::getBool(e, "recommended", &rec);
        lane.recommended = rec ? 1 : 0;

        out.count++;
    }
    return out;
}

// Decode one Navigation JSON body and push the result into the HUD sink.
void handle_navigation(const net::Envelope &env)
{
    // Bring the HUD pipeline up lazily — only once real navigation arrives.
    // Idempotent and, once up, an atomic check.
    hud::open();

    std::string body(env.body.begin(), env.body.end());

    bool active = true;
    json::getBool(body, "active", &active);
    if (!active) {
        LOGD("nav: active=false -> guidance off");
        g_on_glass.store(false, std::memory_order_relaxed);
        hud::routeActive(false);
        return;
    }

    long event = NAV_EV_STRAIGHT, side = NAV_SIDE_NONE, angle = 0, number = 0;
    json::getInt(body, "event",  &event);
    json::getInt(body, "side",   &side);
    json::getInt(body, "angle",  &angle);
    json::getInt(body, "number", &number);

    NavManeuver m{};
    m.event  = safe_event(event);
    m.side   = safe_side(side);
    m.angle  = (int32_t)angle;
    m.number = (number >= 0 && number <= 19) ? (int32_t)number : 0;
    json::getString(body, "road", m.road, sizeof(m.road));

    LOGV("nav: event=%u side=%u angle=%d number=%d road=\"%s\"",
         m.event, m.side, m.angle, m.number, m.road);
    if (!g_on_glass.exchange(true, std::memory_order_relaxed))
        LOGD("nav: guidance on -> HUD");
    hud::routeActive(true);
    hud::maneuver(m);

    // Lane row. Pushed on every frame, including the empty one, because each
    // Navigation is a full snapshot (see the schema note above).
    NavLanes lanes = parse_lanes(body);
    LOGV("nav: lanes=%d", lanes.count);
    hud::lanes(lanes);

    long metres = -1, unit = 0, eta = 0;
    if (json::getInt(body, "distance", &metres) && metres >= 0) {
        json::getInt(body, "unit", &unit);
        json::getInt(body, "eta",  &eta);
        NavDistance d = make_distance(metres, unit, eta);
        hud::distance(d);
    }

    // Posted speed limit (km/h). Each Navigation is a full snapshot, so a missing
    // key means "no limit" — push 0 to blank the sign.
    long speed = 0;
    json::getInt(body, "speedLimit", &speed);
    hud::speedLimit(speed < 0 ? 0 : (int)speed);
}

// The socket came up or went down. A route still on the glass when the link
// dies (phone unplugged mid-guidance, app killed) would otherwise stay there
// forever — the server is not around to send active:false — so wipe it.
void handle_link(bool up, const char *why)
{
    if (up) return;
    if (g_on_glass.exchange(false, std::memory_order_relaxed)) {
        LOGD("nav: link down (%s) with guidance on the glass -> HUD clear", why);
        hud::clear();
    }
}

} // namespace

namespace hudnav {

void start()
{
    net::routerRegister(net::MessageType::Navigation, &handle_navigation);
    net::clientSetLinkCallback(&handle_link);
    LOGD("hudnav started; awaiting Navigation messages from the server");
}

void stop()
{
    net::clientSetLinkCallback(nullptr);
    hud::close();
    LOGD("hudnav stopped");
}

} // namespace hudnav
