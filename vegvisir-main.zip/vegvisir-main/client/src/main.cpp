// SPDX-License-Identifier: AGPL-3.0-or-later
// Author: rongcondihoc
//
// vegvisir-client v2 — the composition root.
//
// A standalone Mazda Connect (JCI) service that puts phone navigation on the
// instrument-cluster HUD:
//
//   phone plugged in (USB ethernet, usb0)
//     -> core/net   finds the phone in the unit's own routing table (the IPv6
//                   next hop out of usb0 — core/net/peer_discovery.h), dials its
//                   vegvisir server on port 15985 (VEG1), redials when it moves
//     -> hudnav/    decodes each Navigation JSON into maneuver/distance/lanes
//     -> hud/       renders it on the cluster HUD over the OEM com.jci.vbs.navi D-Bus
//
//   core/usb        diagnostics only: logs the USB link's interface / lease /
//                   gateway timeline from rtnetlink, so the log shows WHY
//                   discovery did or did not find a peer. Nothing depends on it.
//
// Discovery + socket client are the v1.3 mechanism, cloned: the client thread
// polls the routing table itself and needs no netlink/sysfs detection of the
// link to connect.
//
// hudnav is the only navigation source in this build (no iAP2/CarPlay tap), so
// it drives the HUD sink directly — there is no provider layer.
//
// HOW THIS RUNS
//
// This is a plain executable, registered in sm.conf as
// <service type="process" name="vegvisir-client" path="/data_persist/vegvisir-client/vegvisir-client">
// (the same way the community hudd daemon and the OEM stage_*.sh scripts run):
// sm fork/execs it at boot and sends SIGTERM to stop it. main() starts the
// worker threads (socket client, USB watcher, HUD sender) and then parks in
// pause() — the process is the service. No LD_PRELOAD host binary, no
// sm_svclauncher/GetServiceInterfaces ABI, no sm pings (type="process"
// services are not pinged).

#define LOG_TAG "CORE"
#include "core/log.h"
#include "core/net/socket_client.h"
#include "core/usb/usb_net_watch.h"
#include "hudnav/hudnav.h"

#include <cstdlib>
#include <sys/syscall.h>
#include <sys/types.h>
#include <unistd.h>

// Log sink shared by every TU (core/log.h). The service has no terminal and sm
// swallows stderr, so log to a file — on /data_persist (the module's own dir,
// created by install.sh) because /tmp is wiped on every boot, losing exactly the
// boot-time diagnostics we most want. Append so boots accumulate.
std::FILE *g_logf = nullptr;

namespace {

const char *kLogPath = "/data_persist/vegvisir-client/client.log";

pid_t gettid_compat()
{
#ifdef SYS_gettid
    return (pid_t)syscall(SYS_gettid);
#else
    return -1;
#endif
}

} // namespace

int main(int, char **)
{
    g_logf = std::fopen(kLogPath, "ae");
    if (g_logf) std::setvbuf(g_logf, nullptr, _IOLBF, 0);   // line-buffered: `tail -f` sees lines live

    LOGD("=== vegvisir-client v2 started pid=%d tid=%d ppid=%d (usb0 route -> socket 15985 -> hudnav -> HUD) ===",
         (int)getpid(), (int)gettid_compat(), (int)getppid());

    // Navigation from the phone -> HUD. The HUD sink brings the OEM D-Bus up
    // lazily, on the first Navigation message.
    hudnav::start();

    // The v1.3 mechanism: the client discovers the phone itself (VEGVISIR_IFACE,
    // default usb0; VEGVISIR_PEER pins an address) and dials/redials on its own
    // thread. Nothing has to hand it an address.
    net::clientStart();

    // Diagnostics: the rtnetlink watcher narrates the link to the log ("usb0
    // (idx 5): up ip=… gw4=… gw6=…", "removed — cable out"). No listener — the
    // client does not wait for it, so losing it costs only log lines.
    if (!usbnet::watchStart(nullptr, std::getenv("VEGVISIR_IFACE")))
        LOGW("USB watcher unavailable — link diagnostics off (discovery is unaffected)");

    LOGD("service up; looking for the phone on the USB link");
    for (;;)
        pause();   // wake only on a signal (sm sends SIGTERM to stop us; default action exits)
    return 0;      // not reached
}
