#!/bin/sh
# ============================================================================
#  macOS build helper for the JCI client service.
#
#  The bundled m3-toolchain ARM cross-compiler is a Linux x86-64 ELF binary and
#  cannot run on macOS. This script builds (once) a small Linux x86-64 Docker
#  image with make, copies the whole project (sources + bundled ./m3-toolchain)
#  into a fresh container, runs the normal ./build.sh inside it, copies the
#  artifacts back out, and removes the container.
#
#  The image is KEPT between runs: rebuilding it means `apt-get` under amd64
#  emulation, which takes many minutes. `./macos-build.sh clean` removes it.
#
#  It uses `docker cp` (not a bind mount), so it does not depend on how the
#  Docker backend shares the host filesystem (Docker Desktop, Colima, Rancher,
#  a remote daemon all behave the same).
#
#  Artifacts land exactly where a native Linux build would:
#    build/<target>/vegvisir-client      (+ deploy/vegvisir-client and
#                                          deploy/versions/ for every target)
#  Only the built files come back — deploy/*.sh and module.conf on the host are
#  never overwritten by the container's copies.
#
#  Usage (same arguments as build.sh):
#    ./macos-build.sh            # release
#    ./macos-build.sh debug
#    ./macos-build.sh clean      # local: build.sh clean + remove the cached image
#
#  Needs the Docker CLI; starts Colima if no daemon runs (and stops it again
#  only if this script started it). On Apple Silicon the amd64 image runs under
#  emulation.
# ============================================================================
set -eu

SELF_DIR=$(cd "$(dirname "$0")" && pwd)
TARGET="${1:-release}"

TRIPLE="arm-cortexa9_neon-linux-gnueabi"
TC_G="$SELF_DIR/m3-toolchain/bin/$TRIPLE-g++"

IMAGE="client-build:m3"
CID=""
COLIMA_STARTED=0

# --- preflight ---------------------------------------------------------------
if ! command -v docker >/dev/null 2>&1; then
  echo "[macos-build] Docker CLI not found. Install Docker (or Colima) and retry." >&2
  echo "              e.g.  brew install colima docker" >&2
  exit 1
fi

# --- clean: purely local, no container needed --------------------------------
# (Running build.sh clean INSIDE a container would only clean the copy.)
if [ "$TARGET" = "clean" ]; then
  sh "$SELF_DIR/build.sh" clean
  if docker info >/dev/null 2>&1; then
    docker image rm -f "$IMAGE" >/dev/null 2>&1 && echo "[macos-build] removed cached image ($IMAGE)." || true
  else
    echo "[macos-build] no Docker daemon running — cached image ($IMAGE), if any, left in place."
  fi
  exit 0
fi

[ -x "$TC_G" ] || { echo "[macos-build] bundled ARM cross-compiler not found: $TC_G" >&2; exit 1; }

# --- always tear the container down on the way out ---------------------------
# The image stays (see header). Colima is only stopped if THIS script started it.
cleanup() {
  [ -n "$CID" ] && docker rm -f "$CID" >/dev/null 2>&1 || true
  if [ "$COLIMA_STARTED" = "1" ]; then
    echo "[macos-build] stopping Colima (this script started it)…"
    colima stop >/dev/null 2>&1 || true
  fi
}
trap cleanup EXIT INT TERM

# --- ensure a Docker daemon is available -------------------------------------
if ! docker info >/dev/null 2>&1; then
  if ! command -v colima >/dev/null 2>&1; then
    echo "[macos-build] No Docker daemon and Colima is not installed." >&2
    echo "              Start Docker Desktop, or install Colima (brew install colima)." >&2
    exit 1
  fi
  echo "[macos-build] no Docker daemon — starting Colima…"
  colima start
  COLIMA_STARTED=1
  docker info >/dev/null 2>&1 || { echo "[macos-build] Colima started but Docker is unreachable." >&2; exit 1; }
fi

# --- build image (cached: instant when it already exists) --------------------
# make + gawk for build.sh/Makefile; the compiler and binutils (readelf) come
# from the bundled toolchain copied in below.
echo "[macos-build] preparing Linux x86-64 build image ($IMAGE)…"
docker build --platform linux/amd64 -t "$IMAGE" - >/dev/null <<'DOCKERFILE'
FROM --platform=linux/amd64 debian:11-slim
RUN apt-get update \
 && apt-get install -y --no-install-recommends make findutils gawk \
 && rm -rf /var/lib/apt/lists/*
WORKDIR /src
DOCKERFILE

# --- create the container that runs the build --------------------------------
# BUILD_STAMP: the container clock is UTC; stamp the versions/ backup with the
# host's local time instead.
CID=$(docker create --platform linux/amd64 -w /src \
        -e BUILD_STAMP="$(date +%Y%m%d-%H%M)" \
        "$IMAGE" sh build.sh "$TARGET")

# --- copy the project into the container (sources + bundled toolchain) --------
# The ~420 MB toolchain is the bulk of the copy; previous build outputs and the
# staged binaries are skipped. The --no-* flags strip macOS extended attributes
# that docker cp cannot re-apply on the Linux side.
echo "[macos-build] copying project into the container (bundled toolchain is large, please wait)…"
tar -C "$SELF_DIR" --no-mac-metadata --no-xattrs --no-acls --no-fflags \
    --exclude './build' --exclude './deploy/vegvisir-client' --exclude './deploy/*.so' \
    --exclude './deploy/versions' --exclude '*.DS_Store' \
    -cf - . | docker cp - "$CID:/src"

# --- run the build -----------------------------------------------------------
echo "[macos-build] building target '$TARGET' inside the container…"
docker start -a "$CID"

# --- copy artifacts back (built files only, never the deploy/ scripts) -------
echo "[macos-build] copying artifacts back to the repo…"
mkdir -p "$SELF_DIR/build" "$SELF_DIR/deploy/versions"
docker cp "$CID:/src/build/." "$SELF_DIR/build/"
docker cp "$CID:/src/deploy/vegvisir-client" "$SELF_DIR/deploy/vegvisir-client"
docker cp "$CID:/src/deploy/versions/." "$SELF_DIR/deploy/versions/"
# The .d dependency files name headers by their container path (/src/...); on
# the host they would make every later `make` fail with "No rule to make target
# /src/m3-toolchain/...". They are regenerated on the next compile anyway.
find "$SELF_DIR/build" -name '*.d' -delete 2>/dev/null || true

echo "[macos-build] done. Artifacts are in build/ and deploy/."
