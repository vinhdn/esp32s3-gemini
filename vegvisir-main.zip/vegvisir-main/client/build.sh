#!/bin/sh
# ============================================================================
#  Build the JCI client service and stage a ready-to-copy deploy/ bundle.
#
#  Runs `make`, checks the linked binary against the CMU's runtime (symbol
#  versions), then places the freshly built executable:
#    - deploy/vegvisir-client                             (the file the unit runs)
#    - deploy/versions/vegvisir-client-<YYYYMMDD-HHMM>     (timestamped backup)
#
#  The Mazda CMU is ARM, so this cross-compiles with the m3-toolchain (a Linux
#  x86-64 ELF binary): run this on a Linux x86-64 host. On macOS use
#  ./macos-build.sh, which runs this same script inside a Docker container.
#
#  Uses the bundled ./m3-toolchain by default (no external dependency);
#  M3TOOLCHAIN may be set in the environment to point at a different one.
#  BUILD_STAMP (YYYYMMDD-HHMM) overrides the backup timestamp — macos-build.sh
#  passes the host's local time, since the container clock is UTC.
#
#  Usage:
#    ./build.sh            # release build -> deploy/
#    ./build.sh debug      # debug build (verbose, unstripped) -> deploy/
#    ./build.sh clean      # remove build/, the deploy/ binary and deploy/versions/
# ============================================================================
set -eu

SELF_DIR=$(cd "$(dirname "$0")" && pwd)
DEPLOY_DIR="$SELF_DIR/deploy"
VERSIONS_DIR="$DEPLOY_DIR/versions"
OUT="vegvisir-client"
TRIPLE="arm-cortexa9_neon-linux-gnueabi"

TARGET="${1:-release}"

if [ "$TARGET" = "clean" ]; then
  make -C "$SELF_DIR" clean
  # deploy/ holds the tracked scripts — only drop the built executable (and any
  # .so left over from the earlier shared-object build).
  rm -f "$DEPLOY_DIR/$OUT" "$DEPLOY_DIR"/vegvisir-client*.so
  # versions/ holds only build backups — remove it entirely.
  rm -rf "$VERSIONS_DIR"
  echo "[build] cleaned (build/ removed; deploy/ executable and versions/ cleared)."
  exit 0
fi

# --- preflight: the ARM cross-compiler must be present -----------------------
# Ask make where the toolchain resolves to (honours M3TOOLCHAIN from the env).
# -q with -p prints the database WITHOUT remaking anything (plain -p would run
# the default build here, silently, and hide every compiler warning). Fall back
# to the bundled default if make could not tell us.
CXX_PATH=$(make -C "$SELF_DIR" -s -qp 2>/dev/null | awk -F' := ' '/^CXX :=/{print $2; exit}')
[ -n "$CXX_PATH" ] || CXX_PATH="${M3TOOLCHAIN:-m3-toolchain}/bin/$TRIPLE-g++"
# Relative paths in the Makefile are relative to SELF_DIR (make -C), not to our cwd.
case "$CXX_PATH" in /*) ;; *) CXX_PATH="$SELF_DIR/$CXX_PATH" ;; esac
if [ ! -x "$CXX_PATH" ]; then
  echo "[build] ERROR: ARM cross-compiler not found: $CXX_PATH" >&2
  echo "               Point M3TOOLCHAIN at your m3-toolchain checkout, e.g.:" >&2
  echo "               M3TOOLCHAIN=/path/to/m3-toolchain ./build.sh $TARGET" >&2
  exit 1
fi
TC_BIN=$(dirname "$CXX_PATH")

# --- build -------------------------------------------------------------------
make -C "$SELF_DIR" "$TARGET"
ARTIFACT="$SELF_DIR/build/$TARGET/$OUT"
[ -f "$ARTIFACT" ] || { echo "[build] ERROR: expected artifact missing: $ARTIFACT" >&2; exit 1; }
echo "[build] done -> $ARTIFACT"

# --- runtime compatibility check ----------------------------------------------
# The CMU ships libstdc++.so.6.0.14 (newest symbol version GLIBCXX_3.4.14,
# CXXABI_1.3.4 / CXXABI_ARM_1.3.3) and glibc 2.11. Our GCC 4.9.1 toolchain is
# happy to emit references to newer versions (e.g. std::__throw_out_of_range_fmt
# @GLIBCXX_3.4.20 — see src/core/glibcxx_compat.cpp), and the loader on the unit
# then refuses to start the binary. Catch that here, with the toolchain's own
# readelf, instead of on the car.
READELF="$TC_BIN/$TRIPLE-readelf"
if [ -x "$READELF" ]; then
  VERS=$("$READELF" -V "$ARTIFACT" 2>/dev/null \
         | grep -oE 'GLIBCXX_3\.4\.[0-9]+|GLIBC_2\.[0-9]+|CXXABI_[A-Z_]*[0-9.]+' | sort -u)
  BAD=$(printf '%s\n' "$VERS" | awk -F'[_.]' '
          # fields: $1 = name; GLIBCXX_3.4.N -> $4 = N; GLIBC_2.N -> $3 = N;
          #         CXXABI_1.3.N -> $2.$3.$4; CXXABI_ARM_1.3.N -> $3.$4.$5
          /^GLIBCXX_/    { if ($4+0 > 14) print; next }
          /^GLIBC_/      { if ($3+0 > 11) print; next }
          /^CXXABI_ARM_/ { if ($3+0 > 1 || $4+0 > 3 || $5+0 > 3) print; next }
          /^CXXABI_/     { if ($2+0 > 1 || $3+0 > 3 || $4+0 > 4) print; next }')
  if [ -n "$BAD" ]; then
    echo "[build] ERROR: $OUT needs symbol versions the CMU runtime lacks:" >&2
    echo "$BAD" | sed 's/^/               /' >&2
    echo "               (device: GLIBCXX <= 3.4.14, GLIBC <= 2.11, CXXABI <= 1.3.4 / ARM_1.3.3)" >&2
    echo "               Find the symbol with: $READELF --dyn-syms $ARTIFACT | grep <version>" >&2
    echo "               and shim or avoid it (see src/core/glibcxx_compat.cpp); do NOT use -static-libstdc++." >&2
    exit 1
  fi
  MAXCXX=$(printf '%s\n' "$VERS" | grep -E '^GLIBCXX_3\.4\.[0-9]+$' | sort -t. -k3 -n | tail -1)
  echo "[build] runtime check OK: needs ${MAXCXX:-no versioned GLIBCXX} (device has GLIBCXX_3.4.14)"
else
  echo "[build] WARNING: $READELF not found — skipped the runtime symbol-version check" >&2
fi

# --- place the build ---------------------------------------------------------
# deploy/ (with install.sh + uninstall.sh) gets the shipping executable; the
# timestamped backup of this build goes into versions/.
mkdir -p "$DEPLOY_DIR" "$VERSIONS_DIR"
STAMP="${BUILD_STAMP:-$(date +%Y%m%d-%H%M)}"
BACKUP="vegvisir-client-$STAMP"

cp -f "$ARTIFACT" "$DEPLOY_DIR/$OUT"
cp -f "$ARTIFACT" "$VERSIONS_DIR/$BACKUP"

echo "[build] staged  -> $DEPLOY_DIR/$OUT"
echo "[build] backup  -> $VERSIONS_DIR/$BACKUP"
echo "[build] bundle ready: deploy/ ($OUT + install.sh + uninstall.sh + module.conf)"
