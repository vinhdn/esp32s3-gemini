#!/bin/sh
# SPDX-License-Identifier: AGPL-3.0-or-later
# ============================================================================
#  Functional test of the service without a car: everything except the OEM HUD.
#
#  Stands up a throwaway Linux container (native arch, CAP_NET_ADMIN), builds
#  src/ with the container's g++ into the vegvisir-client executable, runs it the
#  way sm does (plain exec), and plays the phone with a veth pair + a Python
#  VEG1 server:
#
#    veth0  = the CMU's USB interface (pinned via VEGVISIR_IFACE)
#    veth1  = the phone: fe80::1 (IPv6 router = what the client dials, v1.3
#             discovery) + 172.20.10.1 (IPv4 gateway, diagnostics only)
#
#  Phases: plug in (addresses, then the IPv6 default route via fe80::1) ->
#  re-tether (phone returns as fe80::2, no FIN) -> unplug -> replug. Prints the
#  client log and the server log at the end; expect "client: peer found — next
#  hop of a default route on veth0", "client: connected to [fe80::1%veth0]:15985",
#  "sent Register", "nav: guidance on", then "client: peer moved … — redialling"
#  and "connected to [fe80::2%veth0]", then "link down" on unplug; in the server
#  log RX Register / RX Pong. Only dlopen(libjcidbus.so) fails — there is no OEM
#  library in the container.
#
#  Needs the Docker CLI and a running daemon (on macOS: `colima start`).
#  Usage:  test/container-test.sh
# ============================================================================
set -eu
SELF_DIR=$(cd "$(dirname "$0")" && pwd)
ROOT_DIR=$(cd "$SELF_DIR/.." && pwd)
NAME="vegvisir-client-test"
IMAGE="debian:bookworm-slim"

command -v docker >/dev/null 2>&1 || { echo "[test] Docker CLI not found" >&2; exit 1; }
docker info >/dev/null 2>&1 || { echo "[test] no Docker daemon (on macOS: colima start)" >&2; exit 1; }

cleanup() { docker rm -f "$NAME" >/dev/null 2>&1 || true; }
trap cleanup EXIT INT TERM
cleanup

echo "[test] starting container ($IMAGE, CAP_NET_ADMIN)…"
docker run -d --name "$NAME" --cap-add=NET_ADMIN "$IMAGE" sleep 3600 >/dev/null
docker exec "$NAME" mkdir -p /src /test
# macOS tar stores xattrs (com.apple.provenance) that docker cp cannot apply.
TAR_FLAGS=""
[ "$(uname -s)" = "Darwin" ] && TAR_FLAGS="--no-mac-metadata --no-xattrs --no-acls --no-fflags"
tar -C "$ROOT_DIR" $TAR_FLAGS --exclude '*.DS_Store' -cf - src | docker cp - "$NAME:/src"
docker cp "$SELF_DIR/inside/." "$NAME:/test/"
echo "[test] running (installs g++/iproute2/python3 in the container, ~1-2 min)…"
docker exec "$NAME" sh /test/run.sh
