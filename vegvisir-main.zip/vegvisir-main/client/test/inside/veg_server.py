#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
# Minimal vegvisir-like VEG1 server for exercising the client in a container:
# dual-stack [::]:15985, logs every envelope, answers Register with a Navigation,
# pings periodically, logs Pongs, and sends active:false before closing.
import socket, struct, threading, time, sys, json

PORT = 15985
HDR = struct.Struct(">4sBBBIII")   # magic ver type flags id replyTo bodyLen
TYPES = {1:"Navigation",2:"Upgrade",3:"FileBegin",4:"FileChunk",5:"FileEnd",6:"Request",7:"Response",9:"Error",10:"Ping",11:"Pong",12:"Register"}

def ts(): return time.strftime("%H:%M:%S")
def log(msg): print(f"{ts()} [server] {msg}", flush=True)

def enc(mtype, body=b"", mid=0, reply_to=0, binary=False):
    return HDR.pack(b"VEG1", 1, mtype, 1 if binary else 0, mid, reply_to, len(body)) + body

def recv_exact(c, n):
    buf = b""
    while len(buf) < n:
        chunk = c.recv(n - len(buf))
        if not chunk: return None
        buf += chunk
    return buf

def serve(c, addr):
    log(f"client connected from {addr}")
    seq = [100]
    def send(mtype, body=b"", reply_to=0):
        seq[0] += 1
        c.sendall(enc(mtype, body, seq[0], reply_to))
        log(f"TX {TYPES.get(mtype, mtype)} id={seq[0]} {body[:80]!r}")
    def pinger():
        try:
            while True:
                time.sleep(3)
                send(10)
        except Exception as e:
            log(f"pinger stopped: {e}")
    try:
        while True:
            h = recv_exact(c, HDR.size)
            if h is None: break
            magic, ver, mtype, flags, mid, reply_to, blen = HDR.unpack(h)
            if magic != b"VEG1": log(f"BAD MAGIC {magic!r}"); break
            body = recv_exact(c, blen) if blen else b""
            if body is None: break
            log(f"RX {TYPES.get(mtype, mtype)} id={mid} replyTo={reply_to} body={body[:100]!r}")
            if mtype == 12:   # Register
                ct = json.loads(body.decode()).get("clientType")
                log(f"registered as {ct!r}")
                nav = json.dumps({"active":True,"event":4,"side":1,"angle":0,"number":0,
                                  "road":"Nguyễn Huệ","distance":1400,"unit":3,"eta":95,"speedLimit":60,
                                  "lanes":[{"angles":[0,-90],"highlight":-90,"recommended":True},{"angles":[0]}]}, ensure_ascii=False).encode()
                send(1, nav)
                threading.Thread(target=pinger, daemon=True).start()
            elif mtype == 10:  # Ping from client -> Pong
                c.sendall(enc(11, b"", 0, mid)); log(f"TX Pong replyTo={mid}")
    except Exception as e:
        log(f"conn error: {e}")
    finally:
        log(f"client {addr} gone")
        try: c.close()
        except Exception: pass

s = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
s.bind(("::", PORT)); s.listen(4)
log(f"listening on [::]:{PORT} (dual-stack)")
while True:
    c, addr = s.accept()
    threading.Thread(target=serve, args=(c, addr), daemon=True).start()
