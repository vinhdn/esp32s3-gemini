#!/bin/sh
# SPDX-License-Identifier: AGPL-3.0-or-later
# Runs INSIDE the container started by ../container-test.sh (as root, CAP_NET_ADMIN).
# Functional test of vegvisir-client v2 in a Linux container:
# a veth pair stands in for the USB tether (veth0 = the CMU side, pinned via
# VEGVISIR_IFACE; veth1 = the phone), a Python VEG1 server plays the phone.
# The client finds the phone the v1.3 way: the IPv6 next hop of the route out of
# veth0 (/proc/net/ipv6_route) — so every phase installs that route; the IPv4
# lease/gateway is there only so the diagnostics watcher has something to log.
set -u
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq >/dev/null 2>&1
apt-get install -y -qq --no-install-recommends g++ make iproute2 python3 procps >/dev/null 2>&1 || { echo "apt failed"; exit 1; }
echo "== toolchain: $(g++ --version | head -1) on $(uname -m)"

cd /src
echo "== building (host g++, debug log level)"
g++ -std=c++11 -O1 -g -Isrc -DVEGVISIR_CLIENT_VN_NORMALIZE=1 -Wall -Wextra \
    $(find src -name '*.cpp') -o /tmp/vegvisir-client -lpthread -ldl 2>&1 | tee /tmp/build.log
[ -x /tmp/vegvisir-client ] || { echo "BUILD FAILED"; exit 1; }
echo "== built /tmp/vegvisir-client ($(wc -c < /tmp/vegvisir-client) bytes)"

mkdir -p /data_persist/vegvisir-client
python3 /test/veg_server.py > /tmp/server.log 2>&1 &
SPID=$!
sleep 1

echo "== starting the service (the executable, as sm would: VEGVISIR_IFACE=veth0)"
VEGVISIR_IFACE=veth0 /tmp/vegvisir-client > /tmp/client.stderr 2>&1 &
CPID=$!
sleep 2
echo "== threads of the service:"; ls /proc/$CPID/task | wc -l

echo "== phase 1: plug in (veth0 appears; the phone = fe80::1 advertises itself as the IPv6 router, and leases IPv4)"
ip link add veth0 type veth peer name veth1
ip link set veth1 up
ip link set veth0 up
ip addr add 172.20.10.1/28 dev veth1
ip -6 addr add fe80::1/64 dev veth1
sleep 1
ip addr add 172.20.10.2/28 dev veth0
ip route add default via 172.20.10.1 dev veth0 metric 100
sleep 1
ip -6 route add default via fe80::1 dev veth0 metric 100
sleep 8

echo "== phase 2: re-tether — the phone comes back as fe80::2 (old address gone, no FIN); the client must notice and redial"
ip -6 addr del fe80::1/64 dev veth1
ip -6 addr add fe80::2/64 dev veth1
ip -6 route replace default via fe80::2 dev veth0 metric 100
sleep 15

echo "== phase 3: unplug (delete veth0)"
ip link del veth0
sleep 4

echo "== phase 4: replug"
ip link add veth0 type veth peer name veth1
ip link set veth1 up; ip link set veth0 up
ip addr add 172.20.10.1/28 dev veth1
ip -6 addr add fe80::1/64 dev veth1
ip addr add 172.20.10.2/28 dev veth0
ip -6 route add default via fe80::1 dev veth0 metric 100
sleep 8

kill $CPID 2>/dev/null; sleep 1; kill $SPID 2>/dev/null
echo "===== CLIENT LOG (/data_persist/vegvisir-client/client.log) ====="
cat /data_persist/vegvisir-client/client.log
echo "===== CLIENT STDERR ====="
cat /tmp/client.stderr
echo "===== SERVER LOG ====="
cat /tmp/server.log
echo "===== END ====="
