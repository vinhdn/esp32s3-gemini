# vegvisir-client v2 — USB → socket → HUD (Linux, C++)

A standalone Mazda Connect (JCI) service that puts phone navigation on the
instrument-cluster HUD. It builds to a plain Linux ARM executable and is
registered as its **own service** (`type="process"`) in `sm.conf` and
`sm_WCP.conf` — independent of `jciCARPLAY`.

```
phone plugged in (USB ethernet: Android tethering / CDC-NCM / RNDIS)
  │  the stock CMU flow (udev 99-usbdiscoverer.rules → linux_dhcp_setup.sh →
  │  udhcpc) brings the interface up and leases it an IP — untouched
  ▼
core/net   peer discovery (v1.3): the phone = the IPv6 next hop of the route out
  │        of usb0 (/proc/net/ipv6_route) → "peer found — next hop of a default route on usb0"
  │        TCP client → [fe80::…%usb0]:15985, VEG1 envelopes, Register{clientType:"mazda"}
  │        Ping/Pong + TCP keepalive; re-discovers every 5 s, redials when the peer moves
  ▼
hudnav/    Navigation JSON → NavManeuver / NavDistance / NavLanes → hud::*
  ▼
hud/       HudSink → OEM libjcidbus → com.jci.vbs.navi (cluster HUD)
```

**hudnav is the only navigation source, and it drives the HUD directly** — no
provider layer (v1.3's `NavProvider`/`NavSink` interfaces and the per-source sink
views are gone), no iAP2/CarPlay path and no upgrade feature in this build: the
socket carries `Navigation` (→ HUD) and `Ping`/`Pong` (transport); every other
message type is logged and dropped.

## How the phone is found

The vegvisir-client **v1.3 mechanism, cloned** (`src/core/net/peer_discovery.*`
+ `socket_client.*`): the phone runs the server on `[::]:15985`; this unit is the
client and finds the server in its **own routing table**. When a phone tethers it
advertises itself as an IPv6 router, so the kernel records its link-local
`fe80::…` as the next hop of a route out of `usb0` — column 4 of
`/proc/net/ipv6_route`. A default route wins; any gateway route on the
interface otherwise. Exact, one read, no traffic, nothing to configure. The
client thread does this every 3 s while disconnected, and every 5 s on a quiet
link so a re-tether (new address, no FIN) is noticed and redialled at once.

What discovery cannot do is spelled out in the log (throttled: only when the
answer changes):

| log line                                              | meaning / fix                                           |
|-------------------------------------------------------|---------------------------------------------------------|
| `interface "usb0" does not exist`                     | cable out, or the gadget has not come up yet            |
| `usb0 exists but has no IPv6 route yet`               | link still coming up, or IPv6 disabled on the interface |
| `no IPv6 gateway on the link — the phone is not advertising itself as a router` | enable IPv6 tethering on the phone, or pin `VEGVISIR_PEER=<fe80::…>` |
| `peer found — next hop of a default route on usb0`    | dialling                                                |

`src/core/usb/usb_net_watch.*` (the rtnetlink watcher) still runs, **for
diagnostics only**: it logs the link's timeline — interface up, IPv4 lease,
IPv4 gateway, IPv6 next hop, cable out — so the log shows *why* discovery did or
did not find a peer. Nothing depends on it; the socket client never waits for it.

## Wire protocol (VEG1)

Unchanged from vegvisir-client v1.3 — the server must not notice the difference.

- 19-byte header: `magic "VEG1" | version(1) | type(1) | flags(1) | id(4) |
  replyTo(4) | bodyLen(4)`, big-endian; body follows (JSON unless flags bit0).
- On connect the client sends `Register {"clientType":"mazda"}`. `"mazda"` is a
  vegvisir `ClientType` wire value (the head-unit role), not the project name.
- `MessageType`: Navigation=1, Upgrade=2, File*=3–5, Request=6, Response=7,
  Error=9, Ping=10, Pong=11, Register=12 (`src/core/net/envelope.h`).
- The `Navigation` JSON schema is documented at the top of
  `src/hudnav/hudnav.cpp`; the server must produce exactly that.

## Layout

```
client/
├── src/
│   ├── main.cpp                 # composition root: log, hudnav, socket client, USB watcher (diagnostics)
│   ├── core/
│   │   ├── log.h                # timestamped [vegvisir-client][TAG][L] lines
│   │   ├── nav_types.h          # nav model shared by hudnav and the HUD sink (v1.3)
│   │   ├── usb/usb_net_watch.*  # rtnetlink USB-ethernet watcher → log only (ip, gw4, gw6 timeline)
│   │   ├── net/                 # envelope (VEG1), json_lite, message_router (v1.3);
│   │   │                        # peer_discovery + socket_client: v1.3 clone (+ link callback)
│   │   └── oem/                 # dlopen'd OEM D-Bus transport thunks (v1.3) + oem_load.h
│   ├── hud/                     # hud::* sink + lane tables → com.jci.vbs.navi (v1.3, AGPL, NOTICE.md)
│   └── hudnav/                  # Navigation JSON → hud::*; wipes the HUD on link loss
├── Makefile                     # cross-compiles build/{release,debug}/vegvisir-client (ARM executable)
├── build.sh                     # runs make (Linux); stages deploy/ + a versions/ backup
├── macos-build.sh               # builds inside Docker on macOS (cross-compiler is a Linux binary)
├── m3-toolchain/                # bundled ARM cross-compiler (git-ignored, ~420 MB)
├── docs/
│   ├── hud_sink.md              # the HUD sink: API, arrow/roundabout/distance/lane mapping
│   └── hud_glyphs.html          # every cluster glyph ID drawn, with the NavEvent that selects it
├── test/
│   ├── container-test.sh        # end-to-end test in a Linux container (veth pair + VEG1 server)
│   └── inside/                  # what runs in the container: run.sh, veg_server.py
└── deploy/                      # the ready-to-copy USB bundle = one tweaks.sh module
    ├── install.sh               # adds our service stanza to sm.conf + sm_WCP.conf, starts it
    ├── uninstall.sh             # kills it, cuts exactly our stanza, removes /data_persist/vegvisir-client
    ├── module.conf              # LABEL/DESC/REBOOT=no/LOGSRC for the community USB-mod dispatcher
    ├── collect-logs.sh          # copies client.log to <USB>/logs/ (also the module's GETLOG)
    ├── install-v1.sh, uninstall-v1.sh   # previous installer (kept for reference)
    ├── vegvisir-client          # the shipping executable, placed here by build.sh (git-ignored)
    └── versions/                # timestamped backups, one per build (git-ignored)
```

## The HUD display

`src/hud/` is vegvisir-client v1.3's HUD sink behind a plain `hud::` API — the
`NavSink` interface and the per-provider views went with the provider layer (one
caller now); the rendering is unchanged: it turns the neutral
`NavManeuver` / `NavDistance` / `NavLanes` into the OEM `com.jci.vbs.navi`
frames (maneuver icon + distance, road-name strip, posted speed limit, lane
row) over `libjcidbus`, with the ~2 Hz keep-alive the cluster needs and the
Vietnamese-diacritics fold for its font. [`docs/hud_sink.md`](docs/hud_sink.md)
documents the API and every mapping (arrow table, roundabout sectors, distance
units, lanes); [`docs/hud_glyphs.html`](docs/hud_glyphs.html) draws each glyph ID.

The cluster only shows navigation the driver has switched on: **Settings →
Active Driving Display → Display Information → Navigation / Street
information**. On a unit without a navigation SD card the stock Settings app
(`/jci/gui/apps/vehsettings/js/vehsettingsApp.js`) greys the "Street
Information" item out. This build changes nothing under `/jci/gui`: v1.3's
patched copy of that file (19 × `items[1].disabled = true` → `false`) and its
`NaviSupported=TRUE` edit to `/etc/devmgr_config_master.xml` (iAP2-only) are
both *not* carried over — `install.sh` touches only `sm.conf` and
`/data_persist`.

## How the service runs

The service is a plain ARM executable, `vegvisir-client`: `main()` starts the
worker threads and parks in `pause()` until sm sends SIGTERM. `install.sh`
registers it as a **`type="process"`** service — the same kind of entry the
OEM `stage_*.sh` scripts and the community `hudd` daemon use:

```xml
<service type="process" name="vegvisir-client" path="/data_persist/vegvisir-client/vegvisir-client" args="" autorun="yes" retry_count="0" reset_board="no" stop_timeout="10000">
    <environ_var env_name="LD_LIBRARY_PATH" env_value="/jci/lib:/jci/lib/nav:/usr/lib"/>
    <!-- VEGVISIR_PORT / VEGVISIR_IFACE / VEGVISIR_PEER environ_vars, when set at install time -->
    <dependency type="service" value="devicemanager"/>
</service>
```

right before the `devicemanager` stanza of **both** `sm.conf` and `sm_WCP.conf`
(so a WCP/non-WCP board swap cannot lose the autostart). sm simply
fork/execs the path at boot; `type="process"` services take part in no
ping/handshake protocol (that is only the `jci_service` kind, where
`sm_svclauncher` `dlopen`s a `.so` exporting `GetServiceInterfaces`).
`reset_board="no"` + `retry_count="0"`: if the service dies, sm neither reboots
the unit nor loops. `LD_LIBRARY_PATH` lets the OEM `libjcidbus` /
`libjcivbsnaviclient` be `dlopen`ed. The edit is guarded the way the community USB
mods do it: backup once, insert only, then a sanity check (line count, one
token, `<service`/`</service>` balance, `devicemanager` intact) before the file
is replaced; `uninstall.sh` cuts exactly that stanza rather than restoring the
whole file, so other mods' `sm.conf` edits survive it. The scripts act on the
real `/jci/sm` and `/data_persist` only (no sandbox mode), so they are meant to
run on the unit; the insert/cut logic was exercised against the FW 74.00.324
`sm.conf`/`sm_WCP.conf` while it was written (install → idempotent re-install →
options → a foreign edit surviving uninstall → byte-identical restore → refusal
on a corrupted stanza). `main()`
starts three threads — socket client (discovers + dials), USB watcher
(diagnostics), HUD sender (lazily, on the first Navigation) — and blocks in
`pause()` until sm stops it.

Runtime options (written into the service entry by `install.sh` when set in the
installer's environment, e.g. `VEGVISIR_IFACE=usb0 sh install.sh`):

| variable         | default             | meaning                                                  |
|------------------|---------------------|----------------------------------------------------------|
| `VEGVISIR_PORT`  | `15985`             | server port; `0` disables the socket client              |
| `VEGVISIR_IFACE` | `usb0`              | interface the phone is on (discovery reads its routes; the diagnostics watcher pins to it too) |
| `VEGVISIR_PEER`  | discovered          | pin the phone's IPv6 address (`fe80::…` literal) instead of reading the routing table |

## Build

The Mazda CMU is ARM (Cortex-A9 / NEON), so the executable is **cross-compiled** with
the `m3-toolchain` ARM compiler bundled in this project (`./m3-toolchain`,
git-ignored). Flags match the device runtime: `-std=c++11`,
`-D_GLIBCXX_USE_CXX11_ABI=0` (GCC-4.6-era libstdc++), `-fvisibility=hidden`,
`-lpthread -ldl`.

**Runtime ceiling.** The unit ships `libstdc++.so.6.0.14` (newest symbol
version `GLIBCXX_3.4.14`, `CXXABI_1.3.4`/`CXXABI_ARM_1.3.3`) and glibc 2.11,
while the toolchain's own libstdc++ is 6.0.20. Anything the binary imports
beyond that makes the loader refuse it on the car
(`libstdc++.so.6: version 'GLIBCXX_3.4.20' not found`). GCC 4.9's headers
route range-checked `std::string`/`std::vector` calls (`substr`,
`compare(pos, n, …)`, `at`, …) through `std::__throw_out_of_range_fmt`, which
only exists since 3.4.20 — `src/core/glibcxx_compat.cpp` defines that one
function locally so no import is needed. `build.sh` then runs the toolchain's
`readelf -V` over the linked binary and **fails the build** if any version
newer than the device's appears. Do not reach for `-static-libstdc++`: the OEM
libraries we `dlopen` use the device's libstdc++, and two C++ runtimes in one
process corrupted the heap in a sibling project.

On a **Linux x86-64 host** (the cross-compiler is a Linux binary):

```sh
./build.sh            # release -> deploy/
./build.sh debug      # debug (VERBOSE log, unstripped)
./build.sh clean
```

On **macOS**, build inside Docker (starts Colima if no daemon is running):

```sh
./macos-build.sh      # release   (also: debug / clean)
```

It keeps a small `client-build:m3` image between runs (rebuilding it means
`apt-get` under amd64 emulation), copies the project into a fresh container,
runs `./build.sh` there and copies back only the built files (`build/`,
`deploy/vegvisir-client`, `deploy/versions/`). `./macos-build.sh clean` cleans
the host tree and removes that image.

Quick host-side checks without the toolchain (the ARM binary itself cannot run on
the dev host):

```sh
# portable TUs
clang++ -std=c++11 -Isrc -fsyntax-only -Wall -Wextra src/core/net/envelope.cpp
# Linux-only TUs (netlink, TCP options) against the bundled sysroot
TC=m3-toolchain; T=arm-cortexa9_neon-linux-gnueabi
clang++ --target=armv7-linux-gnueabi -std=c++11 -nostdinc++ \
  -isystem $TC/$T/include/c++/4.9.1 -isystem $TC/$T/include/c++/4.9.1/$T \
  --sysroot=$TC/$T/sysroot -Isrc -fsyntax-only -Wall -Wextra src/core/usb/usb_net_watch.cpp
```

The whole path except the OEM HUD can be exercised in a Linux container with
`CAP_NET_ADMIN` (needs Docker; on macOS `colima start` first):

```sh
test/container-test.sh
```

It builds `src/` with the container's `g++`, runs the executable the way sm does
(`VEGVISIR_IFACE=veth0 /tmp/vegvisir-client`), and plays the phone with a
`veth0`/`veth1` pair plus a Python VEG1 server on `[::]:15985`
(`test/inside/`): plug in → address → default route → IPv6-only gateway →
unplug → replug. The printed client log shows the bind, the connect, the
Register, the decoded Navigation, Ping/Pong and the HUD clear on unplug; only
`dlopen(libjcidbus.so)` fails there.

## Install

`deploy/` is a self-contained module: drop it on the community USB-mod stick as
`modules/NN-vegvisir-client/` and `tweaks.sh` shows a **CAI / GO** button for it
(`module.conf`), call it from `usb-autorun`'s `vegvisir-autorun.sh`, or run it
over SSH:

```sh
sh install.sh                        # binary -> /data_persist, stanza -> sm*.conf, starts the service NOW
VEGVISIR_IFACE=usb0 sh install.sh    # same, pinning options into the stanza (see table above)
VEGVISIR_NO_START=1 sh install.sh    # install only; the service starts on the next boot
sh uninstall.sh                      # kill, cut our stanza, remove /data_persist/vegvisir-client
```

No reboot is needed: install starts the service itself (`setsid
/data_persist/vegvisir-client/vegvisir-client` with the stanza's
`LD_LIBRARY_PATH`) and sm takes over from the next boot. Re-running
install with a new build is the upgrade path — it stops the running instance,
swaps the file atomically and starts again. `uninstall.sh` also deletes
`client.log` with the module directory, so collect logs first
(`collect-logs.sh`, or *LAY LOG* on the stick). Always `sh script`, never
`./script` — the stick is usually mounted `noexec`.

Then switch the HUD navigation display on once: Settings → Active
Driving Display → Display Information → Navigation **On** (on a unit without a
navigation SD card the *Street information* item is greyed out by the stock
Settings app — see "The HUD display").

Then plug the phone in (USB tethering on, vegvisir app running) and follow
`/data_persist/vegvisir-client/client.log`:

```
… [vegvisir-client][CORE][D] === vegvisir-client v2 loaded pid=1234 … ===
… [vegvisir-client][USB][D]  USB ethernet interface usb0 (idx 7) — watching
… [vegvisir-client][USB][D]  usb0 (idx 7): up ip=192.168.42.12 gw4=192.168.42.129 gw6=-
… [vegvisir-client][CORE][D] usb: usb0 bound — our ip 192.168.42.12, phone 192.168.42.129
… [vegvisir-client][NET][D]  client: connected to 192.168.42.129:15985 via usb0 — VEG1
… [vegvisir-client][NET][D]  client: sent Register{clientType:mazda}
… [vegvisir-client][HUDNAV][D] nav: guidance on -> HUD
```

Release builds log lifecycle (`D`) and up; debug builds add every Navigation
frame and HUD send (`V`). The log is appended across boots — trim it now and
then.

## Known limitations

- One interface (`usb0` unless `VEGVISIR_IFACE`), IPv6 only: the phone must
  advertise itself as an IPv6 router on the link (Android does when it tethers).
  An IPv4-only tether is not dialled — the log says so; pin
  `VEGVISIR_PEER=<fe80::…>`.
- `Upgrade` (push a new build over the socket) from v1.3 is not carried over;
  update by re-running `install.sh` from USB.
- The OEM transport (`src/core/oem/`) is reverse-engineered (Ghidra, hand-derived
  ABI); re-verify after any firmware update.

## License

AGPL-3.0 — see [`LICENSE`](LICENSE) and [`NOTICE.md`](NOTICE.md). The HUD
glyph/lane tables in `src/hud/` are adapted from Trevelopment/headunit and
hudbridge-hud (AGPL), which is what makes the whole work AGPL.
