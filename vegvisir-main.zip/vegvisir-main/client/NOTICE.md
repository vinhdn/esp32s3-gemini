# Attribution

This work is licensed under the **GNU Affero General Public License v3.0** — see
[`LICENSE`](LICENSE). AGPL-3.0 is inherited from the upstream project the HUD
sender is derived from (copyleft).

- **Original to this project** (© 2026 rongcondihoc) — the standalone-service
  entry (`src/main.cpp`), the rtnetlink USB-ethernet watcher
  (`src/core/usb/`, following the author's own `usb-bridge` research daemon),
  the target-driven socket client (`src/core/net/socket_client.*`), the hudnav
  Navigation decoder (`src/hudnav/`), the VEG1 framing / JSON reader / router
  (`src/core/net/`), the OEM transport glue (`src/core/oem/`, reverse-engineered
  from the OEM libraries with Ghidra), the build files and the install scripts.
  Most of these are carried over from vegvisir-client v1.3 by the same author.

- **Derived code (AGPL-3.0)** — the HUD glyph table, the roundabout-icon
  bucketing and the OEM `com.jci.vbs.navi` sending pattern in
  [`src/hud/hud_sink.cpp`](src/hud/hud_sink.cpp) are adapted from
  [Trevelopment/headunit](https://github.com/Trevelopment/headunit). This is the
  reused code, and the reason the whole work is AGPL-3.0.

- **Derived code (AGPL-3.0)** — the lane tables in
  [`src/hud/hud_lane.cpp`](src/hud/hud_lane.cpp) (direction bitmask → OEM lane
  code → cluster glyph, "Table A") and the `VBS_NAVI_SetRecommLaneReq` call form
  are ported from **hudbridge-hud** (`mcu/src/lane`), which in turn ports them
  from VitaliyKurokhtin's **oem-aa-mod** `hud_lane.h`. Ported verbatim rather
  than re-derived: that chain has been verified against a real cluster.

- **`m3-toolchain`** — the ARM cross-compiler bundled under `m3-toolchain/` is an
  independent third-party project ([lmagder/m3-toolchain](https://github.com/lmagder/m3-toolchain),
  its own license), not part of this work.

Per-file `SPDX-License-Identifier` headers mark which is which.

## Disclaimer

Unofficial, community-developed modification — **not affiliated with, endorsed
by, or supported by Mazda Motor Corporation.** "Mazda", "Mazda Connect" and
related marks belong to their respective owners. For research and personal use
on your own vehicle, at your own risk. No warranty.
