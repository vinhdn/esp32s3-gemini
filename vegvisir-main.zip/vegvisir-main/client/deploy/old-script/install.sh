#!/bin/sh
# ============================================================================
#  vegvisir-client v2 — installer for Mazda CMU (JCI / Mazda Connect).
#
#  Adds a NEW, standalone service to sm.conf (or sm_WCP.conf). This service is
#  independent — it does not touch or depend on jciCARPLAY.
#
#  sm launches an executable, but the service is a shared object whose
#  constructor is the entry point and parks the process alive. So the entry runs
#  a stock host binary (HOST_BIN) with LD_PRELOAD set to our .so — no launcher
#  script, no argument dependency. LD_LIBRARY_PATH names the OEM library dirs so
#  the service can dlopen libjcidbus / libjcivbsnaviclient (the HUD transport).
#
#  Optional tuning, taken from THIS shell's environment when set and written
#  into the service entry as <environ_var>s:
#    VEGVISIR_PORT=<n>       server port (default 15985; 0 disables the socket)
#    VEGVISIR_IFACE=<name>   watch only this interface instead of auto-detecting
#                            USB ethernet (e.g. usb0)
#    VEGVISIR_PEER=<ip>      pin the phone's address (IPv4 or IPv6 literal)
#                            instead of taking the gateway of the USB link
#  e.g.  VEGVISIR_IFACE=usb0 sh install.sh
#
#  To emit a valid entry, install detects the service element's tag and
#  indentation from the config (it only reads the XML shape) and writes a fresh
#  entry with our own name/path/environment. Backs up the edited config;
#  reversible via uninstall.sh; sanity-checked so a bad edit leaves the file
#  untouched.
#
#  Usage:  copy the deploy/ folder to the unit and run:  sh install.sh
# ============================================================================
set -u
TAG="[client install]"

SVC_NAME="vegvisir-client"
# Any stock, present executable — our .so parks the process, so its own behaviour
# and arguments are irrelevant; it just needs to exist and be executable.
HOST_BIN="/bin/sleep"
# Where the OEM keeps libjcidbus.so / libjcivbsnaviclient.so (same value the
# jciCARPLAY-based bridges use).
OEM_LIBPATH="/jci/lib:/usr/lib"

SELF_DIR=$(dirname "$0")
SO="vegvisir-client.so"
SO_SRC="$SELF_DIR/$SO"
MOD_DIR="/data_persist/$SVC_NAME"
SO_DST="$MOD_DIR/$SO"
SVC_TOKEN="name=\"$SVC_NAME\""

log() { echo "$TAG $*"; }
die() { echo "$TAG ERROR: $*"; mount -o remount,ro / 2>/dev/null; exit 1; }

# --- preflight ---------------------------------------------------------------
[ -f "$SO_SRC" ] || die "$SO not found next to install.sh ($SO_SRC). Build it first with ./build.sh."
[ -f /jci/sm/sm.conf ] || die "not a CMU (no /jci/sm/sm.conf) — aborting"
log "installing standalone service '$SVC_NAME' from $SO_SRC ($(wc -c < "$SO_SRC") bytes)"
for V in VEGVISIR_PORT VEGVISIR_IFACE VEGVISIR_PEER; do
  eval VAL=\${$V:-}
  [ -n "$VAL" ] && log "option $V=$VAL"
done

# --- pick the sm config the SM actually launches from ------------------------
if [ -x /jci/scripts/get_board_type.sh ]; then
  /jci/scripts/get_board_type.sh >/dev/null 2>&1; BT=$?
else
  BT=""
fi
if [ "$BT" = "2" ] && [ -f /jci/sm/sm_WCP.conf ]; then
  CONFS="/jci/sm/sm_WCP.conf"
  log "WCP hardware (get_board_type.sh=2) -> patching sm_WCP.conf"
else
  CONFS="/jci/sm/sm.conf"
  log "no WCP hardware (get_board_type.sh=${BT:-n/a}) -> patching sm.conf"
fi

# --- remount rootfs rw -------------------------------------------------------
mount -o remount,rw / 2>/dev/null || die "remount rw failed"

# --- 1) place the .so on a persistent path -----------------------------------
mkdir -p "$MOD_DIR" || die "mkdir $MOD_DIR failed"
cp -f "$SO_SRC" "$SO_DST" || die "copy .so failed"
chmod 0644 "$SO_DST"
log "installed $SO_DST"

# --- 2) add a standalone service entry to the config -------------------------
for CONF in $CONFS; do
  [ -f "$CONF" ] || { log "skip (absent): $CONF"; continue; }
  BAK="/data_persist/$(basename "$CONF").bak_prevegvisirclient"
  [ -f "$BAK" ] || { cp -a "$CONF" "$BAK"; log "backup -> $BAK"; }

  if grep -q "$SVC_TOKEN" "$CONF"; then
    log "$CONF: service '$SVC_NAME' already present, skipping (uninstall first to change options)"
    continue
  fi

  # (a) model the entry on the FIRST REAL SERVICE element: a <service ...> line
  #     carrying name= and a path= attribute — " path=" with a leading blank, on
  #     purpose: the <reports> section that precedes <services> has lines with
  #     exec_path=, which a bare /path=/ matches, and the entry would then be
  #     emitted as a <report> in the wrong section, where sm never starts it.
  #     We copy only the XML shape: tag + indentation.
  SAMPLE=$(awk '/<service[ \t]/ && /[ \t]name="/ && /[ \t]path="/ {print; exit}' "$CONF")
  [ -n "$SAMPLE" ] || { log "$CONF: no service element found to model — skipping"; continue; }
  ETAG=$(printf '%s\n' "$SAMPLE" | sed -n 's/^[[:space:]]*<\([A-Za-z_][A-Za-z0-9_-]*\).*/\1/p')
  INDENT=$(printf '%s\n' "$SAMPLE" | sed -n 's/^\([[:space:]]*\)<.*/\1/p')
  [ -n "$ETAG" ] || { log "$CONF: could not detect service tag from '$SAMPLE' — skipping"; continue; }
  log "$CONF: modeling <$ETAG> service element"

  # (b) build the fresh entry. type="process": sm fork/execs HOST_BIN and watches
  #     the pid (the default the <services> header declares, spelled out here).
  {
    printf '%s<%s type="process" name="%s" path="%s" reset_board="no">\n' "$INDENT" "$ETAG" "$SVC_NAME" "$HOST_BIN"
    printf '%s    <environ_var env_name="LD_PRELOAD" env_value="%s"/>\n' "$INDENT" "$SO_DST"
    printf '%s    <environ_var env_name="LD_LIBRARY_PATH" env_value="%s"/>\n' "$INDENT" "$OEM_LIBPATH"
    for V in VEGVISIR_PORT VEGVISIR_IFACE VEGVISIR_PEER; do
      eval VAL=\${$V:-}
      [ -n "$VAL" ] && printf '%s    <environ_var env_name="%s" env_value="%s"/>\n' "$INDENT" "$V" "$VAL"
    done
    printf '%s</%s>\n' "$INDENT" "$ETAG"
  } > /tmp/client.entry

  # (c) insert the entry as a sibling right after that first service element
  #     (position only — inside <services>; the entry itself is independent).
  awk -v cf=/tmp/client.entry '
    function emit(  l){ while((getline l < cf)>0) print l; close(cf) }
    { print }
    done { next }
    /<service[ \t]/ && /[ \t]name="/ && /[ \t]path="/ && !seen {
      seen=1
      if ($0 ~ /\/>[ \t]*$/) { emit(); done=1 }   # sample was self-closing
      else inblk=1
      next
    }
    inblk && /^[ \t]*<\// { emit(); inblk=0; done=1 }
  ' "$CONF" > /tmp/client.new

  old=$(wc -l < "$CONF"); new=$(wc -l < /tmp/client.new)
  if [ "$new" -gt "$old" ] && grep -q "$SVC_TOKEN" /tmp/client.new; then
    cp /tmp/client.new "$CONF"; log "$CONF: added service '$SVC_NAME' ($old->$new lines)"
  else
    log "$CONF: SANITY FAILED ($old->$new) — left untouched"
  fi
  rm -f /tmp/client.entry /tmp/client.new
done

# --- finish ------------------------------------------------------------------
sync
mount -o remount,ro / 2>/dev/null
echo ""
log "=== VERIFY ==="
for CONF in $CONFS; do
  log "$(basename "$CONF") service-'$SVC_NAME'-lines=$(grep -c "$SVC_TOKEN" "$CONF" 2>/dev/null)"
done
log "so-installed=$([ -f "$SO_DST" ] && echo yes || echo NO)"
echo ""
log "DONE. **Reboot the unit** to start the service."
log "Log: $MOD_DIR/client.log  — plug the phone in (USB tethering + vegvisir app running)"
log "     and look for 'usb: ... bound' then 'client: connected to ...:15985'."
log "To remove: run uninstall.sh"
