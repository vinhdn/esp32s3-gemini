#!/bin/sh
# ============================================================================
#  vegvisir-client v2 — uninstaller. Restores stock sm.conf from the backup install.sh made
#  (/data_persist/*.bak_prevegvisirclient) and removes the service files. If no backup
#  exists, it strips the "vegvisir-client" service entry it added.
#
#  Usage:  sh uninstall.sh   (over SSH, or via USB)
# ============================================================================
set -u
TAG="[client uninstall]"
SVC_NAME="vegvisir-client"
SVC_TOKEN="name=\"$SVC_NAME\""
MOD_DIR="/data_persist/$SVC_NAME"

log() { echo "$TAG $*"; }

[ -f /jci/sm/sm.conf ] || { log "not a CMU — aborting"; exit 1; }
mount -o remount,rw / 2>/dev/null || { log "remount rw failed"; exit 1; }

for CONF in /jci/sm/sm.conf /jci/sm/sm_WCP.conf; do
  [ -f "$CONF" ] || continue
  BAK="/data_persist/$(basename "$CONF").bak_prevegvisirclient"
  if [ -f "$BAK" ]; then
    cp -a "$BAK" "$CONF" && log "restored $CONF from backup"
  elif grep -q "$SVC_TOKEN" "$CONF" 2>/dev/null; then
    # no backup (partial install): drop the client service block — from its
    # opening line through the following closing tag (or that line if self-closing).
    awk '
      skip==1 { if ($0 ~ /^[ \t]*<\//) { skip=0 } ; next }
      /name="'"$SVC_NAME"'"/ { if ($0 ~ /\/>[ \t]*$/) next; skip=1; next }
      { print }
    ' "$CONF" > /tmp/client.u
    if [ -s /tmp/client.u ] && ! grep -q "$SVC_TOKEN" /tmp/client.u; then
      cp /tmp/client.u "$CONF"; log "stripped '$SVC_NAME' service from $CONF (no backup found)"
    else
      log "WARN: could not cleanly strip '$SVC_NAME' from $CONF — left untouched"
    fi
    rm -f /tmp/client.u
  fi
done

rm -rf "$MOD_DIR" && log "removed $MOD_DIR"
sync
mount -o remount,ro / 2>/dev/null

log "=== VERIFY (expect 0) ==="
log "sm.conf service-'$SVC_NAME'-lines=$(grep -c "$SVC_TOKEN" /jci/sm/sm.conf 2>/dev/null)"
log "DONE. Reboot to return fully to stock."
