#!/bin/sh
# ============================================================================
# INSTALL vegvisir-client : dat binary `vegvisir-client` vao /data_persist va khai
# 1 stanza <service type="process"> DOC LAP trong sm.conf / sm_WCP.conf -> sm tu
# fork/exec lai sau MOI lan reboot (y nhu 90-hudbridge-hud lam voi `hudd`).
# KHONG dinh vao jciCARPLAY hay tien trinh OEM nao, khong LD_PRELOAD, khong
# sm_svclauncher. Nav den tu app (USB tether, cong 15985) roi len HUD qua
# com.jci.vbs.navi (libjcidbus, LD_LIBRARY_PATH tro toi /jci/lib).
#
# AN TOAN (theo dung format 10-carplay-hud / 90-hudbridge-hud):
#   - backup conf 1 lan (.bak_prevegvisir), CHI THEM stanza, khong doi dong OEM
#   - reset_board="no" retry_count="0": service chet -> KHONG bootloop
#   - sanity check dem dong/token/can-bang-tag TRUOC khi commit; fail = khong doi
#   - chen vao CA HAI conf (WCP va non-WCP) de doi board khong mat autostart
#   - binary ghi ra file .new roi mv (atomic; ghi de binary dang chay = ETXTBSY)
# Chay ngay sau khi cai (setsid) -> KHONG can reboot; sau reboot sm quan ly.
# Go bang uninstall.sh (cat DUNG stanza cua minh, xoa /data_persist/vegvisir-client).
#
# CACH CHAY (tren xe, root)
#   - USB mod (tweaks.sh): folder nay = modules/NN-vegvisir-client/ -> nut CAI
#   - usb-autorun:         vegvisir-autorun.sh goi  sh deploy/install.sh
#   - SSH tren unit:       sh install.sh        (vfat noexec -> luon `sh`)
#
# TUY CHON (env khi chay; ghi vao stanza lam <environ_var> cho service):
#   VEGVISIR_PORT=<n>       cong server tren app (mac dinh 15985; 0 = tat socket)
#   VEGVISIR_IFACE=<if>     interface noi dien thoai (mac dinh usb0); client doc route cua no de tim app
#   VEGVISIR_PEER=<ip6>     ghim dia chi IPv6 cua app (fe80::...) thay vi tu do qua bang route
#   VEGVISIR_NO_START=1     chi cai, KHONG chay ngay (de reboot moi chay)
#   vd:  VEGVISIR_IFACE=usb0 sh install.sh
# ============================================================================
set -u
TAG="[vegvisir-client install]"
SELF=$(cd "$(dirname "$0")" && pwd)

SVC="vegvisir-client"
BIN="vegvisir-client"                     # executable do build.sh dat canh script nay
BIN_SRC="$SELF/$BIN"
MOD_DIR="/data_persist/$SVC"
BIN_DST="$MOD_DIR/$BIN"                   # path= trong stanza: ban da copy (KHONG phai USB)
LOG="$MOD_DIR/client.log"                 # duong dan cung trong main.cpp (kLogPath)
TOKEN="name=\"$SVC\""
LDPATH="/jci/lib:/jci/lib/nav:/usr/lib"   # libjcidbus.so + libjcivbsnaviclient.so
TMP=/tmp/vegvisir.new
ENTRY=/tmp/vegvisir.entry

log() { echo "$TAG $*"; }
die() { echo "$TAG ERROR: $*"; rm -f "$TMP" "$ENTRY"; mount -o remount,ro / 2>/dev/null; exit 1; }
# pid cua moi process dang chay binary cua minh (file exec luon nam trong /proc/<pid>/maps)
veg_pids() {
  for m in /proc/[0-9]*/maps; do
    grep -q "$BIN_DST" "$m" 2>/dev/null && echo "$m" | cut -d/ -f3
  done
}

# --- stanza: dong 1 + environ_var + [option] + dependency + dong dong; indent nhu OEM ---
# type="process" path=<binary>: sm fork/exec thang binary, SIGTERM de dung. Khong
# ping/handshake voi sm (chi jci_service moi co). LD_LIBRARY_PATH: binary roi phai
# tu biet /jci/lib de dlopen libjcidbus (nhu hudd). dependency devicemanager:
# D-Bus/OEM len truoc (nhu 90-hudbridge-hud).
L_OPEN="        <service type=\"process\" name=\"$SVC\" path=\"$BIN_DST\" args=\"\" autorun=\"yes\" retry_count=\"0\" reset_board=\"no\" stop_timeout=\"10000\">"
L_ENV="            <environ_var env_name=\"LD_LIBRARY_PATH\" env_value=\"$LDPATH\"/>"
L_DEP="            <dependency type=\"service\" value=\"devicemanager\"/>"
L_CLOSE="        </service>"
OPTS=""; NOPT=0
for V in VEGVISIR_PORT VEGVISIR_IFACE VEGVISIR_PEER; do
  eval VAL=\${$V:-}
  [ -n "$VAL" ] || continue
  case "$VAL" in *[\"\<\>\&]*) die "gia tri $V='$VAL' chua ky tu khong hop le trong XML" ;; esac
  OPTS="$OPTS            <environ_var env_name=\"$V\" env_value=\"$VAL\"/>
"
  NOPT=$((NOPT+1)); log "option $V=$VAL"
done
NLINES=$((4+NOPT))          # so dong stanza se chen (uninstall.sh chap nhan 4..8)

# --- preflight (abort, khong doan) ---
[ -f "$BIN_SRC" ] || die "khong thay $BIN_SRC (build truoc: ./macos-build.sh hoac ./build.sh)"
[ "$(id -u)" = "0" ] || die "phai chay bang root"
CONFS=""
for c in /jci/sm/sm_WCP.conf /jci/sm/sm.conf; do
  [ -f "$c" ] && grep -q 'name="devicemanager"' "$c" && CONFS="$CONFS $c"
done
[ -n "$CONFS" ] || die "khong thay sm.conf/sm_WCP.conf co stanza devicemanager (khong phai CMU?) -> abort"
log "config se sua:$CONFS"
RUNCONF=$(ps 2>/dev/null | grep '[s]m -f' | sed 's/.*-f *//' | awk '{print $1}' | head -1)
log "sm dang chay voi: ${RUNCONF:-?}"
[ -f /jci/lib/libjcidbus.so ] || log "WARN: khong thay /jci/lib/libjcidbus.so — HUD se khong len, kiem tra LD_LIBRARY_PATH"
mount -o remount,rw / 2>/dev/null || die "remount rw fail"

# --- 1. dung instance cu (nang cap / cai lai) ---
OLD=$(veg_pids | tr '\n' ' ')
if [ -n "$OLD" ]; then
  for p in $OLD; do kill "$p" 2>/dev/null; done
  n=0; while [ $n -lt 3 ] && [ -n "$(veg_pids)" ]; do sleep 1; n=$((n+1)); done
  for p in $(veg_pids); do kill -9 "$p" 2>/dev/null && log "phai kill -9 pid $p"; done
  log "da dung instance cu (pid $OLD)"
fi

# --- 2. dat binary (atomic: .new -> mv; cp thang len binary dang chay bi ETXTBSY) ---
mkdir -p "$MOD_DIR" || die "mkdir $MOD_DIR fail"
cp -f "$BIN_SRC" "$BIN_DST.new" || die "copy binary fail"
chmod 0755 "$BIN_DST.new"
mv -f "$BIN_DST.new" "$BIN_DST" || die "mv binary fail"
BIN_SUM=$(md5sum "$BIN_DST" 2>/dev/null | awk '{print $1}')
log "installed $BIN_DST ($(wc -c < "$BIN_DST" | tr -d ' ') bytes, md5 ${BIN_SUM:-?})"

# --- 3. backup + chen stanza vao tung conf ---
for CONF in $CONFS; do
  BASE=$(basename "$CONF")
  BAK="/data_persist/$BASE.bak_prevegvisir"
  [ -f "$BAK" ] || { cp -a "$CONF" "$BAK" || die "backup $CONF fail"; log "backup -> $BAK"; }

  if grep -q "$TOKEN" "$CONF"; then
    log "$BASE: stanza da co -> skip insert (muon doi option: GO roi CAI lai)"
    continue
  fi

  o=$(wc -l < "$CONF" | tr -d ' ')
  os=$(grep -c '<service ' "$CONF")
  oe=$(grep -c '</service>' "$CONF")
  od=$(grep -c '<service .*name="devicemanager"' "$CONF")
  [ "$od" -eq 1 ] || die "$BASE: devicemanager xuat hien $od lan (ky vong 1) -> abort"

  # Stanza ra file tam (awk -v khong nhan gia tri co xuong dong), roi chen NGAY
  # TRUOC stanza devicemanager (chac chan dang trong <services>).
  { echo "$L_OPEN"; echo "$L_ENV"; printf '%s' "$OPTS"; echo "$L_DEP"; echo "$L_CLOSE"; } > "$ENTRY"
  [ "$(wc -l < "$ENTRY" | tr -d ' ')" -eq "$NLINES" ] || die "stanza tam sai so dong"
  awk -v ef="$ENTRY" '
    /<service / && /name="devicemanager"/ && !done {
      while ((getline l < ef) > 0) print l
      close(ef); done = 1
    }
    { print }
  ' "$CONF" > "$TMP" || die "awk fail tren $CONF"

  n=$(wc -l < "$TMP" | tr -d ' ')
  t=$(grep -c "$TOKEN" "$TMP")
  ns=$(grep -c '<service ' "$TMP")
  ne=$(grep -c '</service>' "$TMP")
  nd=$(grep -c '<service .*name="devicemanager"' "$TMP")

  if [ "$n" -eq "$((o+NLINES))" ] && [ "$t" -eq 1 ] && [ "$ns" -eq "$((os+1))" ] \
     && [ "$ne" -eq "$((oe+1))" ] && [ "$nd" -eq "$od" ]; then
    cp "$TMP" "$CONF" || die "commit $CONF fail"
    log "$BASE: chen OK ($o->$n dong, service $os->$ns, /service $oe->$ne, devicemanager=$nd)"
  else
    die "SANITY FAIL tren $BASE (n=$n want $((o+NLINES)) token=$t service=$ns/$((os+1)) close=$ne/$((oe+1)) devmgr=$nd/$od) -> KHONG doi file"
  fi
  rm -f "$TMP" "$ENTRY"
done

# --- 4. marker ---
{
  echo "installed: $(date)"
  echo "binary: $BIN_DST md5=${BIN_SUM:-?} bytes=$(wc -c < "$BIN_DST" | tr -d ' ')"
  echo "confs:$CONFS"
  [ -n "$OPTS" ] && printf 'options:\n%s' "$OPTS"
} > "$MOD_DIR/installed" 2>/dev/null

sync
mount -o remount,ro / 2>/dev/null

# --- 5. chay ngay (khong can reboot). Binary roi -> tu set LD_LIBRARY_PATH nhu
#        stanza; setsid de tach khoi shell/dispatcher/udev; stdio ve /dev/null
#        (log cua service ghi vao $LOG). Sau reboot sm exec lai y nhu vay.
STARTED=0
if [ -n "${VEGVISIR_NO_START:-}" ]; then
  log "VEGVISIR_NO_START set: khong chay ngay, reboot de sm chay"
else
  # Option -> env cho process con (stanza lo phan nay khi sm chay).
  for V in VEGVISIR_PORT VEGVISIR_IFACE VEGVISIR_PEER; do
    eval VAL=\${$V:-}; [ -n "$VAL" ] && export "$V"
  done
  LD_LIBRARY_PATH="$LDPATH" setsid "$BIN_DST" </dev/null >/dev/null 2>&1 &
  STARTED=1
  sleep 3
fi

# --- verify ---
echo ""
log "=== VERIFY ==="
for CONF in $CONFS; do
  log "$(basename "$CONF"): stanza=$(grep -c "$TOKEN" "$CONF") $(grep "$TOKEN" "$CONF" | grep -oE 'reset_board="[a-z]*"')"
done
log "binary      = $([ -x "$BIN_DST" ] && echo yes || echo NO)"
log "backup      = $(ls /data_persist/sm*.bak_prevegvisir 2>/dev/null | tr '\n' ' ')"
PIDS=$(veg_pids | tr '\n' ' ')
log "dang chay   = ${PIDS:-KHONG}"
if [ -f "$LOG" ]; then
  log "log ($LOG) 8 dong cuoi:"; tail -8 "$LOG" 2>/dev/null
fi
echo ""
if [ "$STARTED" = 0 ]; then
  log "DONE. Stanza + binary da dat; reboot de sm chay service."
  exit 0
fi
if [ -n "$PIDS" ]; then
  log "DONE. Service dang chay (pid $PIDS); sau reboot sm tu chay lai."
  log "Cam box/dien thoai (USB tether + app vegvisir) -> $LOG phai co 'usb: ... bound' roi 'client: connected to'."
  log "Go: uninstall.sh (kill + cat stanza + xoa $MOD_DIR)."
  exit 0
fi
log "service KHONG chay duoc — xem $LOG (stanza van da khai, reboot se thu lai)."
exit 1
