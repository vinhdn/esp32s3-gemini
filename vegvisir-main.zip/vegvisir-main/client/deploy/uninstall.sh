#!/bin/sh
# ============================================================================
# UNINSTALL vegvisir-client : dung service, cat DUNG stanza cua minh khoi
# sm.conf / sm_WCP.conf, xoa /data_persist/vegvisir-client (binary + log + marker)
# va backup. Khong con dau vet -> xe ve nguyen ban. KHONG reboot (khong can:
# service da bi kill; sm khong con stanza de chay lai).
#
# CO Y KHONG restore de-toan-file tu .bak_prevegvisir: neu mod khac (CarPlay HUD,
# AA HUD...) duoc cai SAU day thi restore se dap luon thay doi cua no. Nen o day
# cat dung stanza (tu <service ... name="vegvisir-client"> den </service>) roi
# sanity check truoc khi commit. Backup chi xoa khi moi conf da cat OK; sanity
# fail -> giu backup + giu nguyen conf de cuu tay:
#     cp /data_persist/sm_WCP.conf.bak_prevegvisir /jci/sm/sm_WCP.conf
#
# LUU Y: client.log bi xoa cung /data_persist/vegvisir-client -> LAY LOG truoc.
# Chay tren xe, root:  sh uninstall.sh
# ============================================================================
set -u
TAG="[vegvisir-client uninstall]"
SVC="vegvisir-client"
BIN="vegvisir-client"
MOD_DIR="/data_persist/$SVC"
TOKEN="name=\"$SVC\""
TMP=/tmp/vegvisir.rm

log() { echo "$TAG $*"; }
die() { echo "$TAG ERROR: $*"; rm -f "$TMP"; mount -o remount,ro / 2>/dev/null; exit 1; }
# pid cua moi process dang chay binary (hoac .so ban cu) cua minh: /proc/<pid>/maps
veg_pids() {
  for m in /proc/[0-9]*/maps; do
    grep -q "$MOD_DIR/$BIN" "$m" 2>/dev/null && echo "$m" | cut -d/ -f3
  done
}

[ "$(id -u)" = "0" ] || die "phai chay bang root"

# --- 1. dung service (SIGTERM; treo thi -9) ---
killed=0
for p in $(veg_pids); do kill "$p" 2>/dev/null && killed=$((killed+1)); done
if [ $killed -gt 0 ]; then
  n=0; while [ $n -lt 3 ] && [ -n "$(veg_pids)" ]; do sleep 1; n=$((n+1)); done
  for p in $(veg_pids); do kill -9 "$p" 2>/dev/null && log "phai kill -9 pid $p (treo)"; done
fi
log "da dung $killed process"

# --- 2. cat stanza khoi moi conf co no ---
mount -o remount,rw / 2>/dev/null || die "remount rw fail"
CONFS="/jci/sm/sm_WCP.conf /jci/sm/sm.conf"
for CONF in $CONFS; do
  [ -f "$CONF" ] || continue
  BASE=$(basename "$CONF")
  grep -q "$TOKEN" "$CONF" || { log "$BASE: khong co stanza -> skip"; continue; }

  o=$(wc -l < "$CONF" | tr -d ' ')
  os=$(grep -c '<service ' "$CONF")
  oe=$(grep -c '</service>' "$CONF")
  od=$(grep -c '<service .*name="devicemanager"' "$CONF")
  # state machine: tu dong mo cua minh den </service> dau tien sau do
  awk -v tok="$TOKEN" '
    index($0, tok) > 0 && /<service / { skip = 1; next }   # dong mo stanza cua minh
    skip == 1 && /<\/service>/        { skip = 0; next }   # dong dong
    skip == 1                          { next }            # environ_var / dependency
    { print }
  ' "$CONF" > "$TMP" || die "awk fail tren $CONF"

  n=$(wc -l < "$TMP" | tr -d ' ')
  t=$(grep -c "$TOKEN" "$TMP")
  ns=$(grep -c '<service ' "$TMP")
  ne=$(grep -c '</service>' "$TMP")
  nd=$(grep -c '<service .*name="devicemanager"' "$TMP")
  rm_lines=$((o-n))

  # Stanza cua install.sh dai 4..7 dong (4 + toi da 3 option; ban cu type=process
  # /bin/sleep dai 5..8) -> chap nhan 4..8; token bien mat; dung 1 cap
  # <service>/</service> bi bo; devicemanager con nguyen.
  if [ "$rm_lines" -ge 4 ] && [ "$rm_lines" -le 8 ] && [ "$t" -eq 0 ] \
     && [ "$ns" -eq "$((os-1))" ] && [ "$ne" -eq "$((oe-1))" ] && [ "$nd" -eq "$od" ]; then
    cp "$TMP" "$CONF" || die "commit $CONF fail"
    log "$BASE: da cat stanza ($o->$n dong, service $os->$ns, /service $oe->$ne)"
  else
    die "SANITY FAIL tren $BASE (bo $rm_lines dong, want 4..8; token=$t service=$ns/$((os-1)) close=$ne/$((oe-1)) devmgr=$nd/$od) -> KHONG doi file, giu backup"
  fi
  rm -f "$TMP"
done

# --- 3. xoa thu muc runtime (binary + log + marker) + backup (moi conf da sach) ---
rm -rf "$MOD_DIR" 2>/dev/null
for CONF in $CONFS; do
  BAK="/data_persist/$(basename "$CONF").bak_prevegvisir"
  [ -f "$BAK" ] && rm -f "$BAK" && log "xoa backup $BAK"
done
sync
mount -o remount,ro / 2>/dev/null

echo ""
log "=== VERIFY (ky vong 0 / KHONG / da xoa) ==="
for CONF in $CONFS; do
  [ -f "$CONF" ] && log "$(basename "$CONF"): stanza con lai = $(grep -c "$TOKEN" "$CONF")"
done
log "process con lai = $(veg_pids | wc -l | tr -d ' ')"
log "$MOD_DIR = $([ -d "$MOD_DIR" ] && echo CON || echo 'da xoa')"
log "backup con lai = $(ls /data_persist/sm*.bak_prevegvisir 2>/dev/null | wc -l | tr -d ' ')"
log "DONE."
exit 0
