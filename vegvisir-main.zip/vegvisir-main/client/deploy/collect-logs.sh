#!/bin/sh
# ============================================================================
#  collect-logs.sh — gom log của vegvisir-client trên CMU vào USB.
#
#  Copy mọi file log trong /data_persist/vegvisir-client/ sang thư mục
#  <USB>/logs/, đặt tên theo THỜI GIAN GHI LOG (mtime của file, hoặc dòng log
#  cuối cùng nếu busybox không có `date -r`):
#        logs/client-YYYYmmdd-HHMMSS.log
#  Mỗi lần chạy tạo một bản mới không đè bản cũ (trùng thời gian thì thêm -N),
#  nên log tích luỹ qua nhiều lần cắm/nhiều lần boot.
#
#  CÁCH CHẠY
#    - Tự động (usb-autorun): đổi tên file này thành vegvisir-autorun.sh ở gốc
#      stick, hoặc gọi nó từ script autorun của bạn. Nhận $1=<mount> như mọi
#      script autorun; cwd = gốc stick.
#    - Thủ công trên shell CMU:   sh /mnt/sdXN/deploy/collect-logs.sh
#      (hoặc truyền đích:         sh collect-logs.sh /mnt/sdb1 )
#
#  vfat trên stick thường mount noexec -> luôn chạy bằng `sh ...`, đừng ./
# ============================================================================
set -u

SRC_DIR="/data_persist/vegvisir-client"
TAG="[collect-logs]"

log() { echo "$TAG $*"; }

# --- 1) tìm gốc USB để ghi vào -----------------------------------------------
# Ưu tiên: env của usb-autorun -> tham số $1 (mount) -> mount point chứa script.
if [ -n "${USB_AUTORUN_MOUNT:-}" ] && [ -d "${USB_AUTORUN_MOUNT}" ]; then
  USB_ROOT="$USB_AUTORUN_MOUNT"
elif [ -n "${1:-}" ] && [ -d "$1" ]; then
  USB_ROOT="$1"
else
  SELF_DIR=$(cd "$(dirname "$0")" 2>/dev/null && pwd)
  # mount point của phân vùng chứa chính script này (df in dòng 2, cột cuối)
  USB_ROOT=$(df "${SELF_DIR:-.}" 2>/dev/null | awk 'NR==2 {print $NF}')
  [ -n "$USB_ROOT" ] || USB_ROOT="${SELF_DIR:-$(pwd)}"
fi

DEST="$USB_ROOT/logs"

# --- 2) nguồn phải tồn tại ----------------------------------------------------
if [ ! -d "$SRC_DIR" ]; then
  log "không thấy $SRC_DIR — vegvisir-client chưa được cài? Bỏ qua."
  exit 0
fi

# --- 3) đảm bảo USB ghi được (remount rw nếu đang read-only) ------------------
# CMU thường mount USB read-only -> cp/mkdir sẽ fail. Dò ghi thử; nếu không được
# thì remount rw, làm việc, và trả lại ro lúc thoát (để rút USB an toàn).
# remount phải thực hiện trên MOUNT POINT thật của phân vùng chứa USB_ROOT.
MP=$(df "$USB_ROOT" 2>/dev/null | awk 'NR==2 {print $NF}')
[ -n "$MP" ] || MP="$USB_ROOT"
REMOUNTED=0

# Dò fs có ghi được không — ghi thử 1 file tạm NGAY tại mount point, KHÔNG tạo
# folder đích ở đây. Tách "dò read-only" khỏi "tạo folder" để việc tạo folder
# không bao giờ là thứ khiến script dừng trước khi kịp remount.
fs_writable() {
  ( : > "$MP/.veg_wtest" ) 2>/dev/null && { rm -f "$MP/.veg_wtest" 2>/dev/null; return 0; }
  return 1
}

restore_ro() {   # trả USB về read-only nếu chính ta đã lật sang rw
  [ "$REMOUNTED" = 1 ] || return 0
  sync 2>/dev/null
  mount -o remount,ro "$MP" 2>/dev/null && log "đã trả $MP về read-only"
}
trap 'restore_ro' EXIT INT TERM

if ! fs_writable; then
  log "USB $MP đang read-only — thử remount rw…"
  DEV=""
  [ -r /proc/mounts ] && DEV=$(awk -v m="$MP" '$2==m {print $1; exit}' /proc/mounts)
  if mount -o remount,rw "$MP" 2>/dev/null \
     || { [ -n "$DEV" ] && mount -o remount,rw "$DEV" "$MP" 2>/dev/null; }; then
    REMOUNTED=1
    log "đã remount rw $MP (${DEV:-?})"
  else
    log "remount rw thất bại — cần chạy bằng root (autorun chạy root; shell thì dùng su). Dừng."
    exit 1
  fi
  if ! fs_writable; then
    log "vẫn không ghi được sau remount — dừng."
    exit 1
  fi
fi

# fs đã chắc chắn ghi được -> giờ mới tạo folder đích.
if ! mkdir -p "$DEST" 2>/dev/null; then
  log "USB ghi được nhưng không tạo nổi $DEST (có file trùng tên 'logs'?) — dừng."
  exit 1
fi

# --- 4) mốc thời gian của một file log ---------------------------------------
# Trả về chuỗi YYYYmmdd-HHMMSS. Ưu tiên mtime (thời điểm ghi cuối); nếu busybox
# không hỗ trợ `date -r` thì lấy timestamp của DÒNG LOG CUỐI trong file
# (định dạng log: "YYYY-MM-DD HH:MM:SS ..."). Cùng đường thì trả rỗng.
logstamp() {
  _f="$1"
  # a) mtime của file
  _ts=$(date -r "$_f" +%Y%m%d-%H%M%S 2>/dev/null)
  case "$_ts" in
    ????????-??????) echo "$_ts"; return 0 ;;
  esac
  # b) dòng log cuối cùng có timestamp
  _line=$(grep -oE '^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}' "$_f" 2>/dev/null | tail -n 1)
  if [ -n "$_line" ]; then
    echo "$_line" | tr -d ':-' | tr ' ' '-'   # "2026-08-26 14:58:38" -> "20260826-145838"
    return 0
  fi
  # c) chịu thua: dùng giờ hiện tại (clock CMU có thể sai, nhưng vẫn duy nhất)
  date +%Y%m%d-%H%M%S 2>/dev/null || echo "unknown"
}

# --- 5) copy từng file log ----------------------------------------------------
n=0
seen=""
for f in "$SRC_DIR"/client*.log* "$SRC_DIR"/*.log; do
  [ -f "$f" ] || continue                       # không khớp glob -> bỏ
  # tránh xử lý trùng khi hai pattern cùng khớp một file
  case " $seen " in *" $f "*) continue ;; esac
  seen="$seen $f"

  stem=$(basename "$f"); stem="${stem%.log}"
  ts=$(logstamp "$f")
  out="$DEST/$stem-$ts.log"

  # đụng tên (đã copy đúng file này trước đó với cùng mtime) -> thêm hậu tố
  if [ -e "$out" ]; then
    i=1
    while [ -e "$DEST/$stem-$ts-$i.log" ]; do i=$((i+1)); done
    out="$DEST/$stem-$ts-$i.log"
  fi

  if cp "$f" "$out" 2>/dev/null; then
    sz=$(wc -c < "$out" 2>/dev/null | tr -d ' ')
    log "copied $(basename "$f") -> logs/$(basename "$out") (${sz:-?} bytes)"
    n=$((n+1))
  else
    log "LỖI copy $f"
  fi
done

sync 2>/dev/null   # xả cache trước khi rút USB

if [ "$n" -eq 0 ]; then
  log "không có file log nào trong $SRC_DIR."
else
  log "xong: $n file -> $DEST"
fi
exit 0
