# `hud_sink` — HUD output sink

`hud/hud_sink` is the one place that draws on the Mazda instrument-cluster HUD.
It is a plain API (`namespace hud`): hudnav decodes the server's Navigation JSON
into the neutral `NavManeuver` / `NavDistance` / `NavLanes` types and pushes
them here; the sink turns them into OEM `com.jci.vbs.navi` D-Bus frames.

- Source: [`src/hud/hud_sink.h`](../src/hud/hud_sink.h) /
  [`src/hud/hud_sink.cpp`](../src/hud/hud_sink.cpp)
- Neutral model: [`src/core/nav_types.h`](../src/core/nav_types.h)
- The caller: [`src/hudnav/hudnav.cpp`](../src/hudnav/hudnav.cpp)

This is the **basic** HUD: maneuver icon + distance + road-name strip + posted
speed-limit sign (`speedLimit` km/h; 0 blanks it) + the recommended-lane row.

---

## 1. How to use it

### The API

```cpp
#include "hud/hud_sink.h"

hud::open();                 // idempotent: sender thread + OEM D-Bus, on first use
hud::routeActive(true);
hud::maneuver(m);
hud::distance(d);
```

One process-wide sink, one caller: `src/hudnav/hudnav.cpp`, the handler for the
socket's `Navigation` messages. There is no interface to implement and no handle
to obtain — v1.3's `NavSink` / `hud_sink_for()` view layer existed to arbitrate
between two navigation sources and went away with the second one.

| Function | When to call | Effect |
|---|---|---|
| `hud::open()` | first time real navigation is available | spawns the sender thread, connects the OEM D-Bus, starts the ~2 Hz keep-alive. Idempotent; an atomic check once up, so calling it on every frame is fine. |
| `hud::routeActive(true)` | route is guiding | marks guidance live so the keep-alive re-asserts the frame |
| `hud::maneuver(const NavManeuver&)` | the next maneuver changed | updates the icon + road strip |
| `hud::distance(const NavDistance&)` | the distance readout changed | updates the distance number + unit |
| `hud::lanes(const NavLanes&)` | the lane row changed (`count == 0` = none) | updates the lane arrows |
| `hud::speedLimit(int kmh)` | the posted limit changed (`0` = none) | updates / blanks the speed-limit sign |
| `hud::routeActive(false)` | guidance ended (route finished / turned off) | blanks the maneuver frame |
| `hud::clear()` | source gone (unplugged / link lost) | wipes the HUD, speed-limit sign included |
| `hud::close()` | teardown | sends a clear frame, stops the thread, releases D-Bus |

### The flow in hudnav

```cpp
void handle_navigation(const net::Envelope &env) {
    hud::open();                 // idempotent — called on every frame

    NavManeuver m{};
    m.event  = NAV_EV_TURN;      // see the arrow table below
    m.side   = NAV_SIDE_LEFT;    // 1=left, 2=right, 3=none
    m.angle  = 0;                // roundabout only
    m.number = 0;                // roundabout exit only
    strncpy(m.road, "Nguyễn Huệ", sizeof(m.road) - 1);
    hud::routeActive(true);
    hud::maneuver(m);

    NavDistance d{};
    d.meters          = 1400;
    d.displayDistance = 1400;              // km convention: /100 -> 14 -> "1.4"
    d.displayUnit     = NAV_UNIT_KILOMETERS;
    hud::distance(d);
}
```

### Rules the caller must follow

- **Never block, never throw.** The setters run on the socket receive thread;
  an exception escaping there aborts the service (`std::terminate` → `SIGABRT`).
  Keep the update trivial.
- **`open()` is lazy + idempotent.** Call it when navigation first arrives, not
  at load — this avoids bringing up the D-Bus connection with no phone present.
- **Fields are copied out before the call returns.** You may build the struct on
  the stack and reuse the storage immediately. `road` is NUL-terminated UTF-8.
- **Partial updates are fine.** Maneuver and distance are separate calls; the
  sink keeps whatever you don't update. A burst of updates is coalesced (seqlock
  + "latest wins") into one send.

### What the sink does internally (so you don't have to)

- **UTF-8 / Vietnamese normalization.** The cluster font renders 1- and 2-byte
  UTF-8 but drops 3-byte codepoints, so Vietnamese chars with two stacked
  diacritics (`ề ớ ấ …`) are folded to their 2-byte form (`ê ơ â …`). Toggle
  with the build flag `VEGVISIR_CLIENT_VN_NORMALIZE` (on by default).
- **Keep-alive.** A ~2 Hz ticker re-asserts the last frame so the cluster ECU
  doesn't age the maneuver out while you're between updates.
- **Two OEM frames per push.** `SetHUDDisplayMsgReq` carries the icon + distance;
  `SetHUD_Display_Msg2` carries the road strip. They are always sent as a pair.
  The lane row is a **third**, independent frame (`SetRecommLaneReq`) sent only
  when its glyphs actually change — see §5.
- **Empty road → a single space.** An empty street slot makes the ECU render
  garbage, so the sink substitutes `" "`.

---

## 2. Arrow (turn) types

A maneuver is described by two neutral fields:

- `event` — the *kind* of maneuver (`NavEvent` in `nav_types.h`).
- `side` — the *direction* (`NavSide`): `NAV_SIDE_LEFT` (1), `NAV_SIDE_RIGHT`
  (2), `NAV_SIDE_NONE` (3 = straight / not applicable).

The sink maps `(event, side)` to a Mazda cluster **glyph ID** — the integer the
ECU firmware draws (the glyph atlas is baked into the ECU, out of our control).

> 🧭 **Illustrated reference:** open [`hud_glyphs.html`](hud_glyphs.html) in a browser for
> a drawn icon of every glyph ID (including all 24 roundabout sectors) and the
> `NavEvent · side` that selects each one.

### `NavEvent` → glyph, by side

`side` selects the column: **L** = left, **R** = right, **—** = none/straight.
A `·` means "no glyph" (the HUD draws blank).

| `NavEvent` | value | L | R | — | Meaning |
|---|---:|---|---|---|---|
| `NAV_EV_UNKNOWN`     | 0  | · | · | · | unknown → blank |
| `NAV_EV_DEPART`      | 1  | flag-left (35) | flag-right (36) | flag (12) | start / depart |
| `NAV_EV_NAME_CHANGE` | 2  | straight (1) | straight (1) | straight (1) | road changes name |
| `NAV_EV_SLIGHT`      | 3  | slight-left (4) | slight-right (5) | straight (1) | slight/bear turn |
| `NAV_EV_TURN`        | 4  | left (2) | right (3) | straight (1) | normal turn |
| `NAV_EV_SHARP`       | 5  | sharp-left (11) | sharp-right (9) | straight (1) | sharp turn |
| `NAV_EV_UTURN`       | 6  | u-turn-left (13) | u-turn-right (10) | straight (1) | U-turn |
| `NAV_EV_ON_RAMP`     | 7  | left (2) | right (3) | straight (1) | motorway on-ramp |
| `NAV_EV_OFF_RAMP`    | 8  | off-ramp-left (30) | off-ramp-right (7) | straight (1) | motorway exit |
| `NAV_EV_FORK`        | 9  | fork-left (15) | fork-right (14) | straight (1) | fork / keep left-right |
| `NAV_EV_MERGE`       | 10 | merge-left (16) | merge-right (17) | straight (1) | merge |
| `NAV_EV_ROUNDABOUT`  | 13 | *(see §3)* | *(see §3)* | *(see §3)* | roundabout — glyph from exit angle |
| `NAV_EV_STRAIGHT`    | 14 | straight (1) | straight (1) | straight (1) | continue straight |
| `NAV_EV_FERRY`       | 16 | · | · | · | ferry — no cluster glyph (blank) |
| `NAV_EV_DEST`        | 19 | dest-left (33) | dest-right (34) | destination (8) | arrive at destination |

Notes:
- Values **11, 12, 15, 17, 18** are unassigned → blank. The numbering is sparse
  because it mirrors Android Auto's `hu.proto NAVTurnMessage.TURN_EVENT`, which
  the Mazda glyph table was validated against.
- **Ferry has no cluster glyph** — it maps to blank. If you need something
  visible, pick a different `event`.
- An out-of-range `event` (≥ 20) is treated as blank by the sink; hudnav clamps
  to a known value before pushing (`safe_event()`).

### Mazda glyph IDs (for reference)

These are the raw ECU codes the table above resolves to (`MazdaIcon` enum):

```
 1 straight        2 left            3 right           4 slight-left
 5 slight-right    7 off-ramp-right  8 destination     9 sharp-right
10 u-turn-right   11 sharp-left     12 flag           13 u-turn-left
14 fork-right     15 fork-left      16 merge-left     17 merge-right
30 off-ramp-left  33 dest-left      34 dest-right      35 flag-left   36 flag-right
37..48  roundabout, right-hand-traffic bank (12 directions)
49..60  roundabout, left-hand-traffic bank  (12 directions)
```

---

## 3. Roundabouts

For `NAV_EV_ROUNDABOUT` the glyph is chosen from the **exit bearing**, not a
fixed table:

- `angle` — exit bearing in degrees: `0` = straight through, positive = right /
  clockwise, negative = left. (For a non-roundabout maneuver, leave `angle = 0`.)
- `side` — selects the traffic bank: `NAV_SIDE_LEFT` → left-hand-traffic bank
  (glyphs 49–60), otherwise right-hand-traffic bank (37–48).
- `number` — the exit number (1..19) if the source provides it; `0` otherwise.

The sink buckets the bearing into 12 sectors of 30° and offsets into the bank:

```
d       = (180 - angle) mod 360        // bank sector 0 points down (entry leg),
sector  = round(d / 30) mod 12         //   index runs counter-clockwise
glyph   = sector + (LHT ? 49 : 37)
```

So (right-hand traffic): straight-through exit → up arrow, `+90°` → right,
`+270° / -90°` → left, `180°` → back down.

---

## 4. Distance readout

`hud::distance(const NavDistance&)` carries:

| Field | Meaning |
|---|---|
| `meters` | raw metres to the maneuver (informational) |
| `displayDistance` | the value the HUD shows, in `displayUnit`, **×1000** |
| `displayUnit` | `NavDistanceUnit` (see below) |
| `timeUntilSeconds` | ETA seconds (0 = unknown) |

The sink shows `displayDistance / 100` (i.e. one decimal place), so:

- **metres:** `displayDistance = metres × 1000` → e.g. 800 m → `800000` → shows `800.0`
- **kilometres:** `displayDistance = metres` → e.g. 1400 m → `1400` → shows `1.4`

`displayUnit` is mapped to the cluster's own unit enum:

| `NavDistanceUnit` | value | → cluster unit |
|---|---:|---|
| `NAV_UNIT_METERS`       | 1 | metres |
| `NAV_UNIT_KILOMETERS10` | 2 | kilometres |
| `NAV_UNIT_KILOMETERS`   | 3 | kilometres |
| `NAV_UNIT_MILES10`      | 4 | miles |
| `NAV_UNIT_MILES`        | 5 | miles |
| `NAV_UNIT_FEET`         | 6 | feet |

(The cluster HUD supports metres, miles, kilometres, yards, feet. An unknown
unit renders nothing.)

---

## 5. Lane arrows

`hud::lanes(const NavLanes&)` fills the cluster's lane row — up to 8 slots, one
glyph each, drawn left to right. A lane is described geometrically, not
symbolically, so any source can express it:

| Field | Meaning |
|---|---|
| `NavLane::angles[]` / `angleCount` | every direction this lane allows, in degrees: `0` = straight, negative = left, positive = right (`-90` = left, `30` = slight right, `-180` = U-turn left) |
| `NavLane::highlight` | the one direction the route takes from this lane, in degrees, or `NAV_LANE_NO_HIGHLIGHT` |
| `NavLane::recommended` | 1 = a lane the driver should be in for the maneuver |
| `NavLanes::count` | lanes in play; **0 blanks the row** |

Angles are bucketed into the seven directions the OEM knows (straight, slight /
normal / sharp on each side) — so `-95°` and `-90°` are the same arrow. A
`recommended` lane with exactly one `highlight` gets the OEM's combined glyph
(the taken direction solid, the rest faint); other lanes get the plain "not your
lane" variant of their arrow. The translation is
[`src/hud/hud_lane.cpp`](../src/hud/hud_lane.cpp) — three reverse-engineered
tables (direction bitmask → OEM lane code → cluster glyph) ported verbatim from
the hudbridge-hud reference; see [NOTICE.md](../NOTICE.md).

Rules worth knowing:

- **`count == 0` is the normal state.** Most maneuvers carry no lane data. The
  caller must push the empty row when that is the case, otherwise the previous
  maneuver's arrows stay on the glass — the lane frame is independent of the
  maneuver frame and does not blank with it.
- **Sent on change only,** and re-asserted by the keep-alive only while the row
  is non-blank (an all-hidden row cannot age out, so there is nothing to keep
  alive).
- `routeActive(false)`, `clear()` and `close()` all blank the row.
- Lanes are a bonus: a failing `SetRecommLaneReq` is logged and dropped, never
  propagated — it must not cost the maneuver.

## 6. Lifecycle summary

```
first Navigation frame   ──► hud::open()              (spawn sender + D-Bus, once)
route guiding            ──► hud::routeActive(true)
next maneuver changes    ──► hud::maneuver(m)         ─┐ coalesced, re-asserted
distance ticks           ──► hud::distance(d)          │ at ~2 Hz by keep-alive
lane row changes         ──► hud::lanes(l)            ─┘ (lane row: on change only)
speed limit changes      ──► hud::speedLimit(kmh)         (0 blanks the sign)
guidance ends            ──► hud::routeActive(false)      (blank maneuver + lanes)
link lost / unplugged    ──► hud::clear()                 (wipe HUD)
shutdown                 ──► hud::close()                 (clear frame + release)
```
