#!/bin/sh
# ============================================================================
#  usb-autorun — worker (chạy nền, tách khỏi udev).
#
#  Luồng:  udev add /dev/sdXN
#          -> chờ OEM (devicemanager) mount stick (CMU mount tại /mnt/sdXN)
#          -> nếu OEM không mount trong WAIT_MOUNT_SECS thì tự mount tạm
#          -> nếu gốc stick có "$AUTORUN_NAME" thì chạy:  sh ./<name> <mount> <dev>
#             (chạy bằng `sh` vì vfat thường mount noexec; cwd = gốc stick)
#          -> log ra <stick>/usb-autorun.log và /data_persist/usb-autorun/autorun.log
#
#  Chống chạy lặp: 1 marker /tmp/usb-autorun/done.<uuid|dev> mỗi lần cắm; rule
#  remove xoá marker. Chống chạy song song: lock dir /tmp/usb-autorun/lock.
#
#  Script autorun nhận:  $1 = mount point,  $2 = /dev/sdXN
#  và env USB_AUTORUN_MOUNT / USB_AUTORUN_DEV / USB_AUTORUN_FSTYPE.
#  Script tự lo remount rw rootfs, watchdog, reboot... nếu cần (xem example/).
# ============================================================================
AUTORUN_NAME="${AUTORUN_NAME:-vegvisir-autorun.sh}"
WAIT_MOUNT_SECS=60
PERSIST=/data_persist/usb-autorun
STATE=/tmp/usb-autorun
LOG="$PERSIST/autorun.log"
TAG="[usb-autorun]"

ACTION="$1"; DEV="$2"; FSTYPE="${3:-}"; UUID="${4:-}"
[ -n "$DEV" ] || exit 0
KEY="${UUID:-$(echo "$DEV" | tr / _)}"
MARK="$STATE/done.$KEY"

mkdir -p "$STATE" "$PERSIST" 2>/dev/null
log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $TAG $*" >> "$LOG"; }

DEVKEY=$(echo "$DEV" | tr / _)
if [ "$ACTION" = "remove" ]; then
  # lúc remove udev không còn ID_FS_UUID -> tra bảng dev->key ghi lúc add
  KF="$STATE/key.$DEVKEY"
  [ -f "$KF" ] && rm -f "$STATE/done.$(cat "$KF")" "$KF"
  rm -f "$STATE/done.$DEVKEY"
  exit 0
fi
[ "$ACTION" = "add" ] || exit 0

# --- chống lặp + chống song song ---------------------------------------------
[ -e "$MARK" ] && exit 0
if ! mkdir "$STATE/lock" 2>/dev/null; then
  log "$DEV: another autorun is running — skip"
  exit 0
fi
trap 'rmdir "$STATE/lock" 2>/dev/null' EXIT INT TERM
touch "$MARK"; echo "$KEY" > "$STATE/key.$DEVKEY"
log "$DEV added (fs=${FSTYPE:-?} uuid=${UUID:-?}) — waiting for mount"

# --- 1) chờ OEM mount ----------------------------------------------------------
mp=""; n=0; OWN_MOUNT=0
while [ $n -lt $WAIT_MOUNT_SECS ]; do
  mp=$(awk -v d="$DEV" '$1==d {print $2; exit}' /proc/mounts)
  [ -n "$mp" ] && break
  sleep 1; n=$((n+1))
done

# --- 2) fallback: tự mount ------------------------------------------------------
if [ -z "$mp" ]; then
  [ -b "$DEV" ] || { log "$DEV: device gone before mount — abort"; exit 0; }
  mp="$STATE/mnt/$(basename "$DEV")"
  mkdir -p "$mp"
  if mount -t "${FSTYPE:-auto}" -o rw,noatime "$DEV" "$mp" 2>>"$LOG" \
     || mount "$DEV" "$mp" 2>>"$LOG"; then
    OWN_MOUNT=1; log "$DEV: OEM did not mount in ${WAIT_MOUNT_SECS}s — mounted myself at $mp"
  else
    log "$DEV: mount failed — abort"; rmdir "$mp" 2>/dev/null; exit 0
  fi
else
  log "$DEV mounted by system at $mp"
fi

# --- 3) tìm và chạy script -----------------------------------------------------
SCRIPT="$mp/$AUTORUN_NAME"
if [ -f "$SCRIPT" ]; then
  ULOG="$mp/usb-autorun.log"
  log "$DEV: running $SCRIPT"
  {
    echo "=== usb-autorun: $AUTORUN_NAME on $DEV ($mp) at $(date) ==="
    cd "$mp" && USB_AUTORUN_MOUNT="$mp" USB_AUTORUN_DEV="$DEV" USB_AUTORUN_FSTYPE="$FSTYPE" \
      sh "./$AUTORUN_NAME" "$mp" "$DEV"
    echo "=== exit code: $? at $(date) ==="
  } 2>&1 | tee -a "$LOG" >> "$ULOG" 2>/dev/null
  sync
  log "$DEV: $AUTORUN_NAME finished"
else
  log "$DEV: no $AUTORUN_NAME at $mp — nothing to do"
fi

# --- 4) dọn mount tạm --------------------------------------------------------------
if [ $OWN_MOUNT = 1 ]; then
  sync; umount "$mp" 2>/dev/null && rmdir "$mp" 2>/dev/null
fi
exit 0
