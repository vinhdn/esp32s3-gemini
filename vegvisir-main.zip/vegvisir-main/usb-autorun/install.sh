#!/bin/sh
# ============================================================================
#  usb-autorun — installer cho Mazda CMU (JCI). Chạy trên unit (SSH hoặc USB).
#
#  - scripts  -> /data_persist/usb-autorun/   (persistent, không tốn rootfs)
#  - udev rule-> /etc/udev/rules.d/99-usb-autorun.rules  (file DUY NHẤT trên rootfs)
#  - nạp lại rule ngay (udevadm control --reload-rules) — không cần reboot
#  Không sửa sm.conf hay bất kỳ file OEM nào khác. Gỡ: sh uninstall.sh
#
#  Tuỳ chọn:  AUTORUN_NAME=<tên file> sh install.sh   (mặc định vegvisir-autorun.sh)
# ============================================================================
set -u
TAG="[usb-autorun install]"
SELF_DIR=$(cd "$(dirname "$0")" && pwd)
PERSIST=/data_persist/usb-autorun
RULE_SRC="$SELF_DIR/99-usb-autorun.rules"
RULE_DST=/etc/udev/rules.d/99-usb-autorun.rules
NAME="${AUTORUN_NAME:-vegvisir-autorun.sh}"

log() { echo "$TAG $*"; }
die() { echo "$TAG ERROR: $*" >&2; mount -o remount,ro / 2>/dev/null; exit 1; }

[ -f "$RULE_SRC" ] || die "99-usb-autorun.rules not found next to install.sh"
[ -f "$SELF_DIR/usb-autorun.sh" ] && [ -f "$SELF_DIR/usb-autorun-trigger.sh" ] || die "worker/trigger scripts missing"
[ -d /etc/udev/rules.d ] || die "no /etc/udev/rules.d — not a udev system"
[ "$(id -u)" = "0" ] || die "must run as root"

# --- 1) scripts lên persistent -------------------------------------------------
mkdir -p "$PERSIST" || die "mkdir $PERSIST failed"
for f in usb-autorun.sh usb-autorun-trigger.sh; do
  cp -f "$SELF_DIR/$f" "$PERSIST/$f.new" || die "copy $f failed"
  chmod 0755 "$PERSIST/$f.new"; mv -f "$PERSIST/$f.new" "$PERSIST/$f"
done
# ghi tên script đặc biệt vào worker nếu người dùng đổi
[ "$NAME" != "vegvisir-autorun.sh" ] && sed -i "s|^AUTORUN_NAME=.*|AUTORUN_NAME=\"\${AUTORUN_NAME:-$NAME}\"|" "$PERSIST/usb-autorun.sh"
log "scripts -> $PERSIST (autorun file name: $NAME)"

# --- 2) udev rule lên rootfs ---------------------------------------------------
mount -o remount,rw / 2>/dev/null || die "remount rw failed"
[ -f "$RULE_DST" ] && cp -f "$RULE_DST" "$PERSIST/99-usb-autorun.rules.prev"
cp -f "$RULE_SRC" "$RULE_DST" || die "install rule failed"
chmod 0644 "$RULE_DST"
sync
mount -o remount,ro / 2>/dev/null
log "udev rule -> $RULE_DST"

# --- 3) nạp lại rule -------------------------------------------------------------
udevadm control --reload-rules 2>/dev/null \
  || udevadm control --reload 2>/dev/null \
  || udevcontrol reload_rules 2>/dev/null \
  || log "WARNING: could not reload udev rules — takes effect after reboot"

echo ""
log "=== VERIFY ==="
log "rule-installed=$([ -f "$RULE_DST" ] && echo yes || echo NO)"
log "trigger-exec=$([ -x "$PERSIST/usb-autorun-trigger.sh" ] && echo yes || echo NO)"
log "DONE. Put '$NAME' at the root of a USB stick and plug it in."
log "Logs: <stick>/usb-autorun.log and $PERSIST/autorun.log"
