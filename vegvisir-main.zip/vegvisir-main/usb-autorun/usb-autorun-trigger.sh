#!/bin/sh
# usb-autorun — mục tiêu của RUN+= trong 99-usb-autorun.rules.
# PHẢI thoát ngay: udevd (udev-168) kill RUN khi hết timeout và chỉ coi RUN xong
# khi stdout/stderr của nó đóng. Vì vậy: đóng hết I/O, tách worker ra nền
# (setsid nếu có, để không dính process group của udevd), rồi return.
#   $1 = add|remove   $2 = /dev/sdXN   $3 = fstype (có thể rỗng)   $4 = fs uuid
DIR=$(dirname "$0")
WORKER="$DIR/usb-autorun.sh"
[ -x "$WORKER" ] || WORKER="sh $WORKER"

if command -v setsid >/dev/null 2>&1; then
  setsid $WORKER "$@" </dev/null >/dev/null 2>&1 &
else
  ( $WORKER "$@" </dev/null >/dev/null 2>&1 & ) &
fi
exit 0
