# usb-autorun — chạy script trên USB stick bằng udev (Mazda CMU)

Cắm USB có file **`vegvisir-autorun.sh`** ở gốc → CMU tự chạy nó (root),
log ra `<stick>/usb-autorun.log` và `/data_persist/usb-autorun/autorun.log`.
Không cần `cmu_dataretrieval.up`, không sửa `sm.conf`.

```
cắm stick ─► kernel uevent (block, sdXN)
          ─► udevd: 99-usb-autorun.rules  RUN+= usb-autorun-trigger.sh   (thoát ngay)
                        └─► setsid usb-autorun.sh (nền)
                              ├─ chờ OEM devicemanager mount  (/mnt/sdXN, ≤60 s)
                              ├─ fallback: tự mount /tmp/usb-autorun/mnt/sdXN
                              └─ có vegvisir-autorun.sh ở gốc?  → sh ./vegvisir-autorun.sh <mp> <dev>
```

| File | Vai trò |
|---|---|
| `99-usb-autorun.rules` | Rule udev → `/etc/udev/rules.d/` (file duy nhất ghi lên rootfs) |
| `usb-autorun-trigger.sh` | Mục tiêu `RUN+=`: tách worker ra nền rồi thoát trong ~0 s |
| `usb-autorun.sh` | Worker: chờ mount, tìm script, chạy, log, chống lặp/song song |
| `install.sh` / `uninstall.sh` | Cài lên `/data_persist/usb-autorun/` + rule; gỡ sạch |
| `example/vegvisir-autorun.sh` | Mẫu: gọi `deploy/install.sh` của vegvisir-client nằm trên stick |

Cài (SSH vào unit, copy thư mục này lên): `sh install.sh` — có hiệu lực ngay
(`udevadm control --reload-rules`), không cần reboot. Đổi tên file đặc biệt:
`AUTORUN_NAME=my.sh sh install.sh`.

## Nên đặt index rule bao nhiêu?

udev gộp `/usr/libexec/rules.d` (CMU; `/lib/udev/rules.d` trên distro) và
`/etc/udev/rules.d`, rồi xử lý theo **thứ tự tên file**. Với rule kiểu
"USB storage → RUN":

* **Phải > 60**: `60-persistent-storage.rules` chạy builtin `blkid` điền
  `ENV{ID_FS_TYPE}`, `ID_FS_UUID`, `ID_BUS=usb`. Đặt 10–59 thì các ENV này
  chưa tồn tại, match `ENV{ID_FS_TYPE}!=""` (superfloppy) sẽ sai.
* **Dùng 99** (như bộ này, và như `99-usbdiscoverer.rules` / `99-usbnet.rules`
  của OEM): chạy sau cả `95-udev-late.rules`, thấy đầy đủ ENV của mọi rule
  trước, không bị rule OEM nào ghi đè. Trên distro hiện đại 99 vẫn là chuẩn
  cho rule local (systemd-udevd cũng chỉ có tới `99-systemd.rules`).
* Index **không** quyết định *thời điểm* chạy: mọi `RUN+=` của một event đều
  được thực thi **sau khi toàn bộ rule của event đó xử lý xong**, bất kể nằm ở
  file số nào. Nó chỉ quyết định rule của bạn *nhìn thấy* ENV nào và ai ghi
  đè ai.
* Cùng tên file ở `/etc` sẽ **che** file ở `/usr/libexec`/`/lib` → không đặt
  tên trùng file OEM.

Điều làm service "chắc được chạy" không phải index mà là cách viết RUN:

1. `RUN+=` bị **kill khi hết event timeout** (udev-168 trên CMU có
   `event_timeout`; systemd-udevd mặc định 180 s) và udevd chỉ coi RUN xong khi
   **stdout/stderr của nó đóng** → trigger redirect I/O về `/dev/null`, `setsid`
   worker ra nền, exit 0.
2. Lúc `add` **chưa có mount point** — OEM mount sau đó vài giây. Không mount
   trong RUN (systemd-udevd chạy RUN trong private mount namespace → mount xong
   biến mất); worker chờ `/proc/mounts` rồi mới chạy.
3. vfat thường mount `noexec` → chạy bằng `sh ./script`, không `./script`.
4. Một stick sinh nhiều event (disk + partition, và `change`) → marker theo
   UUID/dev để chỉ chạy 1 lần mỗi lần cắm; lock để không chạy song song.

## Kiểm tra trên unit

```sh
udevadm test /sys/block/sda/sda1 2>&1 | grep -i autorun   # rule có match không
tail -f /data_persist/usb-autorun/autorun.log             # rồi cắm stick
```
