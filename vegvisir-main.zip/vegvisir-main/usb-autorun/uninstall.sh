#!/bin/sh
# usb-autorun — gỡ: xoá rule udev, nạp lại, xoá /data_persist/usb-autorun.
set -u
TAG="[usb-autorun uninstall]"
PERSIST=/data_persist/usb-autorun
RULE_DST=/etc/udev/rules.d/99-usb-autorun.rules
log() { echo "$TAG $*"; }

[ "$(id -u)" = "0" ] || { log "must run as root"; exit 1; }
mount -o remount,rw / 2>/dev/null || { log "remount rw failed"; exit 1; }
if [ -f "$PERSIST/99-usb-autorun.rules.prev" ]; then
  cp -f "$PERSIST/99-usb-autorun.rules.prev" "$RULE_DST" && log "restored previous $RULE_DST"
else
  rm -f "$RULE_DST" && log "removed $RULE_DST"
fi
sync
mount -o remount,ro / 2>/dev/null
udevadm control --reload-rules 2>/dev/null || udevadm control --reload 2>/dev/null || udevcontrol reload_rules 2>/dev/null
rm -rf "$PERSIST" /tmp/usb-autorun && log "removed $PERSIST"
log "=== VERIFY (expect NO) === rule-present=$([ -f "$RULE_DST" ] && echo YES || echo no)"
log "DONE."
