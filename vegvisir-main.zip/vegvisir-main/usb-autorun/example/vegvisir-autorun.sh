#!/bin/sh
# Ví dụ script autorun: đặt file này ở GỐC usb stick cùng thư mục deploy/ của
# vegvisir-client (install.sh + binary vegvisir-client). usb-autorun sẽ gọi:
#     sh ./vegvisir-autorun.sh <mount> <dev>     (cwd = gốc stick)
# stdout/stderr đã được ghi vào <stick>/usb-autorun.log.
MP="${1:-$(pwd)}"

# install của vegvisir-client kéo dài vài giây; nếu script của bạn chạy lâu
# (> ~30 s) hãy tắt hardware watchdog như tweaks.sh của cộng đồng làm:
# echo 1 > "/sys/class/gpio/Watchdog Disable/value" 2>/dev/null

if [ -f "$MP/deploy/install.sh" ]; then
  echo "running vegvisir-client install from $MP/deploy"
  sh "$MP/deploy/install.sh"
  echo "install exit=$? — reboot to start the service"
else
  echo "no deploy/install.sh on stick — nothing to do"
fi
